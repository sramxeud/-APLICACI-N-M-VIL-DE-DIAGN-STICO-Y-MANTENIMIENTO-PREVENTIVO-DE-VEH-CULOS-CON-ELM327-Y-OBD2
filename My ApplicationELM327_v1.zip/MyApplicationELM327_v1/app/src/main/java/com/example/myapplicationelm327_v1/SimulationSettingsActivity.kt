package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.widget.Switch
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class SimulationSettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simulation_settings)
        supportActionBar?.hide()

        // Inicializar con el contexto
        OBD2ServiceFactory.initialize(this)

        val switchSimulation = findViewById<Switch>(R.id.switch_simulation)
        switchSimulation.isChecked = OBD2ServiceFactory.isSimulationMode()

        switchSimulation.setOnCheckedChangeListener { _, isChecked ->
            OBD2ServiceFactory.setSimulationMode(isChecked, this)
            Toast.makeText(
                this,
                if (isChecked) "Modo simulación activado" else "Modo real activado",
                Toast.LENGTH_SHORT
            ).show()
        }
    }
}