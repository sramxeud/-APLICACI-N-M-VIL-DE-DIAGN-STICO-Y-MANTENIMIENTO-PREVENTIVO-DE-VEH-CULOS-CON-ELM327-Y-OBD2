package com.example.myapplicationelm327_v1

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class AIService private constructor() {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    companion object {
        private const val OPENROUTER_API_KEY = "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"
        private const val OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
        private const val MODEL_CLAUDE_HAIKU = "anthropic/claude-3-haiku"

        @Volatile
        private var INSTANCE: AIService? = null

        fun getInstance(): AIService =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: AIService().also { INSTANCE = it }
            }
    }

    suspend fun getAIAnalysis(prompt: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val response = makeOpenRouterCall(prompt)
            Result.Success(response)
        } catch (e: Exception) {
            Result.Error(e)
        }
    }

    @Throws(IOException::class)
    private fun makeOpenRouterCall(prompt: String): String {
        val jsonBody = JSONObject().apply {
            put("model", MODEL_CLAUDE_HAIKU)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", """
                        Eres un experto técnico en automoción, motores, sistemas OBD2 y diagnóstico vehicular. 
                        Responde de forma clara, técnica pero entendible en español.
                        Se conciso pero informativo (máximo 200 palabras).
                        
                        $prompt
                    """.trimIndent())
                })
            })
            put("max_tokens", 500)
        }

        val request = Request.Builder()
            .url(OPENROUTER_URL)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .header("Authorization", "Bearer $OPENROUTER_API_KEY")
            .header("HTTP-Referer", "https://elm327app.com")
            .header("X-Title", "ELM327 Automotive App")
            .header("Content-Type", "application/json")
            .build()

        val response = client.newCall(request).execute()

        if (!response.isSuccessful) {
            val errorBody = response.body?.string() ?: "Sin detalles del error"
            throw IOException("HTTP ${response.code}\n$errorBody")
        }

        val responseBody = response.body?.string() ?: throw IOException("Respuesta vacía del servidor")

        return parseOpenRouterResponse(responseBody)
    }

    private fun parseOpenRouterResponse(responseBody: String): String {
        return try {
            val jsonResponse = JSONObject(responseBody)

            if (jsonResponse.has("error")) {
                val errorObj = jsonResponse.getJSONObject("error")
                throw IOException("API: ${errorObj.getString("message")}")
            }

            val choices = jsonResponse.getJSONArray("choices")
            if (choices.length() == 0) {
                throw IOException("La IA no generó respuesta")
            }

            val firstChoice = choices.getJSONObject(0)
            val message = firstChoice.getJSONObject("message")
            message.getString("content").trim()

        } catch (e: Exception) {
            throw IOException("Error procesando respuesta: ${e.message}")
        }
    }

    sealed class Result<out T> {
        data class Success<out T>(val data: T) : Result<T>()
        data class Error(val exception: Exception) : Result<Nothing>()
    }
}