package com.example.myapplicationelm327_v1

import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class OwnerActivity : AppCompatActivity() {

    private lateinit var btnSelectVehicle: Button
    private lateinit var tvSelectedVehicle: TextView
    private lateinit var tvRequestStatus: TextView
    private lateinit var btnCancelRequest: Button
    private lateinit var llMechanicsList: LinearLayout
    private lateinit var btnLogout: Button
    private lateinit var btnContinue: Button
    private lateinit var btnChangeLocation: Button

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance()
    private val usersRef = database.getReference("users")
    private val vehiclesRef = database.getReference("vehicles")
    private val serviceRequestsRef = database.getReference("service_requests")
    private val assignmentsRef = database.getReference("assignments")

    private var currentOwnerId: String = ""
    private var selectedVehicleId: String = ""
    private var selectedVehicleName: String = ""
    private var currentRequest: Map<String, Any>? = null
    private var ownerLatitude: Double = 0.0
    private var ownerLongitude: Double = 0.0

    // Variables para ubicación
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback

    private lateinit var btnPreventiveMaintenance: Button
    private val LOCATION_PERMISSION_REQUEST_CODE = 1002

    // Listeners para actualizaciones en tiempo real
    private var currentRequestListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_owner)

        supportActionBar?.hide()

        initViews()
        setupLocationServices()
        setupClickListeners()

        currentOwnerId = auth.currentUser?.uid ?: ""
        if (currentOwnerId.isEmpty()) {
            Toast.makeText(this, "Error: Usuario no autenticado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        loadOwnerData()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Remover listeners cuando la actividad se destruya
        currentRequestListener?.let {
            serviceRequestsRef.removeEventListener(it)
        }
    }

    private fun initViews() {
        btnSelectVehicle = findViewById(R.id.btnSelectVehicle)
        tvSelectedVehicle = findViewById(R.id.tvSelectedVehicle)
        tvRequestStatus = findViewById(R.id.tvRequestStatus)
        btnCancelRequest = findViewById(R.id.btnCancelRequest)
        llMechanicsList = findViewById(R.id.llMechanicsList)
        btnLogout = findViewById(R.id.btnLogout)
        btnContinue = findViewById(R.id.btnContinue)
        btnChangeLocation = findViewById(R.id.btnChangeLocation)
        btnPreventiveMaintenance = findViewById(R.id.btnPreventiveMaintenance)
    }

    private fun setupClickListeners() {
        btnSelectVehicle.setOnClickListener {
            showVehicleSelectionDialog()
        }

        btnCancelRequest.setOnClickListener {
            cancelCurrentRequest()
        }

        btnLogout.setOnClickListener {
            logoutUser()
        }

        btnContinue.setOnClickListener {
            val intent = Intent(this, BluetoothActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnChangeLocation.setOnClickListener {
            showLocationOptionsDialog()
        }

        btnPreventiveMaintenance.setOnClickListener {
            openPreventiveMaintenance()
        }
    }
    private fun openPreventiveMaintenance() {
        if (selectedVehicleId.isEmpty()) {
            Toast.makeText(this, "Primero selecciona un vehículo", Toast.LENGTH_SHORT).show()
            return
        }

        val intent = Intent(this, PreventiveMaintenanceActivity::class.java).apply {
            putExtra("VEHICLE_ID", selectedVehicleId)
            putExtra("VEHICLE_NAME", selectedVehicleName)
        }
        startActivity(intent)
    }

    private fun setupLocationServices() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationRequest = LocationRequest.create().apply {
            interval = 10000
            fastestInterval = 5000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    updateUserLocationInFirebase(location.latitude, location.longitude)
                    fusedLocationClient.removeLocationUpdates(this)
                }
            }
        }
    }

    private fun showLocationOptionsDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_location_options)
        dialog.setCancelable(true)
        dialog.window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val btnCurrentLocation = dialog.findViewById<Button>(R.id.btnCurrentLocation)
        val btnManualLocation = dialog.findViewById<Button>(R.id.btnManualLocation)
        val btnCancel = dialog.findViewById<Button>(R.id.btnCancel)

        btnCurrentLocation.setOnClickListener {
            dialog.dismiss()
            getCurrentLocation()
        }

        btnManualLocation.setOnClickListener {
            dialog.dismiss()
            showManualLocationDialog()
        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun getCurrentLocation() {
        if (checkLocationPermissions()) {
            btnChangeLocation.text = "Obteniendo ubicación..."
            btnChangeLocation.isEnabled = false

            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())

            // Timeout por si no obtiene ubicación en 10 segundos
            Handler(Looper.getMainLooper()).postDelayed({
                fusedLocationClient.removeLocationUpdates(locationCallback)
                btnChangeLocation.text = "📍 Cambiar mi ubicación"
                btnChangeLocation.isEnabled = true
                Toast.makeText(this, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
            }, 10000)

        } else {
            requestLocationPermissions()
        }
    }

    private fun showManualLocationDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_manual_location)
        dialog.setCancelable(true)
        dialog.window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val etManualLat = dialog.findViewById<EditText>(R.id.etManualLat)
        val etManualLng = dialog.findViewById<EditText>(R.id.etManualLng)
        val btnConfirmManual = dialog.findViewById<Button>(R.id.btnConfirmManual)
        val btnCancelManual = dialog.findViewById<Button>(R.id.btnCancelManual)

        btnConfirmManual.setOnClickListener {
            val lat = etManualLat.text.toString().trim()
            val lng = etManualLng.text.toString().trim()

            if (lat.isNotEmpty() && lng.isNotEmpty()) {
                try {
                    val latitude = lat.toDouble()
                    val longitude = lng.toDouble()

                    if (latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180) {
                        updateUserLocationInFirebase(latitude, longitude)
                        dialog.dismiss()
                        Toast.makeText(this, "📍 Ubicación actualizada", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Coordenadas inválidas", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: NumberFormatException) {
                    Toast.makeText(this, "Formato de coordenadas inválido", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Ingresa ambas coordenadas", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancelManual.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun updateUserLocationInFirebase(latitude: Double, longitude: Double) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val updates = mapOf(
                "latitude" to latitude,
                "longitude" to longitude,
                "updatedAt" to System.currentTimeMillis()
            )

            usersRef.child(currentUser.uid).updateChildren(updates)
                .addOnSuccessListener {
                    btnChangeLocation.text = "📍 Cambiar mi ubicación"
                    btnChangeLocation.isEnabled = true
                    Toast.makeText(this, "✅ Ubicación actualizada correctamente", Toast.LENGTH_SHORT).show()

                    // Actualizar las coordenadas locales para cálculos de distancia
                    ownerLatitude = latitude
                    ownerLongitude = longitude
                }
                .addOnFailureListener {
                    btnChangeLocation.text = "📍 Cambiar mi ubicación"
                    btnChangeLocation.isEnabled = true
                    Toast.makeText(this, "❌ Error al actualizar ubicación", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun checkLocationPermissions(): Boolean {
        return (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }

    private fun requestLocationPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Se necesitan permisos de ubicación", Toast.LENGTH_SHORT).show()
                showManualLocationDialog()
            }
        }
    }

    private fun loadOwnerData() {
        usersRef.child(currentOwnerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val ownerData = snapshot.value as? Map<String, Any>
                ownerData?.let {
                    ownerLatitude = (it["latitude"] as? Double) ?: 0.0
                    ownerLongitude = (it["longitude"] as? Double) ?: 0.0
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@OwnerActivity, "Error al cargar datos del propietario", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showVehicleSelectionDialog() {
        vehiclesRef.orderByChild("ownerId").equalTo(currentOwnerId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val vehicles = mutableListOf<Pair<String, String>>()
                    val vehicleNames = mutableListOf<String>()

                    for (vehicleSnapshot in snapshot.children) {
                        val vehicleData = vehicleSnapshot.value as? Map<String, Any>
                        vehicleData?.let {
                            val vehicleId = vehicleSnapshot.key ?: ""
                            val vehicleName = (it["nombre"] as? String) ?: "Sin nombre"
                            vehicles.add(Pair(vehicleId, vehicleName))
                            vehicleNames.add(vehicleName)
                        }
                    }

                    if (vehicles.isEmpty()) {
                        Toast.makeText(this@OwnerActivity, "No tienes vehículos registrados", Toast.LENGTH_SHORT).show()
                        return
                    }

                    AlertDialog.Builder(this@OwnerActivity)
                        .setTitle("Seleccionar Vehículo")
                        .setItems(vehicleNames.toTypedArray()) { _, which ->
                            selectedVehicleId = vehicles[which].first
                            selectedVehicleName = vehicles[which].second
                            tvSelectedVehicle.text = "Vehículo seleccionado: $selectedVehicleName"

                            // Remover listener anterior si existe
                            currentRequestListener?.let {
                                serviceRequestsRef.removeEventListener(it)
                            }

                            loadCurrentRequest()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@OwnerActivity, "Error al cargar vehículos", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun loadCurrentRequest() {
        if (selectedVehicleId.isEmpty()) return

        // Usar listener en tiempo real para actualizaciones automáticas
        currentRequestListener = serviceRequestsRef.orderByChild("vehicleId").equalTo(selectedVehicleId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    currentRequest = null
                    for (requestSnapshot in snapshot.children) {
                        val requestData = requestSnapshot.value as? Map<String, Any> ?: continue
                        val status = requestData["status"] as? String ?: continue

                        // SOLUCIÓN: Solo considerar pending y accepted como solicitudes activas
                        // Ignorar completed después de calificar
                        if (status == "pending" || status == "accepted") {
                            currentRequest = requestData
                            break
                        } else if (status == "completed") {
                            val review = requestData["review"] as? Long
                            // Si está completed pero sin calificar, mostrarlo para calificar
                            if (review == null) {
                                currentRequest = requestData
                                break
                            }
                            // Si está completed y ya calificado, ignorarlo (no es solicitud activa)
                        }
                    }
                    updateRequestUI()
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@OwnerActivity, "Error al cargar solicitud actual", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun updateRequestUI() {
        llMechanicsList.removeAllViews()

        if (currentRequest != null) {
            val status = (currentRequest!!["status"] as? String) ?: ""
            val mechanicId = (currentRequest!!["mechanicId"] as? String) ?: ""
            val review = currentRequest!!["review"] as? Long

            when (status) {
                "pending", "accepted" -> {
                    val statusText = when (status) {
                        "pending" -> "Solicitud pendiente de respuesta"
                        "accepted" -> "Solicitud aceptada - Trabajo en progreso"
                        else -> "Estado desconocido"
                    }
                    tvRequestStatus.text = statusText
                    tvRequestStatus.visibility = View.VISIBLE
                    btnCancelRequest.visibility = if (status == "pending") View.VISIBLE else View.GONE

                    loadMechanicInfo(mechanicId, status)
                }
                "completed" -> {
                    if (review == null) {
                        tvRequestStatus.text = "Servicio completado - Por favor califique al mecánico"
                        tvRequestStatus.visibility = View.VISIBLE
                        btnCancelRequest.visibility = View.GONE
                        showRatingView(mechanicId)
                    } else {
                        // SOLUCIÓN: Eliminar el registro completed después de calificar
                        deleteCompletedRequestAfterRating()
                    }
                }
                else -> {
                    tvRequestStatus.visibility = View.GONE
                    btnCancelRequest.visibility = View.GONE
                    loadAvailableMechanics()
                }
            }
        } else {
            tvRequestStatus.visibility = View.GONE
            btnCancelRequest.visibility = View.GONE
            loadAvailableMechanics()
        }
    }

    // NUEVA FUNCIÓN: Eliminar registro completed después de calificar
    private fun deleteCompletedRequestAfterRating() {
        currentRequest?.let { request ->
            val requestId = (request["id"] as? String) ?: return@let

            serviceRequestsRef.child(requestId).removeValue()
                .addOnSuccessListener {
                    currentRequest = null
                    Toast.makeText(this, "Calificación enviada y solicitud finalizada", Toast.LENGTH_SHORT).show()
                    updateRequestUI()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al finalizar solicitud", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun loadMechanicInfo(mechanicId: String, status: String) {
        usersRef.child(mechanicId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val mechanicData = snapshot.value as? Map<String, Any>
                mechanicData?.let {
                    val name = (it["name"] as? String) ?: "Sin nombre"
                    val phone = (it["phone"] as? String) ?: "No disponible"
                    val educationList = it["education"] as? List<String> ?: emptyList()
                    val education = if (educationList.isNotEmpty()) educationList.joinToString(", ") else "No especificada"
                    val rating = (it["rating"] as? Number)?.toFloat() ?: 0f
                    val address = (it["address"] as? String) ?: "No disponible"

                    // Calcular distancia
                    val mechanicLatitude = (it["latitude"] as? Double) ?: 0.0
                    val mechanicLongitude = (it["longitude"] as? Double) ?: 0.0
                    val ownerLocation = Location("owner").apply {
                        latitude = ownerLatitude
                        longitude = ownerLongitude
                    }
                    val mechanicLocation = Location("mechanic").apply {
                        latitude = mechanicLatitude
                        longitude = mechanicLongitude
                    }
                    val distance = ownerLocation.distanceTo(mechanicLocation) / 1000

                    // Mostrar información del mecánico
                    val mechanicView = LayoutInflater.from(this@OwnerActivity).inflate(R.layout.item_mechanic, llMechanicsList, false)

                    mechanicView.findViewById<TextView>(R.id.tvMechanicName).text =
                        if (status == "accepted") "Mecánico asignado: $name" else "Mecánico solicitado: $name"
                    mechanicView.findViewById<TextView>(R.id.tvMechanicPhone).text = "Tel: $phone"
                    mechanicView.findViewById<TextView>(R.id.tvMechanicEducation).text = "Educación: $education"
                    mechanicView.findViewById<TextView>(R.id.tvMechanicRating).text = "Calificación: ${"%.1f".format(rating)}/5.0"
                    mechanicView.findViewById<TextView>(R.id.tvDistance).text = "Distancia: ${"%.1f".format(distance)} km"

                    val addressText = TextView(this@OwnerActivity)
                    addressText.text = "Dirección: $address"
                    addressText.setTextSize(14f)
                    addressText.setPadding(0, 8, 0, 16)

                    val btnRequest = mechanicView.findViewById<Button>(R.id.btnRequest)
                    btnRequest.text = when (status) {
                        "pending" -> "Solicitud Pendiente"
                        "accepted" -> "Solicitud Aceptada"
                        else -> "Solicitud Enviada"
                    }
                    btnRequest.isEnabled = false

                    llMechanicsList.addView(mechanicView)
                    llMechanicsList.addView(addressText)

                    // Mensaje informativo
                    val infoText = TextView(this@OwnerActivity)
                    infoText.text = when (status) {
                        "pending" -> "Esperando respuesta del mecánico..."
                        "accepted" -> "El mecánico ha aceptado tu solicitud. Trabajo en progreso."
                        else -> ""
                    }
                    infoText.setTextSize(14f)
                    infoText.setPadding(0, 16, 0, 0)
                    infoText.setTextColor(resources.getColor(android.R.color.holo_blue_dark))
                    llMechanicsList.addView(infoText)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@OwnerActivity, "Error al cargar información del mecánico", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showRatingView(mechanicId: String) {
        val ratingView = LayoutInflater.from(this).inflate(R.layout.view_rating, llMechanicsList, false)
        val ratingBar = ratingView.findViewById<RatingBar>(R.id.ratingBar)
        val btnSubmit = ratingView.findViewById<Button>(R.id.btnSubmit)
        val tvRatingTitle = ratingView.findViewById<TextView>(R.id.tvRatingTitle)

        usersRef.child(mechanicId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val mechanicData = snapshot.value as? Map<String, Any>
                mechanicData?.let {
                    val name = (it["name"] as? String) ?: "el mecánico"
                    tvRatingTitle.text = "Calificar a $name"
                }
            }

            override fun onCancelled(error: DatabaseError) {}
        })

        btnSubmit.setOnClickListener {
            val rating = ratingBar.rating.toInt()
            if (rating in 1..5) {
                submitRating(mechanicId, rating)
            } else {
                Toast.makeText(this, "Por favor seleccione una calificación entre 1 y 5", Toast.LENGTH_SHORT).show()
            }
        }

        llMechanicsList.addView(ratingView)
    }

    private fun submitRating(mechanicId: String, rating: Int) {
        val requestId = (currentRequest!!["id"] as? String) ?: return

        // Actualizar la solicitud con la calificación
        serviceRequestsRef.child(requestId).child("review").setValue(rating)
            .addOnSuccessListener {
                updateMechanicRating(mechanicId, rating)
                // No mostramos Toast aquí porque deleteCompletedRequestAfterRating mostrará uno
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al enviar calificación", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateMechanicRating(mechanicId: String, newRating: Int) {
        usersRef.child(mechanicId).child("rating").addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val currentRating = snapshot.getValue(Double::class.java) ?: 0.0
                val currentCount = snapshot.child("ratingCount").getValue(Int::class.java) ?: 0

                val newCount = currentCount + 1
                val newAverage = (currentRating * currentCount + newRating) / newCount

                val updates = mapOf(
                    "rating" to newAverage,
                    "ratingCount" to newCount
                )
                usersRef.child(mechanicId).updateChildren(updates)
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@OwnerActivity, "Error al actualizar calificación del mecánico", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun loadAvailableMechanics() {
        if (selectedVehicleId.isEmpty()) return

        llMechanicsList.removeAllViews()

        // No cargar mecánicos si hay solicitud activa
        if (currentRequest != null) {
            val status = (currentRequest!!["status"] as? String) ?: ""
            if (status == "pending" || status == "accepted" || status == "completed") {
                return
            }
        }

        usersRef.orderByChild("userType").equalTo("mechanic")
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val mechanicsWithDistance = mutableListOf<Triple<String, Map<String, Any>, Float>>()

                    for (mechanicSnapshot in snapshot.children) {
                        val mechanicData = mechanicSnapshot.value as? Map<String, Any>
                        mechanicData?.let {
                            val userType = (it["userType"] as? String) ?: ""
                            if (userType == "mechanic") {
                                val mechanicId = mechanicSnapshot.key ?: ""
                                val mechanicLatitude = (it["latitude"] as? Double) ?: 0.0
                                val mechanicLongitude = (it["longitude"] as? Double) ?: 0.0

                                val ownerLocation = Location("owner").apply {
                                    latitude = ownerLatitude
                                    longitude = ownerLongitude
                                }
                                val mechanicLocation = Location("mechanic").apply {
                                    latitude = mechanicLatitude
                                    longitude = mechanicLongitude
                                }
                                val distance = ownerLocation.distanceTo(mechanicLocation) / 1000

                                mechanicsWithDistance.add(Triple(mechanicId, it, distance))
                            }
                        }
                    }

                    mechanicsWithDistance.sortBy { it.third }

                    for ((mechanicId, mechanicData, distance) in mechanicsWithDistance) {
                        addMechanicToView(mechanicId, mechanicData, distance)
                    }

                    if (mechanicsWithDistance.isEmpty()) {
                        val noMechanicsText = TextView(this@OwnerActivity)
                        noMechanicsText.text = "No hay mecánicos registrados."
                        noMechanicsText.setTextSize(14f)
                        llMechanicsList.addView(noMechanicsText)
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@OwnerActivity, "Error al cargar mecánicos", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun addMechanicToView(mechanicId: String, mechanicData: Map<String, Any>, distance: Float) {
        val mechanicView = LayoutInflater.from(this).inflate(R.layout.item_mechanic, llMechanicsList, false)

        val name = (mechanicData["name"] as? String) ?: "Sin nombre"
        val phone = (mechanicData["phone"] as? String) ?: "No disponible"
        val educationList = mechanicData["education"] as? List<String> ?: emptyList()
        val education = if (educationList.isNotEmpty()) educationList.joinToString(", ") else "No especificada"
        val rating = (mechanicData["rating"] as? Number)?.toFloat() ?: 0f

        mechanicView.findViewById<TextView>(R.id.tvMechanicName).text = name
        mechanicView.findViewById<TextView>(R.id.tvMechanicPhone).text = "Tel: $phone"
        mechanicView.findViewById<TextView>(R.id.tvMechanicEducation).text = "Educación: $education"
        mechanicView.findViewById<TextView>(R.id.tvMechanicRating).text = "Calificación: ${"%.1f".format(rating)}/5.0"
        mechanicView.findViewById<TextView>(R.id.tvDistance).text = "Distancia: ${"%.1f".format(distance)} km"

        val btnRequest = mechanicView.findViewById<Button>(R.id.btnRequest)

        if (currentRequest != null) {
            val currentStatus = (currentRequest!!["status"] as? String) ?: ""
            if (currentStatus == "pending" || currentStatus == "accepted" || currentStatus == "completed") {
                btnRequest.text = "Solicitud Activa"
                btnRequest.isEnabled = false
            } else {
                btnRequest.setOnClickListener {
                    sendServiceRequest(mechanicId, name)
                }
            }
        } else {
            btnRequest.setOnClickListener {
                sendServiceRequest(mechanicId, name)
            }
        }

        llMechanicsList.addView(mechanicView)
    }

    private fun sendServiceRequest(mechanicId: String, mechanicName: String) {
        if (selectedVehicleId.isEmpty()) return

        val requestId = serviceRequestsRef.push().key ?: return

        val requestData = mapOf(
            "id" to requestId,
            "ownerId" to currentOwnerId,
            "mechanicId" to mechanicId,
            "vehicleId" to selectedVehicleId,
            "status" to "pending",
            "createdAt" to System.currentTimeMillis(),
            "acceptedAt" to null,
            "completedAt" to null,
            "rating" to null,
            "review" to null
        )

        serviceRequestsRef.child(requestId).setValue(requestData)
            .addOnSuccessListener {
                Toast.makeText(this, "Solicitud enviada a $mechanicName", Toast.LENGTH_SHORT).show()
                // No need to call loadCurrentRequest() because the real-time listener will update automatically
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al enviar solicitud", Toast.LENGTH_SHORT).show()
            }
    }

    private fun cancelCurrentRequest() {
        currentRequest?.let { request ->
            val requestId = (request["id"] as? String) ?: return@let

            serviceRequestsRef.child(requestId).removeValue()
                .addOnSuccessListener {
                    Toast.makeText(this, "Solicitud cancelada", Toast.LENGTH_SHORT).show()
                    // No need to set currentRequest = null because the real-time listener will update
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al cancelar solicitud", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun logoutUser() {
        try {
            // Remover listeners antes de cerrar sesión
            currentRequestListener?.let {
                serviceRequestsRef.removeEventListener(it)
            }

            Firebase.auth.signOut()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al cerrar sesión", Toast.LENGTH_SHORT).show()
        }
    }
}