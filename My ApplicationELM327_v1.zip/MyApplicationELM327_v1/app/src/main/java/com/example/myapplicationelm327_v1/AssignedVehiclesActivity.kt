package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class AssignedVehiclesActivity : AppCompatActivity() {

    private lateinit var btnBack: Button
    private lateinit var containerVehicles: LinearLayout
    private lateinit var progressBar: ProgressBar
    private lateinit var tvEmptyMessage: TextView

    private val auth = FirebaseAuth.getInstance()
    private val database = Firebase.database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_assigned_vehicles)
        supportActionBar?.hide()

        initViews()
        loadAssignedVehicles()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        containerVehicles = findViewById(R.id.containerVehicles)
        progressBar = findViewById(R.id.progressBar)
        tvEmptyMessage = findViewById(R.id.tvEmptyMessage)

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadAssignedVehicles() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            progressBar.visibility = View.VISIBLE
            containerVehicles.visibility = View.GONE
            tvEmptyMessage.visibility = View.GONE

            val vehiclesRef = database.getReference("vehicles")

            vehiclesRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    progressBar.visibility = View.GONE

                    val assignedVehicles = mutableListOf<Vehicle>()

                    snapshot.children.forEach { vehicleSnapshot ->
                        val vehicle = vehicleSnapshot.getValue(Vehicle::class.java)
                        vehicle?.let {
                            // Verificar si este vehículo está asignado al mecánico actual
                            if (currentUser.uid in it.assignedMechanics) {
                                assignedVehicles.add(it)
                            }
                        }
                    }

                    if (assignedVehicles.isNotEmpty()) {
                        displayVehicles(assignedVehicles)
                    } else {
                        showEmptyMessage()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    progressBar.visibility = View.GONE
                    Toast.makeText(
                        this@AssignedVehiclesActivity,
                        "❌ Error cargando vehículos: ${error.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                    showEmptyMessage()
                }
            })
        } else {
            Toast.makeText(this, "❌ No hay usuario autenticado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun displayVehicles(vehicles: List<Vehicle>) {
        containerVehicles.removeAllViews()
        containerVehicles.visibility = View.VISIBLE

        vehicles.forEach { vehicle ->
            addVehicleCard(vehicle)
        }
    }

    private fun addVehicleCard(vehicle: Vehicle) {
        val card = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 0, 0, 16)
            }
            radius = 12f
            cardElevation = 4f
            setContentPadding(16, 16, 16, 16)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Información básica del vehículo - Ahora desde vpicData
        val tvBasicInfo = TextView(this).apply {
            text = "🚗 ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo} (${vehicle.vpicData.año})"
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        val tvDetails = TextView(this).apply {
            text = "🎨 Color: ${vehicle.vpicData.color}\n🔢 VIN: ${vehicle.vin}"
            textSize = 14f
            setPadding(0, 8, 0, 0)
        }

        // Botones de acción
        val buttonsLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(0, 16, 0, 0)
            }
        }

        val btnDiagnostic = Button(this).apply {
            text = "🔧 Diagnosticar"
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
                setMargins(0, 0, 8, 0)
            }
            setOnClickListener {
                // Guardar el VIN actual para usarlo en otros módulos
                ELM327Manager.currentVIN = vehicle.vin

                val intent = Intent(this@AssignedVehiclesActivity, DiagnosticActivity::class.java)
                startActivity(intent)
            }
        }

        val btnDetails = Button(this).apply {
            text = "📊 Detalles"
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
                setMargins(8, 0, 0, 0)
            }
            setOnClickListener {
                showVehicleDetails(vehicle)
            }
        }

        buttonsLayout.addView(btnDiagnostic)
        buttonsLayout.addView(btnDetails)

        layout.addView(tvBasicInfo)
        layout.addView(tvDetails)
        layout.addView(buttonsLayout)
        card.addView(layout)

        containerVehicles.addView(card)
    }

    private fun showVehicleDetails(vehicle: Vehicle) {
        Toast.makeText(
            this,
            "Detalles:\nMarca: ${vehicle.vpicData.marca}\nModelo: ${vehicle.vpicData.modelo}\nAño: ${vehicle.vpicData.año}\nColor: ${vehicle.vpicData.color}\nVIN: ${vehicle.vin}",
            Toast.LENGTH_LONG
        ).show()
    }

    private fun showEmptyMessage() {
        containerVehicles.visibility = View.GONE
        tvEmptyMessage.visibility = View.VISIBLE
        tvEmptyMessage.text = "No tienes vehículos asignados actualmente"
    }

    data class Vehicle(
        val id: String = "",
        val ownerId: String = "",
        val nombre: String = "",
        val vin: String = "",
        val assignedMechanics: List<String> = emptyList(),
        val vpicData: VpicData = VpicData(),
        val sensorData: SensorData = SensorData(),
        val errorData: ErrorData = ErrorData(),
        val createdAt: Long = 0L
    )

    data class VpicData(
        val marca: String = "",
        val modelo: String = "",
        val año: Int = 0,
        val color: String = "",
        val motor: String = "",
        val transmision: String = "",
        val combustible: String = "",
        val ultimaActualizacion: Long = 0L
    )

    data class SensorData(
        val rpm: String = "",
        val cargaMotor: String = "",
        val avanceEncendido: String = "",
        val tempRefrigerante: String = "",
        val tempAireAdmision: String = "",
        val tempAireAmbiental: String = "",
        val nivelCombustible: String = "",
        val presionCombustible: String = "",
        val tasaConsumo: String = "",
        val presionMAP: String = "",
        val presionBarometrica: String = "",
        val velocidad: String = "",
        val posicionAcelerador: String = "",
        val ultimaLectura: Long = 0L
    )

    data class ErrorData(
        val codigosActivos: List<String> = emptyList(),
        val codigosPendientes: List<String> = emptyList(),
        val ultimaLectura: Long = 0L
    )
}