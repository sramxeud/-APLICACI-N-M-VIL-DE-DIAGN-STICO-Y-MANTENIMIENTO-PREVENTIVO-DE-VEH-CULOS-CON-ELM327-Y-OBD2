package com.example.myapplicationelm327_v1

import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.ktx.Firebase

class MechanicActivity : AppCompatActivity() {

    private lateinit var tvRequestsTitle: TextView
    private lateinit var llRequestsList: LinearLayout
    private lateinit var scrollViewRequests: ScrollView
    private lateinit var tvOwnerInfoTitle: TextView
    private lateinit var scrollViewOwnerInfo: ScrollView
    private lateinit var llOwnerInfo: LinearLayout
    private lateinit var tvOwnerName: TextView
    private lateinit var tvOwnerEmail: TextView
    private lateinit var tvOwnerPhone: TextView
    private lateinit var tvOwnerAddress: TextView
    private lateinit var btnFinishWork: Button
    private lateinit var btnLogout: Button
    private lateinit var btnContinue: Button
    private lateinit var btnChangeLocation: Button

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance()
    private val usersRef = database.getReference("users")
    private val vehiclesRef = database.getReference("vehicles")
    private val serviceRequestsRef = database.getReference("service_requests")
    private val assignmentsRef = database.getReference("assignments")

    private var currentMechanicId: String = ""
    private var currentAcceptedRequest: Map<String, Any>? = null
    private var currentOwnerInfo: Map<String, Any>? = null

    // Variables para ubicación
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback
    private val LOCATION_PERMISSION_REQUEST_CODE = 1002

    // Listener para actualizaciones en tiempo real
    private var requestsListener: ValueEventListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mechanic)

        supportActionBar?.hide()

        initViews()
        setupLocationServices()
        setupClickListeners()

        currentMechanicId = auth.currentUser?.uid ?: ""
        if (currentMechanicId.isEmpty()) {
            Toast.makeText(this, "Error: Usuario no autenticado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        setupRealTimeListeners()
    }

    override fun onDestroy() {
        super.onDestroy()
        // Remover listeners cuando la actividad se destruya
        requestsListener?.let {
            serviceRequestsRef.removeEventListener(it)
        }
    }

    private fun initViews() {
        tvRequestsTitle = findViewById(R.id.tvRequestsTitle)
        llRequestsList = findViewById(R.id.llRequestsList)
        scrollViewRequests = findViewById(R.id.scrollViewRequests)
        tvOwnerInfoTitle = findViewById(R.id.tvOwnerInfoTitle)
        scrollViewOwnerInfo = findViewById(R.id.scrollViewOwnerInfo)
        llOwnerInfo = findViewById(R.id.llOwnerInfo)
        tvOwnerName = findViewById(R.id.tvOwnerName)
        tvOwnerEmail = findViewById(R.id.tvOwnerEmail)
        tvOwnerPhone = findViewById(R.id.tvOwnerPhone)
        tvOwnerAddress = findViewById(R.id.tvOwnerAddress)
        btnFinishWork = findViewById(R.id.btnFinishWork)
        btnLogout = findViewById(R.id.btnLogout)
        btnContinue = findViewById(R.id.btnContinue)
        btnChangeLocation = findViewById(R.id.btnChangeLocation)
    }

    private fun setupClickListeners() {
        btnFinishWork.setOnClickListener {
            finishWork()
        }

        btnLogout.setOnClickListener {
            logoutUser()
        }

        btnContinue.setOnClickListener {
            val intent = Intent(this, MechanicMainActivity::class.java)
            startActivity(intent)
            finish()
        }

        btnChangeLocation.setOnClickListener {
            showLocationOptionsDialog()
        }
    }

    private fun setupLocationServices() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationRequest = LocationRequest.create().apply {
            interval = 10000
            fastestInterval = 5000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    updateUserLocationInFirebase(location.latitude, location.longitude)
                    fusedLocationClient.removeLocationUpdates(this)
                }
            }
        }
    }

    private fun showLocationOptionsDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_location_options)
        dialog.setCancelable(true)
        dialog.window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val btnCurrentLocation = dialog.findViewById<Button>(R.id.btnCurrentLocation)
        val btnManualLocation = dialog.findViewById<Button>(R.id.btnManualLocation)
        val btnCancel = dialog.findViewById<Button>(R.id.btnCancel)

        btnCurrentLocation.setOnClickListener {
            dialog.dismiss()
            getCurrentLocation()
        }

        btnManualLocation.setOnClickListener {
            dialog.dismiss()
            showManualLocationDialog()
        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun getCurrentLocation() {
        if (checkLocationPermissions()) {
            btnChangeLocation.text = "Obteniendo ubicación..."
            btnChangeLocation.isEnabled = false

            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())

            // Timeout por si no obtiene ubicación en 10 segundos
            Handler(Looper.getMainLooper()).postDelayed({
                fusedLocationClient.removeLocationUpdates(locationCallback)
                btnChangeLocation.text = "📍 Cambiar mi ubicación"
                btnChangeLocation.isEnabled = true
                Toast.makeText(this, "No se pudo obtener la ubicación", Toast.LENGTH_SHORT).show()
            }, 10000)

        } else {
            requestLocationPermissions()
        }
    }

    private fun showManualLocationDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_manual_location)
        dialog.setCancelable(true)
        dialog.window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val etManualLat = dialog.findViewById<EditText>(R.id.etManualLat)
        val etManualLng = dialog.findViewById<EditText>(R.id.etManualLng)
        val btnConfirmManual = dialog.findViewById<Button>(R.id.btnConfirmManual)
        val btnCancelManual = dialog.findViewById<Button>(R.id.btnCancelManual)

        btnConfirmManual.setOnClickListener {
            val lat = etManualLat.text.toString().trim()
            val lng = etManualLng.text.toString().trim()

            if (lat.isNotEmpty() && lng.isNotEmpty()) {
                try {
                    val latitude = lat.toDouble()
                    val longitude = lng.toDouble()

                    if (latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180) {
                        updateUserLocationInFirebase(latitude, longitude)
                        dialog.dismiss()
                        Toast.makeText(this, "📍 Ubicación actualizada", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Coordenadas inválidas", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: NumberFormatException) {
                    Toast.makeText(this, "Formato de coordenadas inválido", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Ingresa ambas coordenadas", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancelManual.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun updateUserLocationInFirebase(latitude: Double, longitude: Double) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val updates = mapOf(
                "latitude" to latitude,
                "longitude" to longitude,
                "updatedAt" to System.currentTimeMillis()
            )

            usersRef.child(currentUser.uid).updateChildren(updates)
                .addOnSuccessListener {
                    btnChangeLocation.text = "📍 Cambiar mi ubicación"
                    btnChangeLocation.isEnabled = true
                    Toast.makeText(this, "✅ Ubicación actualizada correctamente", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener {
                    btnChangeLocation.text = "📍 Cambiar mi ubicación"
                    btnChangeLocation.isEnabled = true
                    Toast.makeText(this, "❌ Error al actualizar ubicación", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun checkLocationPermissions(): Boolean {
        return (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }

    private fun requestLocationPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Se necesitan permisos de ubicación", Toast.LENGTH_SHORT).show()
                showManualLocationDialog()
            }
        }
    }

    private fun setupRealTimeListeners() {
        // Listener en tiempo real para solicitudes
        requestsListener = serviceRequestsRef.orderByChild("mechanicId").equalTo(currentMechanicId)
            .addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    loadPendingRequests(snapshot)
                    loadAcceptedRequest(snapshot)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@MechanicActivity, "Error al cargar solicitudes", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun loadPendingRequests(snapshot: DataSnapshot) {
        llRequestsList.removeAllViews()
        var hasPendingRequests = false

        for (requestSnapshot in snapshot.children) {
            val requestData = requestSnapshot.value as? Map<String, Any>
            requestData?.let {
                val status = (it["status"] as? String) ?: ""
                if (status == "pending") {
                    hasPendingRequests = true
                    addRequestToView(requestSnapshot.key, it)
                }
            }
        }

        if (!hasPendingRequests) {
            val noRequestsText = TextView(this@MechanicActivity)
            noRequestsText.text = "No hay solicitudes pendientes."
            noRequestsText.setTextSize(14f)
            noRequestsText.setPadding(16, 16, 16, 16)
            llRequestsList.addView(noRequestsText)
        }
    }

    private fun addRequestToView(requestId: String?, requestData: Map<String, Any>) {
        if (requestId == null) return

        val requestView = LayoutInflater.from(this).inflate(R.layout.item_request, llRequestsList, false)

        val ownerId = requestData["ownerId"] as? String ?: ""
        val vehicleId = requestData["vehicleId"] as? String ?: ""

        // Cargar información del propietario y vehículo para mostrar en la solicitud
        usersRef.child(ownerId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(ownerSnapshot: DataSnapshot) {
                val ownerData = ownerSnapshot.value as? Map<String, Any>
                ownerData?.let {
                    val ownerName = (it["name"] as? String) ?: "Sin nombre"

                    vehiclesRef.child(vehicleId).addListenerForSingleValueEvent(object : ValueEventListener {
                        override fun onDataChange(vehicleSnapshot: DataSnapshot) {
                            val vehicleData = vehicleSnapshot.value as? Map<String, Any>
                            vehicleData?.let { vehicle ->
                                val vehicleName = (vehicle["nombre"] as? String) ?: "Sin nombre"

                                requestView.findViewById<TextView>(R.id.tvRequestInfo).text =
                                    "Solicitud de: $ownerName\nVehículo: $vehicleName"

                                val btnAccept = requestView.findViewById<Button>(R.id.btnAccept)
                                val btnReject = requestView.findViewById<Button>(R.id.btnReject)

                                btnAccept.setOnClickListener {
                                    acceptRequest(requestId, requestData, ownerId, vehicleId)
                                }

                                btnReject.setOnClickListener {
                                    rejectRequest(requestId)
                                }
                            }
                        }

                        override fun onCancelled(error: DatabaseError) {
                            Toast.makeText(this@MechanicActivity, "Error al cargar vehículo", Toast.LENGTH_SHORT).show()
                        }
                    })
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@MechanicActivity, "Error al cargar propietario", Toast.LENGTH_SHORT).show()
            }
        })

        llRequestsList.addView(requestView)
    }

    private fun loadAcceptedRequest(snapshot: DataSnapshot) {
        currentAcceptedRequest = null
        for (requestSnapshot in snapshot.children) {
            val requestData = requestSnapshot.value as? Map<String, Any> ?: continue
            val status = requestData["status"] as? String ?: continue

            if (status == "accepted") {
                currentAcceptedRequest = requestData
                break
            }
        }

        updateAcceptedRequestUI()
    }

    private fun acceptRequest(requestId: String, requestData: Map<String, Any>, ownerId: String, vehicleId: String) {
        // Actualizar la solicitud a "accepted"
        val updates = mapOf(
            "status" to "accepted",
            "acceptedAt" to System.currentTimeMillis()
        )

        serviceRequestsRef.child(requestId).updateChildren(updates)
            .addOnSuccessListener {
                // Crear un assignment
                createAssignment(requestId, ownerId, vehicleId)
                Toast.makeText(this, "Solicitud aceptada", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al aceptar solicitud", Toast.LENGTH_SHORT).show()
            }
    }

    private fun createAssignment(requestId: String, ownerId: String, vehicleId: String) {
        val assignmentId = assignmentsRef.push().key ?: return

        val assignmentData = mapOf(
            "id" to assignmentId,
            "requestId" to requestId,
            "ownerId" to ownerId,
            "mechanicId" to currentMechanicId,
            "vehicleId" to vehicleId,
            "assignedAt" to System.currentTimeMillis(),
            "status" to "active",
            "permissions" to listOf("read", "diagnose", "clear_codes")
        )

        assignmentsRef.child(assignmentId).setValue(assignmentData)
            .addOnFailureListener {
                Toast.makeText(this, "Error al crear assignment", Toast.LENGTH_SHORT).show()
            }
    }

    private fun rejectRequest(requestId: String) {
        serviceRequestsRef.child(requestId).removeValue()
            .addOnSuccessListener {
                Toast.makeText(this, "Solicitud rechazada", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al rechazar solicitud", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateAcceptedRequestUI() {
        if (currentAcceptedRequest != null) {
            // Mostrar la sección de información del propietario
            scrollViewRequests.visibility = View.GONE
            tvRequestsTitle.visibility = View.GONE
            tvOwnerInfoTitle.visibility = View.VISIBLE
            scrollViewOwnerInfo.visibility = View.VISIBLE

            // Cargar información del propietario
            val ownerId = currentAcceptedRequest!!["ownerId"] as? String ?: ""
            usersRef.child(ownerId).addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val ownerData = snapshot.value as? Map<String, Any>
                    ownerData?.let {
                        currentOwnerInfo = it
                        val name = (it["name"] as? String) ?: "No disponible"
                        val email = (it["email"] as? String) ?: "No disponible"
                        val phone = (it["phone"] as? String) ?: "No disponible"
                        val address = (it["address"] as? String) ?: "No disponible"

                        tvOwnerName.text = "Nombre: $name"
                        tvOwnerEmail.text = "Email: $email"
                        tvOwnerPhone.text = "Teléfono: $phone"
                        tvOwnerAddress.text = "Dirección: $address"
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@MechanicActivity, "Error al cargar información del propietario", Toast.LENGTH_SHORT).show()
                }
            })

        } else {
            // Ocultar la sección de información del propietario
            scrollViewRequests.visibility = View.VISIBLE
            tvRequestsTitle.visibility = View.VISIBLE
            tvOwnerInfoTitle.visibility = View.GONE
            scrollViewOwnerInfo.visibility = View.GONE
        }
    }

    private fun finishWork() {
        currentAcceptedRequest?.let { request ->
            val requestId = request["id"] as? String ?: return@let

            // Actualizar la solicitud a "completed"
            val updates = mapOf(
                "status" to "completed",
                "completedAt" to System.currentTimeMillis()
            )

            serviceRequestsRef.child(requestId).updateChildren(updates)
                .addOnSuccessListener {
                    Toast.makeText(this, "Trabajo finalizado. Esperando calificación del propietario.", Toast.LENGTH_SHORT).show()

                    // Eliminar el assignment (según lo requerido)
                    deleteAssignmentForRequest(requestId)

                    currentAcceptedRequest = null
                    updateAcceptedRequestUI()
                }
                .addOnFailureListener {
                    Toast.makeText(this, "Error al finalizar trabajo", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun deleteAssignmentForRequest(requestId: String) {
        assignmentsRef.orderByChild("requestId").equalTo(requestId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (assignmentSnapshot in snapshot.children) {
                        assignmentSnapshot.ref.removeValue()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    // No hacemos nada si falla
                }
            })
    }

    private fun logoutUser() {
        try {
            Firebase.auth.signOut()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()

            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al cerrar sesión", Toast.LENGTH_SHORT).show()
        }
    }
}