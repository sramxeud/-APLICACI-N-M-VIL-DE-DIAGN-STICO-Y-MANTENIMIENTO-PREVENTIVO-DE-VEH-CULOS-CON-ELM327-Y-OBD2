package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class AddVehicleActivity : AppCompatActivity() {

    private lateinit var etNombre: EditText
    private lateinit var btnGuardar: Button
    private lateinit var btnCancelar: Button

    private val auth = FirebaseAuth.getInstance()
    private val database = Firebase.database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_vehicle)
        supportActionBar?.hide()

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        etNombre = findViewById(R.id.etNombre)
        btnGuardar = findViewById(R.id.btnGuardar)
        btnCancelar = findViewById(R.id.btnCancelar)


    }

    private fun setupClickListeners() {
        btnGuardar.setOnClickListener {
            guardarVehiculo()
        }

        btnCancelar.setOnClickListener {
            finish()
        }
    }

    private fun guardarVehiculo() {
        val nombre = etNombre.text.toString().trim()

        if (validarDatos(nombre)) {
            val currentUser = auth.currentUser
            if (currentUser != null) {
                val vehicleRef = database.getReference("vehicles").push()
                val vehicleId = vehicleRef.key ?: ""

                // Crear vehículo sin VIN (se asignará en VpicActivity)
                val vehicleData = Vehicle(
                    id = vehicleId,
                    ownerId = currentUser.uid,
                    nombre = nombre,
                    vin = "", // VIN vacío inicialmente
                    assignedMechanics = emptyList(),
                    vpicData = VpicData(),
                    sensorData = SensorData(),
                    errorData = ErrorData(),
                    createdAt = System.currentTimeMillis()
                )

                btnGuardar.isEnabled = false
                btnGuardar.text = "Guardando..."

                vehicleRef.setValue(vehicleData).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(this, "✅ Vehículo agregado exitosamente", Toast.LENGTH_SHORT).show()

                        // Redirigir a VpicActivity para asignar el VIN
                        val intent = Intent(this, VpicActivity::class.java)
                        intent.putExtra("VEHICLE_ID", vehicleId) // Pasar ID del vehículo
                        startActivity(intent)
                        finish()
                    } else {
                        btnGuardar.isEnabled = true
                        btnGuardar.text = "Guardar Vehículo"
                        Toast.makeText(this, "❌ Error guardando vehículo: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    private fun validarDatos(nombre: String): Boolean {
        if (nombre.isEmpty()) {
            etNombre.error = "Ingresa un nombre para el vehículo"
            return false
        }
        return true
    }

    // Data classes (se mantienen igual)
    data class Vehicle(
        val id: String = "",
        val ownerId: String = "",
        val nombre: String = "",
        val vin: String = "",
        val assignedMechanics: List<String> = emptyList(),
        val vpicData: VpicData = VpicData(),
        val sensorData: SensorData = SensorData(),
        val errorData: ErrorData = ErrorData(),
        val createdAt: Long = 0L
    )

    data class VpicData(
        val marca: String = "",
        val modelo: String = "",
        val año: Int = 0,
        val color: String = "",
        val motor: String = "",
        val transmision: String = "",
        val combustible: String = "",
        val ultimaActualizacion: Long = 0L
    )

    data class SensorData(
        val rpm: String = "",
        val cargaMotor: String = "",
        val avanceEncendido: String = "",
        val tempRefrigerante: String = "",
        val tempAireAdmision: String = "",
        val tempAireAmbiental: String = "",
        val nivelCombustible: String = "",
        val presionCombustible: String = "",
        val tasaConsumo: String = "",
        val presionMAP: String = "",
        val presionBarometrica: String = "",
        val velocidad: String = "",
        val posicionAcelerador: String = "",
        val ultimaLectura: Long = 0L
    )

    data class ErrorData(
        val codigosActivos: List<String> = emptyList(),
        val codigosPendientes: List<String> = emptyList(),
        val ultimaLectura: Long = 0L
    )
}