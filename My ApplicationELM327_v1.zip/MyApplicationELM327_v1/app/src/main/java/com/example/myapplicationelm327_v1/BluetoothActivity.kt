package com.example.myapplicationelm327_v1

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.view.MenuItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.ktx.Firebase

class BluetoothActivity : AppCompatActivity() {
    private lateinit var btnLogout: Button

    private lateinit var tvStatus: TextView
    private lateinit var btnSearchDevices: Button
    private lateinit var lvPairedDevices: ListView

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        BluetoothAdapter.getDefaultAdapter()
    }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val allGranted = permissions.all { it.value }
        if (allGranted) {
            checkBluetoothEnabled()
        } else {
            updateStatus("Permisos denegados")
            Toast.makeText(this, "Permisos de Bluetooth denegados", Toast.LENGTH_LONG).show()
        }
    }


    private val enableBluetoothLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK) {
            showBluetoothDevices()
        } else {
            updateStatus("Bluetooth rechazado")
            Toast.makeText(this, "Bluetooth necesario para conectar", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bluetooth)

        // Inicializar la fábrica
        OBD2ServiceFactory.initialize(this)

        initViews()
        setupButtons()
        updateStatus("Listo para buscar dispositivos")

        // Mostrar modo actual en el status
        val mode = if (OBD2ServiceFactory.isSimulationMode()) "SIMULACIÓN" else "REAL"
        updateStatus("Listo ($mode)")
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_settings -> {
                startActivity(Intent(this, SimulationSettingsActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun initViews() {
        tvStatus = findViewById(R.id.tvStatus)
        btnSearchDevices = findViewById(R.id.btnSearchDevices)
        lvPairedDevices = findViewById(R.id.lvPairedDevices)
        btnLogout = findViewById(R.id.btnLogout)  // Nuevo botón

    }


    private fun setupButtons() {

        btnSearchDevices.setOnClickListener {
            checkBluetoothPermissions()
        }

        lvPairedDevices.setOnItemClickListener { _, _, position, _ ->
            val devices = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()
            if (position < devices.size) {
                val device = devices[position]
                val intent = Intent(this, ProtocolSelectionActivity::class.java)
                intent.putExtra("DEVICE_ADDRESS", device.address)
                intent.putExtra("DEVICE_NAME", device.name ?: "Dispositivo desconocido")
                startActivity(intent)
            }
        }
        btnLogout.setOnClickListener {
            logoutUser()
        }

    }

    private fun logoutUser() {
        try {
            Firebase.auth.signOut()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()

            // Regresar a LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al cerrar sesión", Toast.LENGTH_SHORT).show()
        }
    }

    private fun checkBluetoothPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN
            )
        } else {
            arrayOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.BLUETOOTH_ADMIN,
                Manifest.permission.ACCESS_FINE_LOCATION
            )
        }

        val allPermissionsGranted = permissions.all { permission ->
            ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        }

        if (allPermissionsGranted) {
            checkBluetoothEnabled()
        } else {
            requestPermissionLauncher.launch(permissions)
        }
    }

    private fun checkBluetoothEnabled() {
        if (bluetoothAdapter == null) {
            updateStatus("No hay Bluetooth")
            Toast.makeText(this, "Bluetooth no disponible", Toast.LENGTH_LONG).show()
            return
        }

        if (bluetoothAdapter?.isEnabled == true) {
            showBluetoothDevices()
        } else {
            updateStatus("Activando Bluetooth...")
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            enableBluetoothLauncher.launch(enableBtIntent)
        }
    }

    private fun showBluetoothDevices() {
        val pairedDevices = bluetoothAdapter?.bondedDevices?.toList() ?: emptyList()

        if (pairedDevices.isEmpty()) {
            updateStatus("No hay dispositivos")
            Toast.makeText(this, "No hay dispositivos emparejados", Toast.LENGTH_SHORT).show()
        } else {
            updateStatus("${pairedDevices.size} dispositivos encontrados")
            showDeviceList(pairedDevices)
        }
    }

    private fun showDeviceList(devices: List<BluetoothDevice>) {
        val deviceNames = devices.map { device ->
            device.name ?: "Dispositivo desconocido (${device.address})"
        }
        val adapter = ArrayAdapter(this, R.layout.list_item_device, deviceNames)
        lvPairedDevices.adapter = adapter
    }

    private fun updateStatus(message: String) {
        tvStatus.text = "Estado: $message"
    }
}