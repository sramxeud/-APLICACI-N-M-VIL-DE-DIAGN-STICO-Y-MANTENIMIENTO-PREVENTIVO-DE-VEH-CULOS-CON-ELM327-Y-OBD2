package com.example.myapplicationelm327_v1

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.util.Log
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.util.*

class ELM327Connection(private val device: BluetoothDevice) {

    companion object {
        private const val TAG = "ELM327Connection"
        private val ELM_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
        private const val CONNECTION_TIMEOUT = 10000 // 10 segundos
    }

    private var socket: BluetoothSocket? = null
    private var inputStream: InputStream? = null
    private var outputStream: OutputStream? = null
    private var isConnected = false

    enum class Protocol(val code: String, val displayName: String) {
        AUTO("0", "Auto"),
        SAE_J1850_PWM("1", "SAE J1850 PWM"),
        SAE_J1850_VPW("2", "SAE J1850 VPW"),
        ISO_9141_2("3", "ISO 9141-2"),
        ISO_14230_4_KWP("4", "ISO 14230-4 KWP"),
        ISO_14230_4_KWP_FAST("5", "ISO 14230-4 KWP (5 baud)"),
        ISO_15765_4_CAN_11BIT("6", "ISO 15765-4 CAN (11 bit)"),
        ISO_15765_4_CAN_29BIT("7", "ISO 15765-4 CAN (29 bit)"),
        SAE_J1939("8", "SAE J1939")
    }

    var currentProtocol: Protocol = Protocol.AUTO
    var connectionListener: ConnectionListener? = null

    interface ConnectionListener {
        fun onConnectionSuccess()
        fun onConnectionError(error: String)
        fun onDataReceived(data: String)
        fun onDisconnected()
    }

    fun connect() {
        Thread {
            try {
                connectionListener?.onConnectionError("Conectando...")

                socket = device.createRfcommSocketToServiceRecord(ELM_UUID)
                socket?.connect()

                inputStream = socket?.inputStream
                outputStream = socket?.outputStream
                isConnected = true

                // Verificar que realmente estamos conectados
                if (isActuallyConnected()) {
                    configureELM327()
                    connectionListener?.onConnectionSuccess()
                    Log.d(TAG, "Conexión exitosa con ELM327")
                } else {
                    throw IOException("Conexión establecida pero no funcional")
                }

            } catch (e: IOException) {
                isConnected = false
                connectionListener?.onConnectionError("Error de conexión: ${e.message}")
                Log.e(TAG, "Error de conexión", e)
                disconnect()
            } catch (e: Exception) {
                isConnected = false
                connectionListener?.onConnectionError("Error: ${e.message}")
                Log.e(TAG, "Error general", e)
                disconnect()
            }
        }.start()
    }

    private fun isActuallyConnected(): Boolean {
        return try {
            socket?.isConnected == true && inputStream != null && outputStream != null
        } catch (e: Exception) {
            false
        }
    }

    private fun configureELM327() {
        try {
            Thread.sleep(2000)
            sendCommand("ATZ", 3000)
            Thread.sleep(2000)
            sendCommand("ATE0", 1000)
            sendCommand("ATH1", 1000)
            sendCommand("ATL0", 1000)

            // Configurar AUTO inicialmente
            setProtocol(Protocol.AUTO)

            // Si el usuario quiere otro protocolo, cambiarlo después
            /*if (currentProtocol != Protocol.AUTO) {
                Thread.sleep(1000)
                setProtocol(currentProtocol)
            }*/

        } catch (e: Exception) {
            Log.e(TAG, "Error en configuración", e)
            throw e
        }
    }

    fun setProtocol(protocol: Protocol): Boolean {
        return try {
            val response = sendCommand("ATSP${protocol.code}", 2000)
            if (response.contains("OK") || response.contains(protocol.code)) {
                currentProtocol = protocol
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    @Throws(IOException::class)
    fun sendCommand(command: String, timeout: Int = 1000): String {
        if (!isConnected) throw IOException("No conectado")

        try {
            outputStream?.write("$command\r".toByteArray())
            outputStream?.flush()

            return readResponse(timeout)
        } catch (e: Exception) {
            isConnected = false
            throw IOException("Error enviando comando: ${e.message}")
        }
    }

    private fun readResponse(timeout: Int): String {
        val buffer = ByteArray(1024)
        val startTime = System.currentTimeMillis()
        var bytesRead = 0

        while (System.currentTimeMillis() - startTime < timeout) {
            val available = inputStream?.available() ?: 0
            if (available > 0) {
                bytesRead = inputStream?.read(buffer) ?: 0
                break
            }
            Thread.sleep(100)
        }

        return if (bytesRead > 0) {
            String(buffer, 0, bytesRead).trim()
        } else {
            "NO_RESPONSE"
        }
    }

    fun disconnect() {
        try {
            inputStream?.close()
            outputStream?.close()
            socket?.close()
        } catch (e: IOException) {
            Log.e(TAG, "Error al desconectar", e)
        } finally {
            isConnected = false
            connectionListener?.onDisconnected()
        }
    }

    fun isConnected(): Boolean = isConnected && isActuallyConnected()
}