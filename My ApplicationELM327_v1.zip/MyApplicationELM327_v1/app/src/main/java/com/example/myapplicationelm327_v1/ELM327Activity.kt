package com.example.myapplicationelm327_v1
/*
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class ELM327Activity : AppCompatActivity(), ELM327Connection.ConnectionListener {

    private lateinit var tvDeviceName: TextView
    private lateinit var tvStatus: TextView
    private lateinit var tvProtocol: TextView
    private lateinit var tvVehicleData: TextView
    private lateinit var btnDisconnect: Button
    private lateinit var btnReadData: Button

    private var deviceAddress: String? = null
    private var deviceName: String? = null
    private var protocolName: String? = null
    private var isConnected: Boolean = false
    private var isSimulationMode: Boolean = false

    private var obd2Service: IOBD2Service? = null
    private val handler = Handler(Looper.getMainLooper())
    private var isReading = false

    // Referencia a Firebase Database
    private val database = FirebaseDatabase.getInstance()
    private val vehiculosRef = database.getReference("vehiculo")

    // Lista de PIDs básicos para lectura
    private val basicPIDs = listOf(
        "010C", // RPM
        "010D", // Vehicle Speed
        "0105", // Coolant Temp
        "0104", // Engine Load
        "010B", // MAP Pressure
        "010A", // Fuel Pressure
        "010F", // Intake Air Temp
        "010E", // Timing Advance
        "0111", // Throttle Position
        "012F", // Fuel Level
        "0133", // Barometric Pressure
        "0146", // Ambient Air Temp
        "015E"  // Engine Fuel Rate
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_elm327)

        // Obtener datos de la conexión
        deviceAddress = intent.getStringExtra("DEVICE_ADDRESS")
        deviceName = intent.getStringExtra("DEVICE_NAME")
        protocolName = intent.getStringExtra("PROTOCOL")
        isConnected = intent.getBooleanExtra("IS_CONNECTED", false)
        isSimulationMode = intent.getBooleanExtra("IS_SIMULATION", false)

        initViews()
        setupUI()
        setupButtons()
        initializeConnection()

        // Cargar datos de Firebase
        loadFirebaseData()
    }

    private fun initViews() {
        tvDeviceName = findViewById(R.id.tvDeviceName)
        tvStatus = findViewById(R.id.tvStatus)
        tvProtocol = findViewById(R.id.tvProtocol)
        tvVehicleData = findViewById(R.id.tvVehicleData)
        btnDisconnect = findViewById(R.id.btnDisconnect)
        btnReadData = findViewById(R.id.btnReadData)
    }

    private fun setupUI() {
        tvDeviceName.text = "Dispositivo: $deviceName"
        tvProtocol.text = "Protocolo: $protocolName"

        val modeText = if (isSimulationMode) " (SIMULACIÓN)" else ""
        if (isConnected) {
            tvStatus.text = "Estado: Conectado$modeText"
            tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
        } else {
            tvStatus.text = "Estado: Desconectado$modeText"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
        }
        // En setupUI() o onCreate()
        val btnTestAI = findViewById<Button>(R.id.btnTestAI)
        btnTestAI.setOnClickListener {
            val intent = Intent(this, AITestActivity::class.java)
            startActivity(intent)
        }
    }

    private fun setupButtons() {
        btnDisconnect.setOnClickListener {
            disconnect()
        }

        btnReadData.setOnClickListener {
            if (isConnected) {
                readVehicleData()
            } else {
                Toast.makeText(this, "No hay conexión activa", Toast.LENGTH_SHORT).show()
            }
        }

    }

    private fun initializeConnection() {
        // Obtener el servicio del manager
        obd2Service = ELM327Manager.obd2Service

        if (obd2Service == null) {
            Toast.makeText(this, "Error: Servicio no disponible", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        obd2Service?.setConnectionListener(this)

        if (obd2Service?.isConnected() == true) {
            onConnectionSuccess()
        } else {
            // Intentar reconectar
            if (isSimulationMode) {
                obd2Service?.connect("simulated_device")
                tvStatus.text = "Estado: Conectando (SIMULACIÓN)..."
            } else {
                deviceAddress?.let { address ->
                    obd2Service?.connect(address)
                    tvStatus.text = "Estado: Conectando..."
                }
            }
        }
    }

    private fun loadFirebaseData() {
        // Limitar a los primeros 2 vehículos
        vehiculosRef.limitToFirst(2).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val firebaseData = StringBuilder()
                firebaseData.append("\n=== DATOS DE FIREBASE ===\n\n")

                if (snapshot.exists()) {
                    for (vehicleSnapshot in snapshot.children) {
                        val vehicle = vehicleSnapshot.getValue(Vehicle::class.java)
                        vehicle?.let {
                            firebaseData.append("Vehículo ${vehicleSnapshot.key}:\n")
                            firebaseData.append("  Marca: ${it.marca}\n")
                            firebaseData.append("  Modelo: ${it.modelo}\n")
                            firebaseData.append("  Año: ${it.anio}\n")
                            firebaseData.append("---\n")
                        }
                    }
                    firebaseData.append("✓ Conexión Firebase exitosa\n")
                } else {
                    firebaseData.append("No se encontraron vehículos\n")
                }

                // Actualizar la UI con los datos de Firebase
                appendFirebaseData(firebaseData.toString())
            }

            override fun onCancelled(error: DatabaseError) {
                val errorMessage = "\n=== DATOS DE FIREBASE ===\n\n✗ Error de conexión: ${error.message}\n"
                appendFirebaseData(errorMessage)
            }
        })
    }

    private fun appendFirebaseData(firebaseData: String) {
        runOnUiThread {
            val currentText = tvVehicleData.text.toString()
            // Si ya hay datos OBD, agregar Firebase al final
            if (currentText.contains("===")) {
                val updatedText = if (currentText.contains("===")) {
                    // Reemplazar cualquier sección previa de Firebase
                    currentText.replace(Regex("=== DATOS DE FIREBASE ===[\\s\\S]*"), firebaseData)
                } else {
                    "$currentText\n$firebaseData"
                }
                tvVehicleData.text = updatedText
            } else {
                // Si no hay datos aún, mostrar solo Firebase
                tvVehicleData.text = firebaseData
            }
        }
    }

    private fun readVehicleData() {
        if (!isConnected) {
            Toast.makeText(this, "No hay conexión activa", Toast.LENGTH_SHORT).show()
            return
        }

        Thread {
            try {
                val vehicleData = mutableMapOf<String, String>()

                // Leer todos los PIDs básicos
                basicPIDs.forEach { pid ->
                    try {
                        val response = obd2Service?.readPID(pid) ?: "NO_DATA"
                        if (!response.contains("ERROR") && !response.contains("NO_DATA") && !response.contains("NO_CONNECTION")) {
                            val value = parseOBDResponse(pid, response)
                            vehicleData[getPIDName(pid)] = value
                        }
                    } catch (e: Exception) {
                        vehicleData[getPIDName(pid)] = "Error"
                    }
                }

                // Leer información del vehículo si está en modo simulación
                if (isSimulationMode) {
                    readVehicleInfo(vehicleData)
                }

                runOnUiThread {
                    updateVehicleDataDisplay(vehicleData)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    Toast.makeText(this, "Error leyendo datos: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun readVehicleInfo(vehicleData: MutableMap<String, String>) {
        try {
            // Leer VIN
            val vinResponse = obd2Service?.readPID("0902") ?: ""
            if (!vinResponse.contains("ERROR")) {
                val vin = parseVehicleInfoResponse("0902", vinResponse)
                vehicleData["VIN"] = vin
            }

            // Leer información de calibración
            val calibrationResponse = obd2Service?.readPID("0904") ?: ""
            if (!calibrationResponse.contains("ERROR")) {
                val calibration = parseVehicleInfoResponse("0904", calibrationResponse)
                vehicleData["Calibración"] = calibration
            }
        } catch (e: Exception) {
            // Ignorar errores en información adicional
        }
    }

    private fun getPIDName(pid: String): String {
        return when (pid) {
            "010C" -> "RPM"
            "010D" -> "Velocidad"
            "0105" -> "Temp. Refrigerante"
            "0104" -> "Carga Motor"
            "010B" -> "Presión Múltiple"
            "010A" -> "Presión Combustible"
            "010F" -> "Temp. Aire Admisión"
            "010E" -> "Avance Encendido"
            "0111" -> "Posición Acelerador"
            "012F" -> "Nivel Combustible"
            "0133" -> "Presión Barométrica"
            "0146" -> "Temp. Ambiente"
            "015E" -> "Consumo Combustible"
            else -> pid
        }
    }

    private fun parseOBDResponse(command: String, response: String): String {
        if (response.contains("ERROR") || response.contains("NO_DATA") || response.contains("NO_CONNECTION")) {
            return "Sin datos"
        }

        return try {
            when (command) {
                "010C" -> { // RPM
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 4 && parts[0] == "41" && parts[1] == "0C") {
                        val a = parts[2].toInt(16)
                        val b = parts[3].toInt(16)
                        "${((a * 256) + b) / 4} RPM"
                    } else {
                        "Formato inválido"
                    }
                }
                "010D" -> { // Velocidad
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0D") {
                        "${parts[2].toInt(16)} km/h"
                    } else {
                        "Formato inválido"
                    }
                }
                "0105" -> { // Temperatura refrigerante
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "05") {
                        "${parts[2].toInt(16) - 40} °C"
                    } else {
                        "Formato inválido"
                    }
                }
                "0104" -> { // Carga del motor
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "04") {
                        "${(parts[2].toInt(16) * 100) / 255} %"
                    } else {
                        "Formato inválido"
                    }
                }
                "010B" -> { // Presión del múltiple
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0B") {
                        "${parts[2].toInt(16)} kPa"
                    } else {
                        "Formato inválido"
                    }
                }
                "010A" -> { // Fuel Pressure
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0A") {
                        "${parts[2].toInt(16) * 3} kPa"
                    } else {
                        "Formato inválido"
                    }
                }
                "010F" -> { // Temperatura aire admisión
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0F") {
                        "${parts[2].toInt(16) - 40} °C"
                    } else {
                        "Formato inválido"
                    }
                }
                "010E" -> { // Timing Advance
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0E") {
                        "${parts[2].toInt(16) / 2.0} °"
                    } else {
                        "Formato inválido"
                    }
                }
                "0111" -> { // Posición acelerador
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "11") {
                        "${(parts[2].toInt(16) * 100) / 255} %"
                    } else {
                        "Formato inválido"
                    }
                }
                "012F" -> { // Nivel combustible
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "2F") {
                        "${(parts[2].toInt(16) * 100) / 255} %"
                    } else {
                        "Formato inválido"
                    }
                }
                "0133" -> { // Barometric Pressure
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "33") {
                        "${parts[2].toInt(16)} kPa"
                    } else {
                        "Formato inválido"
                    }
                }
                "0146" -> { // Ambient Air Temperature
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 3 && parts[0] == "41" && parts[1] == "46") {
                        "${parts[2].toInt(16) - 40} °C"
                    } else {
                        "Formato inválido"
                    }
                }
                "015E" -> { // Engine Fuel Rate
                    val parts = response.split(" ").filter { it.isNotBlank() }
                    if (parts.size >= 4 && parts[0] == "41" && parts[1] == "5E") {
                        val a = parts[2].toInt(16)
                        val b = parts[3].toInt(16)
                        val rate = ((a * 256) + b).toDouble() / 100.0
                        String.format("%.2f L/h", rate)
                    } else {
                        "Formato inválido"
                    }
                }
                else -> response
            }
        } catch (e: Exception) {
            "Error parsing: $response"
        }
    }

    private fun parseVehicleInfoResponse(command: String, response: String): String {
        if (response.contains("ERROR") || response.contains("NO_DATA") || response.contains("NO_CONNECTION")) {
            return "Sin datos"
        }

        return try {
            when (command) {
                "0902" -> { // VIN
                    response.substringAfter("49 02 01 ")
                        .split(" ")
                        .filter { it.length == 2 && it != "00" }
                        .map { it.toInt(16).toChar() }
                        .joinToString("")
                        .trim()
                }
                "0904" -> { // Calibración
                    response.substringAfter("49 04 01 ")
                        .split(" ")
                        .filter { it.length == 2 && it != "00" }
                        .map { it.toInt(16).toChar() }
                        .joinToString("")
                        .trim()
                }
                else -> response
            }
        } catch (e: Exception) {
            "Error parsing: $response"
        }
    }

    private fun updateVehicleDataDisplay(data: Map<String, String>) {
        val stringBuilder = StringBuilder()
        val mode = if (isSimulationMode) "SIMULACIÓN" else "REAL"
        stringBuilder.append("=== DATOS DEL VEHÍCULO ($mode) ===\n\n")

        if (data.isEmpty()) {
            stringBuilder.append("No hay datos disponibles\n")
        } else {
            data.forEach { (name, value) ->
                stringBuilder.append("$name: $value\n")
            }
        }

        stringBuilder.append("\n---\n")
        stringBuilder.append("Presiona 'Leer Información' para actualizar")

        tvVehicleData.text = stringBuilder.toString()

        // Mantener los datos de Firebase si ya estaban cargados
        val currentText = tvVehicleData.text.toString()
        if (!currentText.contains("=== DATOS DE FIREBASE ===")) {
            // Recargar datos de Firebase si no están presentes
            loadFirebaseData()
        }
    }

    private fun disconnect() {
        isReading = false
        obd2Service?.disconnect()
        ELM327Manager.disconnect()
        Toast.makeText(this, "Desconectado", Toast.LENGTH_SHORT).show()
        finish()
    }

    // Implementación de ConnectionListener
    override fun onConnectionSuccess() {
        runOnUiThread {
            isConnected = true
            val modeText = if (isSimulationMode) " (SIMULACIÓN)" else ""
            tvStatus.text = "Estado: Conectado$modeText"
            tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
            Toast.makeText(this, "Conexión exitosa", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onConnectionError(error: String) {
        runOnUiThread {
            isConnected = false
            tvStatus.text = "Estado: Error - $error"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
            Toast.makeText(this, "Error de conexión: $error", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDataReceived(data: String) {
        // Para datos en tiempo real si decides implementar streaming
    }

    override fun onDisconnected() {
        runOnUiThread {
            isConnected = false
            tvStatus.text = "Estado: Desconectado"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
            isReading = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        isReading = false
        obd2Service?.disconnect()
    }
}

// Clase de datos para mapear los vehículos de Firebase
data class Vehicle(
    val marca: String = "",
    val modelo: String = "",
    val anio: Int = 0
)*/