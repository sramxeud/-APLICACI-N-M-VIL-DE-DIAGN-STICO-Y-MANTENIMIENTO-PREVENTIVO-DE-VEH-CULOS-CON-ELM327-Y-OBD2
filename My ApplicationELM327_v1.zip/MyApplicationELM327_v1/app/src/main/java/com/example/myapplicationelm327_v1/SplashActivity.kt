package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class SplashActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        supportActionBar?.hide() //ocultar menu sup
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        // INICIALIZACIÓN DOBLE: Archivo JSON + Manual
        FirebaseInitializer.initialize(this)

        try {
            auth = Firebase.auth
            Log.d("SplashActivity", "Firebase Auth initialized successfully")
        } catch (e: Exception) {
            Log.e("SplashActivity", "Firebase Auth init error: ${e.message}")
        }

        Handler(Looper.getMainLooper()).postDelayed({
            checkAuthStatus()
        }, 2000)
    }

    private fun checkAuthStatus() {
        try {
            val currentUser = auth.currentUser

            if (currentUser != null) {
                Log.d("SplashActivity", "User logged in: ${currentUser.email}")
                // Verificar si ya tiene perfil completo
                checkUserProfile(currentUser.uid)
            } else {
                Log.d("SplashActivity", "No user logged in")
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
                finish()
            }
        } catch (e: Exception) {
            Log.e("SplashActivity", "Error checking auth: ${e.message}")
            // En caso de error, ir a LoginActivity
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun checkUserProfile(userId: String) {
        val userRef = Firebase.database.getReference("users").child(userId)

        userRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val intent = if (snapshot.exists() &&
                    snapshot.child("userType").getValue(String::class.java) != null &&
                    snapshot.child("name").getValue(String::class.java)?.isNotEmpty() == true &&
                    snapshot.child("phone").getValue(String::class.java)?.isNotEmpty() == true) {

                    // Usuario tiene perfil completo, redirigir según tipo
                    val userType = snapshot.child("userType").getValue(String::class.java) ?: "owner"
                    if (userType == "mechanic") {
                        Intent(this@SplashActivity, MechanicActivity::class.java)
                    } else {
                        Intent(this@SplashActivity, OwnerActivity::class.java)
                    }
                } else {
                    // Usuario no tiene perfil completo, redirigir a ProfileActivity
                    Intent(this@SplashActivity, ProfileActivity::class.java)
                }

                startActivity(intent)
                finish()
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("SplashActivity", "Error checking user profile: ${error.message}")
                // En caso de error, ir a ProfileActivity para completar perfil
                val intent = Intent(this@SplashActivity, ProfileActivity::class.java)
                startActivity(intent)
                finish()
            }
        })
    }
}