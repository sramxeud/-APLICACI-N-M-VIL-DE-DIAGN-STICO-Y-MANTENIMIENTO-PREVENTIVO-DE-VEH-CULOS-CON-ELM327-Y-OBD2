package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MainActivity : AppCompatActivity() {

    private lateinit var btnDisconnect: Button
    private lateinit var btnMenu: ImageButton
    private lateinit var layoutMenu: LinearLayout
    private lateinit var opcion1: TextView
    private lateinit var opcion2: TextView
    private lateinit var opcion3: TextView
    private lateinit var opcion4: TextView

    // Variables para información del vehículo
    private lateinit var tvCurrentVehicle: TextView
    private lateinit var tvVehicleInfo: TextView
    private lateinit var btnSelectVehicle: Button

    private val handler = Handler(Looper.getMainLooper())
    private var obd2Service: IOBD2Service? = null
    private var isReading = false

    // Firebase
    private val database = FirebaseDatabase.getInstance()
    private val auth = FirebaseAuth.getInstance()
    private var myVehicles: List<Vehicle> = emptyList()
    private var selectedVehicle: Vehicle? = null

    override fun onResume() {
        super.onResume()
        // Solo cargar vehículos si la UI ya está inicializada
        if (::tvCurrentVehicle.isInitialized) {
            loadMyVehicles()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Primero verificar autenticación y perfil
        checkUserProfile()
    }

    private fun checkUserProfile() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val userRef = Firebase.database.getReference("users").child(currentUser.uid)

            userRef.addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (!snapshot.exists() || snapshot.child("name").getValue(String::class.java) == null) {
                        // No tiene perfil completo, redirigir a ProfileActivity
                        Log.d("MainActivity", "Usuario sin perfil completo, redirigiendo a ProfileActivity")
                        startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                        finish()
                    } else {
                        // Tiene perfil completo, inicializar UI normal
                        Log.d("MainActivity", "Perfil completo encontrado")
                        initializeNormalUI()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MainActivity", "Error cargando perfil: ${error.message}")
                    // En caso de error, redirigir a perfil para asegurar
                    startActivity(Intent(this@MainActivity, ProfileActivity::class.java))
                    finish()
                }
            })
        } else {
            // No hay usuario autenticado, redirigir a LoginActivity
            Log.d("MainActivity", "No hay usuario autenticado, redirigiendo a Login")
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    private fun initializeNormalUI() {
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()
        initViews()
        initializeService()
        setupMenuDesplegable()
        // Cargar vehículos después de inicializar la UI
        loadMyVehicles()
    }

    private fun initViews() {
        try {
            btnDisconnect = findViewById(R.id.btnDisconnect)
            btnDisconnect.setOnClickListener {
                disconnect()
            }

            // INICIALIZACIÓN SEGURA de views
            tvCurrentVehicle = findViewById(R.id.tvCurrentVehicle)
            tvVehicleInfo = findViewById(R.id.tvVehicleInfo)
            btnSelectVehicle = findViewById(R.id.btnSelectVehicle)

            // Configurar botón de selección de vehículo solo si los views existen
            btnSelectVehicle.setOnClickListener {
                showVehicleSelectionDialog()
            }

            // vPIC
            val layoutVpic = findViewById<LinearLayout>(R.id.layout_vpic)
            layoutVpic.setOnClickListener {
                val intent = Intent(this, VpicActivity::class.java)
                startActivity(intent)
            }

            // ImageButton vPIC
            findViewById<ImageButton>(R.id.btn_vpic).setOnClickListener {
                val intent = Intent(this, VpicActivity::class.java)
                startActivity(intent)
            }

            // Sensores
            val layoutSensors = findViewById<LinearLayout>(R.id.layout_sensors)
            layoutSensors.setOnClickListener {
                val intent = Intent(this, SensorsActivity::class.java)
                startActivity(intent)
            }

            // ImageButton Sensores
            findViewById<ImageButton>(R.id.btn_sensors).setOnClickListener {
                val intent = Intent(this, SensorsActivity::class.java)
                startActivity(intent)
            }

            // Códigos de error
            val layoutErrorCodes = findViewById<LinearLayout>(R.id.layout_error_codes)
            layoutErrorCodes.setOnClickListener {
                val intent = Intent(this, ErrorCodesActivity::class.java)
                startActivity(intent)
            }

            // ImageButton Códigos de error
            findViewById<ImageButton>(R.id.btn_error_codes).setOnClickListener {
                val intent = Intent(this, ErrorCodesActivity::class.java)
                startActivity(intent)
            }

            // Diagnóstico General
            val btnDiagnostic = findViewById<ImageButton>(R.id.btn_refresh)
            btnDiagnostic.setOnClickListener {
                val intent = Intent(this, DiagnosticActivity::class.java)
                startActivity(intent)
            }

            // También el LinearLayout contenedor del diagnóstico
            val layoutDiagnostic = findViewById<LinearLayout>(R.id.layout_diagnostic)
            layoutDiagnostic?.setOnClickListener {
                val intent = Intent(this, DiagnosticActivity::class.java)
                startActivity(intent)
            }

            Log.d("MainActivity", "Views inicializados correctamente")

        } catch (e: Exception) {
            Log.e("MainActivity", "Error en initViews: ${e.message}")
            // Mostrar error pero continuar
            Toast.makeText(this, "Error inicializando interfaz", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadMyVehicles() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            val vehiclesRef = Firebase.database.getReference("vehicles")
            vehiclesRef.orderByChild("ownerId").equalTo(currentUser.uid)
                .addListenerForSingleValueEvent(object : ValueEventListener {
                    override fun onDataChange(snapshot: DataSnapshot) {
                        try {
                            myVehicles = snapshot.children.mapNotNull {
                                try {
                                    it.getValue(Vehicle::class.java)
                                } catch (e: Exception) {
                                    Log.e("MainActivity", "Error parsing vehicle: ${e.message}")
                                    null
                                }
                            }

                            Log.d("MainActivity", "Vehículos encontrados: ${myVehicles.size}")

                            if (myVehicles.isNotEmpty()) {
                                // SOLO seleccionar automáticamente si no hay selección previa
                                if (selectedVehicle == null) {
                                    selectedVehicle = myVehicles.first()
                                } else {
                                    // Actualizar el objeto seleccionado con los datos frescos
                                    val currentVin = selectedVehicle!!.vin
                                    selectedVehicle = myVehicles.find { it.vin == currentVin } ?: myVehicles.firstOrNull()
                                }
                                updateVehicleInfo()
                            } else {
                                selectedVehicle = null
                                // MANEJO SEGURO: Actualizar UI en el hilo principal
                                runOnUiThread {
                                    try {
                                        tvCurrentVehicle.text = "No hay vehículos"
                                        tvVehicleInfo.text = "Agrega un vehículo para comenzar"
                                        // También limpiar el VIN en ELM327Manager
                                        ELM327Manager.currentVIN = ""
                                    } catch (e: Exception) {
                                        Log.e("MainActivity", "Error updating UI: ${e.message}")
                                    }
                                }
                            }
                        } catch (e: Exception) {
                            Log.e("MainActivity", "Error processing vehicles: ${e.message}")
                            runOnUiThread {
                                Toast.makeText(this@MainActivity, "Error cargando vehículos", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }

                    override fun onCancelled(error: DatabaseError) {
                        Log.e("MainActivity", "Database error: ${error.message}")
                        runOnUiThread {
                            Toast.makeText(this@MainActivity, "Error cargando vehículos", Toast.LENGTH_SHORT).show()
                        }
                    }
                })
        } else {
            Log.e("MainActivity", "No current user found")
        }
    }

    private fun showVehicleSelectionDialog() {
        if (myVehicles.isEmpty()) {
            Toast.makeText(this, "No hay vehículos disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        val vehicleNames = myVehicles.map {
            if (it.vpicData.marca.isNotEmpty()) {
                "${it.vpicData.marca} ${it.vpicData.modelo} - ${it.vin}"
            } else {
                "${it.nombre} - ${it.vin}"
            }
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Seleccionar Vehículo")
            .setItems(vehicleNames) { _, which ->
                selectedVehicle = myVehicles[which]
                updateVehicleInfo()

                // CORRECCIÓN: Forzar la actualización inmediata del VIN
                ELM327Manager.currentVIN = selectedVehicle?.vin ?: ""
                Log.d("MainActivity", "Vehículo seleccionado: ${selectedVehicle?.vin}")
                val marca = selectedVehicle?.vpicData?.marca ?: "Marca desconocida"
                val modelo = selectedVehicle?.vpicData?.modelo ?: "Modelo desconocido"
                Toast.makeText(this, "Vehículo seleccionado: $marca $modelo", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateVehicleInfo() {
        runOnUiThread {
            try {
                selectedVehicle?.let { vehicle ->
                    tvCurrentVehicle.text = "Vehículo Actual"

                    val vehicleInfo = if (vehicle.vpicData.marca.isNotEmpty()) {
                        """
                    🚗 ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo}
                    📅 Año: ${vehicle.vpicData.año}
                    🎨 Color: ${vehicle.vpicData.color}
                    🔢 VIN: ${vehicle.vin}
                    """.trimIndent()
                    } else {
                        """
                    🚗 ${vehicle.nombre}
                    🔢 VIN: ${vehicle.vin}
                    ℹ️ Completa la información VPIC
                    """.trimIndent()
                    }

                    tvVehicleInfo.text = vehicleInfo

                    // CORRECCIÓN: Actualizar ELM327Manager ANTES de cualquier operación
                    ELM327Manager.currentVIN = vehicle.vin
                    Log.d("MainActivity", "VIN actualizado: ${vehicle.vin}")
                } ?: run {
                    // Si selectedVehicle es null
                    tvCurrentVehicle.text = "No hay vehículos"
                    tvVehicleInfo.text = "Agrega un vehículo para comenzar"
                }
            } catch (e: Exception) {
                Log.e("MainActivity", "Error updating vehicle info: ${e.message}")
            }
        }
    }

    private fun initializeService() {
        obd2Service = ELM327Manager.obd2Service ?: run {
            ELM327Manager.initializeService(null)
            ELM327Manager.obd2Service
        }
    }

    private fun setupMenuDesplegable() {
        btnMenu = findViewById(R.id.btnMenu)
        layoutMenu = findViewById(R.id.layoutMenuDesplegable)
        opcion1 = findViewById(R.id.opcion1)
        opcion2 = findViewById(R.id.opcion2)
        opcion3 = findViewById(R.id.opcion3)
        opcion4 = findViewById(R.id.opcion4)

        // Configurar opciones del menú para propietarios
        setupOwnerMenu()

        // Click en el botón del menú - usando el estado actual
        btnMenu.setOnClickListener {
            if (layoutMenu.visibility == View.VISIBLE) {
                layoutMenu.visibility = View.GONE
            } else {
                layoutMenu.visibility = View.VISIBLE
            }
        }

        // Opcional: Cerrar menú al tocar fuera
        setupCerrarMenuAlTocarFuera()
    }

    private fun setupOwnerMenu() {
        // Configurar opciones para propietarios - AHORA 4 OPCIONES
        opcion1.text = "Modificar Perfil"
        opcion2.text = "Agregar Vehículo"
        opcion3.text = "Eliminar Vehículo"
        opcion4.text = "Cerrar sesión"
         // Nueva opción

        // Clicks en las opciones del menú para propietarios
        opcion1.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("EDIT_MODE", true)
            startActivity(intent)
            layoutMenu.visibility = View.GONE
        }

        opcion2.setOnClickListener {
            val intent = Intent(this, AddVehicleActivity::class.java)
            startActivity(intent)
            layoutMenu.visibility = View.GONE
        }

        opcion4.setOnClickListener {
            // Cerrar sesión
            auth.signOut()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
            layoutMenu.visibility = View.GONE
        }

        opcion3.setOnClickListener {
            showDeleteVehicleDialog()
            layoutMenu.visibility = View.GONE
        }
    }

    private fun showDeleteVehicleDialog() {
        if (myVehicles.isEmpty()) {
            Toast.makeText(this, "No hay vehículos para eliminar", Toast.LENGTH_SHORT).show()
            return
        }

        val vehicleNames = myVehicles.map {
            if (it.vpicData.marca.isNotEmpty()) {
                "${it.vpicData.marca} ${it.vpicData.modelo} - ${it.vin}"
            } else {
                "${it.nombre} - ${it.vin}"
            }
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Seleccionar Vehículo a Eliminar")
            .setItems(vehicleNames) { _, which ->
                val vehicleToDelete = myVehicles[which]
                confirmDeleteVehicle(vehicleToDelete)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun confirmDeleteVehicle(vehicle: Vehicle) {
        AlertDialog.Builder(this)
            .setTitle("Confirmar Eliminación")
            .setMessage("¿Estás seguro de que deseas eliminar el vehículo ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo}? Esta acción no se puede deshacer.")
            .setPositiveButton("Eliminar") { _, _ ->
                deleteVehicle(vehicle)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun deleteVehicle(vehicle: Vehicle) {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Eliminar el vehículo de la base de datos
            val vehicleRef = Firebase.database.getReference("vehicles").child(vehicle.id)
            vehicleRef.removeValue().addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // Eliminar las asignaciones de este vehículo
                    deleteAssignmentsForVehicle(vehicle.id)
                    // Actualizar la lista de vehículos local
                    loadMyVehicles()
                    Toast.makeText(this, "Vehículo eliminado correctamente", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Error al eliminar vehículo", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun deleteAssignmentsForVehicle(vehicleId: String) {
        val assignmentsRef = Firebase.database.getReference("assignments")
        assignmentsRef.orderByChild("vehicleId").equalTo(vehicleId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    for (assignmentSnapshot in snapshot.children) {
                        assignmentSnapshot.ref.removeValue()
                    }
                    Log.d("MainActivity", "Asignaciones eliminadas para vehicleId: $vehicleId")
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MainActivity", "Error eliminando asignaciones: ${error.message}")
                }
            })
    }

    private fun setupCerrarMenuAlTocarFuera() {
        val rootView = findViewById<View>(android.R.id.content)

        rootView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN &&
                layoutMenu.visibility == View.VISIBLE) {

                val location = IntArray(2)
                layoutMenu.getLocationOnScreen(location)
                val menuRect = android.graphics.Rect(
                    location[0], location[1],
                    location[0] + layoutMenu.width,
                    location[1] + layoutMenu.height
                )

                val btnLocation = IntArray(2)
                btnMenu.getLocationOnScreen(btnLocation)
                val btnRect = android.graphics.Rect(
                    btnLocation[0], btnLocation[1],
                    btnLocation[0] + btnMenu.width,
                    btnLocation[1] + btnMenu.height
                )

                // Si se toca fuera del menú Y fuera del botón, cerrar menú
                if (!menuRect.contains(event.rawX.toInt(), event.rawY.toInt()) &&
                    !btnRect.contains(event.rawX.toInt(), event.rawY.toInt())) {
                    layoutMenu.visibility = View.GONE
                }
            }
            false
        }
    }

    private fun disconnect() {
        isReading = false
        ELM327Manager.disconnect()

        // Redirigir a OwnerActivity
        val intent = Intent(this, OwnerActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    override fun onDestroy() {
        super.onDestroy()
        isReading = false
        handler.removeCallbacksAndMessages(null)
    }

    // Data classes necesarias (las mismas que en AddVehicleActivity)
    data class Vehicle(
        val id: String = "",
        val ownerId: String = "",
        val nombre: String = "",
        val vin: String = "",
        val assignedMechanics: List<String> = emptyList(),
        val vpicData: VpicData = VpicData(),
        val sensorData: SensorData = SensorData(),
        val errorData: ErrorData = ErrorData(),
        val createdAt: Long = 0L
    )

    data class VpicData(
        val marca: String = "",
        val modelo: String = "",
        val año: Int = 0,
        val color: String = "",
        val motor: String = "",
        val transmision: String = "",
        val combustible: String = "",
        val ultimaActualizacion: Long = 0L
    )

    data class SensorData(
        val rpm: String = "",
        val cargaMotor: String = "",
        val avanceEncendido: String = "",
        val tempRefrigerante: String = "",
        val tempAireAdmision: String = "",
        val tempAireAmbiental: String = "",
        val nivelCombustible: String = "",
        val presionCombustible: String = "",
        val tasaConsumo: String = "",
        val presionMAP: String = "",
        val presionBarometrica: String = "",
        val velocidad: String = "",
        val posicionAcelerador: String = "",
        val ultimaLectura: Long = 0L
    )

    data class ErrorData(
        val codigosActivos: List<String> = emptyList(),
        val codigosPendientes: List<String> = emptyList(),
        val ultimaLectura: Long = 0L
    )
}