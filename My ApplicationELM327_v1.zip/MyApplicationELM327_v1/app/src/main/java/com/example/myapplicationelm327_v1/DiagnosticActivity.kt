package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class DiagnosticActivity : AppCompatActivity() {

    private lateinit var btnBack: Button
    private lateinit var containerDiagnosticOptions: LinearLayout
    private lateinit var tvCurrentVehicle: TextView
    private lateinit var tvConnectionStatus: TextView
    private lateinit var progressBar: ProgressBar

    private val database = Firebase.database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_diagnostic)
        supportActionBar?.hide()

        initViews()
        setupDiagnosticOptions()
        updateVehicleInfo()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBackDiagnostic)
        containerDiagnosticOptions = findViewById(R.id.containerDiagnosticOptions)
        tvCurrentVehicle = findViewById(R.id.tvCurrentVehicle)
        tvConnectionStatus = findViewById(R.id.tvConnectionStatus)
        progressBar = findViewById(R.id.progressBar)

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun setupDiagnosticOptions() {
        containerDiagnosticOptions.removeAllViews()

        // Opción 1: Diagnóstico Inteligente con IA
        addDiagnosticCard(
            "🤖 Diagnóstico Inteligente",
            "Análisis completo con IA: problemas, causas y soluciones organizadas",
            "IA"
        ) {
            val intent = Intent(this@DiagnosticActivity, IntelligentDiagnosisActivity::class.java)
            startActivity(intent)
        }

        // Opción 2: Diagnóstico Rápido (sin internet)
        addDiagnosticCard(
            "⚡ Diagnóstico Rápido",
            "Análisis básico de sensores y códigos de error sin conexión a internet",
            "RÁPIDO"
        ) {
            performQuickDiagnosis()
        }

        // Opción 3: Información Técnica
        addDiagnosticCard(
            "📋 Información Técnica",
            "Ver especificaciones y rangos operativos del vehículo",
            "TÉCNICA"
        ) {
            showTechnicalInfo()
        }
    }

    private fun addDiagnosticCard(title: String, description: String, badge: String, onClick: () -> Unit) {
        val card = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 8, 16, 16)
            }
            radius = 12f
            cardElevation = 4f
            setContentPadding(16, 16, 16, 16)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Header con título y badge
        val headerLayout = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tvTitle = TextView(this).apply {
            text = title
            textSize = 18f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
            }
        }

        val tvBadge = TextView(this).apply {
            text = badge
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setBackgroundColor(0xFF2196F3.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(8, 4, 8, 4)
            gravity = android.view.Gravity.CENTER
        }

        headerLayout.addView(tvTitle)
        headerLayout.addView(tvBadge)

        // Descripción
        val tvDescription = TextView(this).apply {
            text = description
            textSize = 14f
            setTextColor(0xFF757575.toInt())
            setPadding(0, 8, 0, 16)
        }

        // Botón de acción
        val btnAction = Button(this).apply {
            text = "Ejecutar"
            setBackgroundColor(0xFF4CAF50.toInt())
            setTextColor(0xFFFFFFFF.toInt())
            setOnClickListener { onClick() }
        }

        layout.addView(headerLayout)
        layout.addView(tvDescription)
        layout.addView(btnAction)
        card.addView(layout)

        containerDiagnosticOptions.addView(card)
    }

    private fun updateVehicleInfo() {
        val currentVIN = ELM327Manager.currentVIN
        val isConnected = ELM327Manager.isConnected

        if (!currentVIN.isNullOrEmpty()) {
            tvCurrentVehicle.text = "Vehículo: $currentVIN"
        } else {
            tvCurrentVehicle.text = "Vehículo: No seleccionado"
        }

        if (isConnected) {
            tvConnectionStatus.text = "Conexión: ✅ Conectado"
            tvConnectionStatus.setTextColor(0xFF4CAF50.toInt())
        } else {
            tvConnectionStatus.text = "Conexión: ❌ Desconectado"
            tvConnectionStatus.setTextColor(0xFFF44336.toInt())
        }
    }

    private fun performQuickDiagnosis() {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty()) {
            Toast.makeText(this, "No hay vehículo seleccionado", Toast.LENGTH_SHORT).show()
            return
        }

        showProgress("⚡ Analizando vehículo...")

        lifecycleScope.launch {
            try {
                val vehicle = getVehicleFromFirebase(currentVIN)
                hideProgress()

                vehicle?.let {
                    showQuickDiagnosisResults(it)
                } ?: run {
                    showOfflineQuickDiagnosis()
                }
            } catch (e: Exception) {
                hideProgress()
                showOfflineQuickDiagnosis()
            }
        }
    }

    private fun showOfflineQuickDiagnosis() {
        val currentVIN = ELM327Manager.currentVIN
        val message = """
            🔧 Diagnóstico Rápido (Sin Conexión)
            
            ℹ️ No se pudo conectar a internet para obtener datos actualizados.
            
            💡 Información disponible:
            • VIN: ${currentVIN ?: "No disponible"}
            • Conexión OBD2: ${if (ELM327Manager.isConnected) "✅ Conectado" else "❌ Desconectado"}
            
            ⚠️ Para diagnóstico completo, conecta a internet y ejecuta "Diagnóstico Inteligente".
        """.trimIndent()

        AlertDialog.Builder(this)
            .setTitle("Diagnóstico Rápido")
            .setMessage(message)
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private fun showQuickDiagnosisResults(vehicle: Vehicle) {
        // Crear un diálogo con tabla para el diagnóstico rápido
        val dialogView = layoutInflater.inflate(R.layout.dialog_quick_diagnosis, null)
        val tableContainer = dialogView.findViewById<LinearLayout>(R.id.tableContainer)
        val tvSummary = dialogView.findViewById<TextView>(R.id.tvSummary)

        // Calcular resumen
        val errorCount = vehicle.errorData.codigosActivos.size + vehicle.errorData.codigosPendientes.size
        val status = when {
            errorCount > 3 -> "❌ CRÍTICO - Se detectaron $errorCount códigos de error"
            errorCount > 0 -> "⚠️ ADVERTENCIA - Se detectaron $errorCount códigos de error"
            else -> "✅ ÓPTIMO - No se detectaron códigos de error"
        }

        tvSummary.text = "Estado: $status"

        // Construir tabla
        buildQuickDiagnosisTable(tableContainer, vehicle)

        AlertDialog.Builder(this)
            .setTitle("⚡ Diagnóstico Rápido - ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo}")
            .setView(dialogView)
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private fun buildQuickDiagnosisTable(container: LinearLayout, vehicle: Vehicle) {
        container.removeAllViews()

        // HorizontalScrollView para la tabla
        val horizontalScrollView = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tableLayout = TableLayout(this).apply {
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT
            )
            isStretchAllColumns = true
        }

        // Cabecera de la tabla
        val headerRow = TableRow(this).apply {
            setBackgroundColor(0xFF2196F3.toInt())
        }

        val headers = arrayOf("Sensor", "Lectura", "Estado", "Descripción")

        headers.forEach { header ->
            val textView = TextView(this).apply {
                text = header
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(16, 12, 16, 12)
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            headerRow.addView(textView)
        }

        tableLayout.addView(headerRow)

        // Función helper para agregar filas
        fun addRow(sensor: String, lectura: String, estado: String, descripcion: String) {
            val row = TableRow(this).apply {
                layoutParams = TableLayout.LayoutParams(
                    TableLayout.LayoutParams.WRAP_CONTENT,
                    TableLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val background = if (tableLayout.childCount % 2 == 1) 0xFFFAFAFA.toInt() else 0xFFFFFFFF.toInt()
            val texts = arrayOf(sensor, lectura, estado, descripcion)

            texts.forEach { text ->
                val textView = TextView(this).apply {
                    this.text = text
                    setPadding(16, 12, 16, 12)
                    textSize = 12f
                    gravity = Gravity.CENTER
                    setBackgroundColor(background)
                }
                row.addView(textView)
            }

            tableLayout.addView(row)
        }

        // Agregar sensores principales
        addRow("RPM", vehicle.sensorData.rpm,
            if (vehicle.sensorData.rpm.isNotEmpty()) "✅" else "⚠️",
            "Revoluciones por minuto")

        addRow("Temp. Motor", vehicle.sensorData.tempRefrigerante,
            if (vehicle.sensorData.tempRefrigerante.isNotEmpty()) "✅" else "⚠️",
            "Temperatura refrigerante")

        addRow("Carga Motor", vehicle.sensorData.cargaMotor,
            if (vehicle.sensorData.cargaMotor.isNotEmpty()) "✅" else "⚠️",
            "Carga del motor")

        addRow("Velocidad", vehicle.sensorData.velocidad,
            if (vehicle.sensorData.velocidad.isNotEmpty()) "✅" else "⚠️",
            "Velocidad del vehículo")

        addRow("Combustible", vehicle.sensorData.nivelCombustible,
            if (vehicle.sensorData.nivelCombustible.isNotEmpty()) "✅" else "⚠️",
            "Nivel de combustible")

        // Agregar códigos de error
        vehicle.errorData.codigosActivos.forEach { code ->
            addRow("DTC", code, "❌", "Código de error activo")
        }

        vehicle.errorData.codigosPendientes.forEach { code ->
            addRow("DTC", code, "⚠️", "Código de error pendiente")
        }

        horizontalScrollView.addView(tableLayout)
        container.addView(horizontalScrollView)
    }

    private fun showTechnicalInfo() {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty()) {
            Toast.makeText(this, "No hay vehículo seleccionado", Toast.LENGTH_SHORT).show()
            return
        }

        showProgress("📋 Cargando información técnica...")

        lifecycleScope.launch {
            try {
                val vpicData = getVpicTechnicalData(currentVIN)
                hideProgress()

                vpicData?.let {
                    showTechnicalInfoDialog(it)
                } ?: run {
                    Toast.makeText(this@DiagnosticActivity, "No hay información técnica disponible para este vehículo", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                hideProgress()
                Toast.makeText(this@DiagnosticActivity, "Error cargando información técnica: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showTechnicalInfoDialog(vpicData: VpicTechnicalData) {
        val scrollView = ScrollView(this)
        val mainLayout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // HorizontalScrollView para la tabla
        val horizontalScrollView = HorizontalScrollView(this)
        val tableLayout = TableLayout(this).apply {
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
            isStretchAllColumns = true
        }

        // Función helper para agregar secciones
        fun addSection(title: String) {
            val row = TableRow(this).apply {
                setBackgroundColor(0xFF2196F3.toInt())
            }
            val textView = TextView(this).apply {
                text = title
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(16, 12, 16, 12)
                textSize = 16f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
            }
            row.addView(textView)
            tableLayout.addView(row)
        }

        // Función helper para agregar filas
        fun addRow(label: String, value: String) {
            val row = TableRow(this)

            val tvLabel = TextView(this).apply {
                text = label
                setPadding(16, 8, 16, 8)
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setBackgroundColor(0xFFEEEEEE.toInt())
                minWidth = 200 // Ancho mínimo para mejor visualización
            }

            val tvValue = TextView(this).apply {
                text = value
                setPadding(16, 8, 16, 8)
                setBackgroundColor(0xFFFFFFFF.toInt())
                minWidth = 300 // Ancho mínimo para mejor visualización
            }

            row.addView(tvLabel)
            row.addView(tvValue)
            tableLayout.addView(row)
        }

        // Información General
        addSection("🚗 INFORMACIÓN GENERAL")
        addRow("Marca", vpicData.info_general.marca)
        addRow("Modelo", vpicData.info_general.modelo)
        addRow("Año", vpicData.info_general.ano.toString())
        addRow("Color", vpicData.info_general.color)
        addRow("Carrocería", vpicData.info_general.carroceria)
        addRow("VIN", vpicData.info_general.vin)
        addRow("Fecha Registro", vpicData.info_general.fecha_registro)

        // Especificaciones Técnicas
        addSection("⚙️ ESPECIFICACIONES TÉCNICAS")
        addRow("Motor", vpicData.especificaciones_tecnicas.motor)
        addRow("Cilindrada", "${vpicData.especificaciones_tecnicas.cilindrada_cc} cc")
        addRow("Potencia", "${vpicData.especificaciones_tecnicas.potencia_hp} HP")
        addRow("Torque", "${vpicData.especificaciones_tecnicas.torque_nm} Nm")
        addRow("Transmisión", vpicData.especificaciones_tecnicas.transmision)
        addRow("Tracción", vpicData.especificaciones_tecnicas.traccion)
        addRow("Combustible", vpicData.especificaciones_tecnicas.combustible)
        addRow("Compresión", vpicData.especificaciones_tecnicas.compresion)
        addRow("Emisiones", vpicData.especificaciones_tecnicas.emisiones)

        // Rangos Operativos
        addSection("📈 RANGOS OPERATIVOS")
        addRow("RPM Mínima", vpicData.rangos_operativos.rpm.min.toString())
        addRow("RPM Óptima", vpicData.rangos_operativos.rpm.optima.toString())
        addRow("RPM Alerta", vpicData.rangos_operativos.rpm.alerta.toString())
        addRow("RPM Máxima", vpicData.rangos_operativos.rpm.max.toString())
        addRow("Temp. Motor Mín", "${vpicData.rangos_operativos.temperatura_motor.min}°C")
        addRow("Temp. Motor Óptima", "${vpicData.rangos_operativos.temperatura_motor.optima}°C")
        addRow("Temp. Motor Máx", "${vpicData.rangos_operativos.temperatura_motor.max}°C")
        addRow("Temp. Aceite Mín", "${vpicData.rangos_operativos.temp_aceite.min}°C")
        addRow("Temp. Aceite Máx", "${vpicData.rangos_operativos.temp_aceite.max}°C")
        addRow("Presión Aceite Mín", "${vpicData.rangos_operativos.presion_aceite.min} bar")
        addRow("Presión Aceite Máx", "${vpicData.rangos_operativos.presion_aceite.max} bar")
        addRow("Tensión Batería Mín", "${vpicData.rangos_operativos.tension_bateria.min} V")
        addRow("Tensión Batería Máx", "${vpicData.rangos_operativos.tension_bateria.max} V")

        // Consumo y Eficiencia
        addSection("⛽ CONSUMO Y EFICIENCIA")
        addRow("Consumo Ciudad", "${vpicData.consumo_eficiencia.ciudad_lt_100km} L/100km")
        addRow("Consumo Carretera", "${vpicData.consumo_eficiencia.carretera_lt_100km} L/100km")
        addRow("Consumo Mixto", "${vpicData.consumo_eficiencia.mixto_lt_100km} L/100km")
        addRow("Capacidad Tanque", "${vpicData.consumo_eficiencia.capacidad_tanque_lt} L")

        // Dimensiones
        addSection("📏 DIMENSIONES Y PESO")
        addRow("Largo", "${vpicData.dimensiones_peso.largo_mm} mm")
        addRow("Ancho", "${vpicData.dimensiones_peso.ancho_mm} mm")
        addRow("Alto", "${vpicData.dimensiones_peso.alto_mm} mm")
        addRow("Peso", "${vpicData.dimensiones_peso.peso_kg} kg")

        // Procedencia
        addSection("🌍 PROCEDENCIA")
        addRow("País de Ensamblaje", vpicData.procedencia.pais_ensamblaje)
        addRow("WMI (World Manufacturer Identifier)", vpicData.procedencia.wmi)

        horizontalScrollView.addView(tableLayout)
        mainLayout.addView(horizontalScrollView)
        scrollView.addView(mainLayout)

        AlertDialog.Builder(this)
            .setTitle("📋 Información Técnica Completa - ${vpicData.info_general.marca} ${vpicData.info_general.modelo}")
            .setView(scrollView)
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private suspend fun getVehicleFromFirebase(vin: String): Vehicle? = withContext(Dispatchers.IO) {
        try {
            val vehiclesRef = database.getReference("vehicles")
            val dataSnapshot = vehiclesRef.get().await()

            for (child in dataSnapshot.children) {
                val vehicle = child.getValue(Vehicle::class.java)
                if (vehicle != null && vehicle.vin.equals(vin, ignoreCase = true)) {
                    return@withContext vehicle
                }
            }
            return@withContext null
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun getVpicTechnicalData(vin: String): VpicTechnicalData? = withContext(Dispatchers.IO) {
        try {
            val vpicRef = database.getReference("vpic/vehiculos/$vin")
            val dataSnapshot = vpicRef.get().await()

            if (dataSnapshot.exists()) {
                return@withContext dataSnapshot.getValue(VpicTechnicalData::class.java)
            } else {
                return@withContext null
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun showProgress(message: String) {
        progressBar.visibility = View.VISIBLE
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun hideProgress() {
        progressBar.visibility = View.GONE
    }

    private fun showError(message: String) {
        Toast.makeText(this, "❌ $message", Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()
        updateVehicleInfo()
    }

    // Data Classes para Firebase
    data class Vehicle(
        val id: String = "",
        val ownerId: String = "",
        val nombre: String = "",
        val vin: String = "",
        val assignedMechanics: List<String> = emptyList(),
        val vpicData: VpicData = VpicData(),
        val sensorData: SensorData = SensorData(),
        val errorData: ErrorData = ErrorData(),
        val createdAt: Long = 0L
    )

    data class VpicData(
        val marca: String = "",
        val modelo: String = "",
        val año: Int = 0,
        val color: String = "",
        val motor: String = "",
        val transmision: String = "",
        val combustible: String = "",
        val ultimaActualizacion: Long = 0L
    )

    data class SensorData(
        val rpm: String = "",
        val cargaMotor: String = "",
        val avanceEncendido: String = "",
        val tempRefrigerante: String = "",
        val tempAireAdmision: String = "",
        val tempAireAmbiental: String = "",
        val nivelCombustible: String = "",
        val presionCombustible: String = "",
        val tasaConsumo: String = "",
        val presionMAP: String = "",
        val presionBarometrica: String = "",
        val velocidad: String = "",
        val posicionAcelerador: String = "",
        val ultimaLectura: Long = 0L
    )

    data class ErrorData(
        val codigosActivos: List<String> = emptyList(),
        val codigosPendientes: List<String> = emptyList(),
        val ultimaLectura: Long = 0L
    )

    // Data Classes para datos técnicos VPIC
    data class VpicTechnicalData(
        val info_general: InfoGeneral = InfoGeneral(),
        val especificaciones_tecnicas: EspecificacionesTecnicas = EspecificacionesTecnicas(),
        val rangos_operativos: RangosOperativos = RangosOperativos(),
        val consumo_eficiencia: ConsumoEficiencia = ConsumoEficiencia(),
        val dimensiones_peso: DimensionesPeso = DimensionesPeso(),
        val procedencia: Procedencia = Procedencia()
    ) {
        data class InfoGeneral(
            val marca: String = "",
            val modelo: String = "",
            val ano: Int = 0,
            val color: String = "",
            val carroceria: String = "",
            val vin: String = "",
            val fecha_registro: String = ""
        )

        data class EspecificacionesTecnicas(
            val motor: String = "",
            val cilindrada_cc: Int = 0,
            val combustible: String = "",
            val potencia_hp: Int = 0,
            val torque_nm: Int = 0,
            val transmision: String = "",
            val traccion: String = "",
            val compresion: String = "",
            val emisiones: String = ""
        )

        data class RangosOperativos(
            val rpm: Rpm = Rpm(),
            val temperatura_motor: TemperaturaMotor = TemperaturaMotor(),
            val temp_aceite: TempAceite = TempAceite(),
            val presion_aceite: PresionAceite = PresionAceite(),
            val tension_bateria: TensionBateria = TensionBateria()
        ) {
            data class Rpm(val min: Int = 0, val optima: Int = 0, val alerta: Int = 0, val max: Int = 0)
            data class TemperaturaMotor(val min: Int = 0, val optima: Int = 0, val max: Int = 0)
            data class TempAceite(val min: Int = 0, val max: Int = 0)
            data class PresionAceite(val min: Double = 0.0, val max: Double = 0.0)
            data class TensionBateria(val min: Double = 0.0, val max: Double = 0.0)
        }

        data class ConsumoEficiencia(
            val ciudad_lt_100km: Double = 0.0,
            val carretera_lt_100km: Double = 0.0,
            val mixto_lt_100km: Double = 0.0,
            val capacidad_tanque_lt: Double = 0.0
        )

        data class DimensionesPeso(
            val largo_mm: Int = 0,
            val ancho_mm: Int = 0,
            val alto_mm: Int = 0,
            val peso_kg: Int = 0
        )

        data class Procedencia(
            val pais_ensamblaje: String = "",
            val wmi: String = ""
        )
    }
}