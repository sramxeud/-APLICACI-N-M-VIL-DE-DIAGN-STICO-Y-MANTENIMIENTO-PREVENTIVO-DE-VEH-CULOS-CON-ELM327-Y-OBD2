package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException

class AITestActivity : AppCompatActivity() {

    private lateinit var etPrompt: EditText
    private lateinit var btnGenerate: Button
    private lateinit var btnClear: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var tvResponse: TextView
    private lateinit var btnExample1: Button
    private lateinit var btnExample2: Button

    private companion object {
        const val OPENROUTER_API_KEY = "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"
        const val OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions"
        const val MODEL_CLAUDE_HAIKU = "anthropic/claude-3-haiku"
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .readTimeout(30, java.util.concurrent.TimeUnit.SECONDS)
        .build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ai_test)

        initViews()
        setupUI()
        showWelcomeMessage()
    }

    private fun initViews() {
        etPrompt = findViewById(R.id.etPrompt)
        btnGenerate = findViewById(R.id.btnGenerate)
        btnClear = findViewById(R.id.btnClear)
        progressBar = findViewById(R.id.progressBar)
        tvResponse = findViewById(R.id.tvResponse)
        btnExample1 = findViewById(R.id.btnExample1)
        btnExample2 = findViewById(R.id.btnExample2)
    }

    private fun setupUI() {
        btnGenerate.setOnClickListener {
            val prompt = etPrompt.text.toString().trim()
            if (prompt.isNotEmpty()) {
                testOpenRouterConnection(prompt)
            } else {
                Toast.makeText(this, "Por favor escribe una pregunta", Toast.LENGTH_SHORT).show()
            }
        }

        btnClear.setOnClickListener {
            etPrompt.setText("")
            tvResponse.text = "Escribe tu pregunta..."
        }

        btnExample1.setOnClickListener {
            etPrompt.setText("¿Qué es un código DTC en OBDII?")
        }

        btnExample2.setOnClickListener {
            etPrompt.setText("¿Qué es un PID en OBDII?")
        }
    }

    private fun showWelcomeMessage() {
        tvResponse.text = "🚗 **Asistente**\n\n" + "API Key configurada ✓"
    }

    private fun testOpenRouterConnection(prompt: String) {
        progressBar.visibility = View.VISIBLE
        btnGenerate.isEnabled = false
        tvResponse.text = "🔍 Consultando a la IA..."

        lifecycleScope.launch {
            try {
                val response = withContext(Dispatchers.IO) {
                    makeOpenRouterCall(prompt)
                }

                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    btnGenerate.isEnabled = true
                    tvResponse.text = "🤖 **Respuesta:**\n\n$response"
                }

            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    btnGenerate.isEnabled = true
                    showDetailedError(e)
                }
            }
        }
    }

    @Throws(IOException::class)
    private fun makeOpenRouterCall(prompt: String): String {
        val jsonBody = JSONObject().apply {
            put("model", MODEL_CLAUDE_HAIKU)
            put("messages", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("content", """
                        Eres un experto técnico en automoción, motores, sistemas OBD2 y diagnóstico vehicular. 
                        Responde de forma clara, técnica pero entendible en español.
                        Se conciso pero informativo (máximo 150 palabras).
                        
                        Pregunta: $prompt
                    """.trimIndent())
                })
            })
            put("max_tokens", 300)
        }

        val request = Request.Builder()
            .url(OPENROUTER_URL)
            .post(jsonBody.toString().toRequestBody("application/json".toMediaType()))
            .header("Authorization", "Bearer $OPENROUTER_API_KEY")
            .header("HTTP-Referer", "https://elm327app.com")
            .header("X-Title", "ELM327 Automotive App")
            .header("Content-Type", "application/json")
            .build()

        val response = client.newCall(request).execute()

        if (!response.isSuccessful) {
            val errorBody = response.body?.string() ?: "Sin detalles del error" // en caso de que a respuesta sea null muestra<-
            throw IOException("HTTP ${response.code}\n$errorBody")
        }

        val responseBody = response.body?.string() ?: throw IOException("Respuesta vacía del servidor")

        return parseOpenRouterResponse(responseBody)
    }

    private fun parseOpenRouterResponse(responseBody: String): String {
        return try {
            val jsonResponse = JSONObject(responseBody)

            if (jsonResponse.has("error")) {
                val errorObj = jsonResponse.getJSONObject("error")
                throw IOException("API: ${errorObj.getString("message")}")
            }

            val choices = jsonResponse.getJSONArray("choices")
            if (choices.length() == 0) {
                throw IOException("La IA no generó respuesta")
            }

            val firstChoice = choices.getJSONObject(0)
            val message = firstChoice.getJSONObject("message")
            message.getString("content").trim()

        } catch (e: Exception) {
            throw IOException("Error procesando respuesta: ${e.message}")
        }
    }

    private fun showDetailedError(e: Exception) {
        val errorMessage = when {
            e.message?.contains("404") == true || e.message?.contains("endpoints") == true ->
                "🔧 **Modelo no disponible**\n\n" +
                        "El modelo de IA no está disponible en OpenRouter.\n\n" +
                        "Solución: Cambiando a modelo compatible...\n\n" +
                        "💡 Prueba con Claude Haiku"

            e.message?.contains("400") == true ->
                "🔧 **Error de solicitud**\n\n" +
                        "Problema con la configuración.\n\n" +
                        "Detalles: ${e.message}"

            e.message?.contains("401") == true || e.message?.contains("403") == true ->
                "🔐 **Error de autenticación**\n\nAPI Key no válida."

            e.message?.contains("429") == true ->
                "⏰ **Límite excedido**\n\nEspera unos minutos."

            else ->
                "❌ **Error:**\n${e.message ?: "Error desconocido"}\n\n" +
                        "💡 **Solución:** Verifica tu conexión e intenta de nuevo."
        }

        tvResponse.text = errorMessage
    }
}
