package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.ktx.auth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase


class LoginActivity : AppCompatActivity() {

    private val TAG = "LoginActivity"
    private lateinit var auth: FirebaseAuth

    private lateinit var etEmail: EditText
    private lateinit var etPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnRegister: Button
    private lateinit var tvForgotPassword: TextView // NUEVO
    private lateinit var progressBar: ProgressBar
    private lateinit var tvError: TextView
    private val database = Firebase.database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login_simple)

        // INICIALIZAR FIREBASE AUTH
        try {
            auth = Firebase.auth
            Log.d(TAG, "Firebase Auth initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firebase Auth: ${e.message}")
            showCriticalError("Error de configuración. Reinstala la app.")
        }

        initViews()
        setupButtons()
    }

    private fun initViews() {
        try {
            etEmail = findViewById(R.id.etEmail)
            etPassword = findViewById(R.id.etPassword)
            btnLogin = findViewById(R.id.btnLogin)
            btnRegister = findViewById(R.id.btnRegister)
            tvForgotPassword = findViewById(R.id.tvForgotPassword) // NUEVO - INICIALIZAR
            progressBar = findViewById(R.id.progressBar)
            tvError = findViewById(R.id.tvError)

            Log.d(TAG, "All views initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing views: ${e.message}")
            showCriticalError("Error cargando la interfaz")
        }
    }

    private fun setupButtons() {
        btnLogin.setOnClickListener {
            Log.d(TAG, "Login button clicked")
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (validateInputs(email, password)) {
                loginUser(email, password)
            }
        }

        btnRegister.setOnClickListener {
            Log.d(TAG, "Register button clicked")
            val email = etEmail.text.toString().trim()
            val password = etPassword.text.toString().trim()

            if (validateInputs(email, password)) {
                registerUser(email, password)
            }
        }

        // NUEVO: Recuperación de contraseña
        tvForgotPassword.setOnClickListener {
            Log.d(TAG, "Forgot password clicked")
            showForgotPasswordDialog()
        }
    }

    private fun validateInputs(email: String, password: String): Boolean {
        if (email.isEmpty()) {
            showError("Por favor ingresa tu email")
            return false
        }

        if (password.isEmpty()) {
            showError("Por favor ingresa tu contraseña")
            return false
        }

        if (password.length < 6) {
            showError("La contraseña debe tener al menos 6 caracteres")
            return false
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Por favor ingresa un email válido")
            return false
        }

        hideError()
        return true
    }

    private fun loginUser(email: String, password: String) {
        showLoading(true)
        Log.d(TAG, "Attempting login for: $email")

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                showLoading(false)
                if (task.isSuccessful) {
                    Log.d(TAG, "Login successful for: $email")
                    Toast.makeText(this, "¡Bienvenido!", Toast.LENGTH_SHORT).show()
                    checkExistingProfile() // NUEVO: Verificar si ya tiene perfil
                } else {
                    Log.e(TAG, "Login failed: ${task.exception?.message}")
                    showError("Error al iniciar sesión: ${task.exception?.message}")
                }
            }
            .addOnFailureListener { e ->
                showLoading(false)
                Log.e(TAG, "Login failure: ${e.message}")
                showError("Error de conexión: ${e.message}")
            }
    }

    private fun registerUser(email: String, password: String) {
        showLoading(true)
        Log.d(TAG, "Attempting registration for: $email")

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    Log.d(TAG, "Registration successful for: $email")
                    checkExistingProfile() // NUEVO: Verificar si ya tiene perfil
                } else {
                    showLoading(false)
                    Log.e(TAG, "Registration failed: ${task.exception?.message}")
                    showError("Error al crear cuenta: ${task.exception?.message}")
                }
            }
            .addOnFailureListener { e ->
                showLoading(false)
                Log.e(TAG, "Registration failure: ${e.message}")
                showError("Error de conexión: ${e.message}")
            }
    }

    private fun checkExistingProfile() {
        val firebaseUser = auth.currentUser
        if (firebaseUser != null) {
            val userRef = Firebase.database.getReference("users").child(firebaseUser.uid)

            userRef.addListenerForSingleValueEvent(object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    if (snapshot.exists()) {
                        // El usuario ya tiene perfil, redirigir directamente
                        val userType = snapshot.child("userType").getValue(String::class.java) ?: "owner"
                        val name = snapshot.child("name").getValue(String::class.java) ?: ""
                        val phone = snapshot.child("phone").getValue(String::class.java) ?: ""

                        // Solo redirigir si tiene perfil completo
                        if (name.isNotEmpty() && phone.isNotEmpty() && userType.isNotEmpty()) {
                            Log.d(TAG, "Perfil existente encontrado, redirigiendo a: $userType")
                            redirectToUserActivity(userType)
                        } else {
                            // Tiene perfil pero incompleto, ir a ProfileActivity
                            goToProfileActivity()
                        }
                    } else {
                        // No tiene perfil, ir a ProfileActivity
                        goToProfileActivity()
                    }
                }

                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {
                    Log.e(TAG, "Error verificando perfil: ${error.message}")
                    // En caso de error, ir a ProfileActivity
                    goToProfileActivity()
                }
            })
        } else {
            goToProfileActivity()
        }
    }

    // NUEVO MÉTODO: Redirigir según tipo de usuario
    private fun redirectToUserActivity(userType: String) {
        val intent = when (userType) {
            "mechanic" -> Intent(this, MechanicActivity::class.java)
            else -> Intent(this, OwnerActivity::class.java)
        }

        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun goToProfileActivity() {
        try {
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting ProfileActivity: ${e.message}")
            Toast.makeText(this, "Error al cargar la aplicación", Toast.LENGTH_SHORT).show()
        }
    }
    private fun showForgotPasswordDialog() {
        val email = etEmail.text.toString().trim()

        if (email.isEmpty() || !android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showError("Ingresa un email válido para recuperar tu contraseña")
            return
        }

        showLoading(true)
        Log.d(TAG, "Sending password reset email to: $email")

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                showLoading(false)
                if (task.isSuccessful) {
                    Log.d(TAG, "Password reset email sent successfully")
                    Toast.makeText(this, "Email de recuperación enviado a $email", Toast.LENGTH_LONG).show()
                    hideError()
                } else {
                    Log.e(TAG, "Password reset failed: ${task.exception?.message}")
                    showError("Error al enviar email: ${task.exception?.message}")
                }
            }
            .addOnFailureListener { e ->
                showLoading(false)
                Log.e(TAG, "Password reset failure: ${e.message}")
                showError("Error de conexión: ${e.message}")
            }
    }

    private fun goToMainActivity() {
        try {
            // Cambiar de BluetoothActivity a ProfileActivity
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
            finish()
        } catch (e: Exception) {
            Log.e(TAG, "Error starting ProfileActivity: ${e.message}")
            Toast.makeText(this, "Error al cargar la aplicación", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showLoading(show: Boolean) {
        progressBar.visibility = if (show) View.VISIBLE else View.GONE
        btnLogin.isEnabled = !show
        btnRegister.isEnabled = !show
        tvForgotPassword.isEnabled = !show // NUEVO
    }

    private fun showError(message: String) {
        tvError.text = message
        tvError.visibility = View.VISIBLE
    }

    private fun showCriticalError(message: String) {
        btnLogin.isEnabled = false
        btnRegister.isEnabled = false
        tvForgotPassword.isEnabled = false // NUEVO
        tvError.text = message
        tvError.visibility = View.VISIBLE
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun hideError() {
        tvError.visibility = View.GONE
    }
}