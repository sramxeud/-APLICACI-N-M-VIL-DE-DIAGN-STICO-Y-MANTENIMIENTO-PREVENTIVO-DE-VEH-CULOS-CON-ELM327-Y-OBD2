package com.example.myapplicationelm327_v1

import android.bluetooth.BluetoothDevice
import android.content.Context
import androidx.core.content.edit

class OBD2ServiceFactory private constructor() {
    companion object {
        private var useSimulation = false

        fun setSimulationMode(enabled: Boolean, context: Context? = null) {
            useSimulation = enabled
            // Guardar preferencia si se proporciona contexto
            context?.getSharedPreferences("app_settings", Context.MODE_PRIVATE)?.edit {
                putBoolean("simulation_mode", enabled)
            }
        }

        fun initialize(context: Context? = null) {
            // Cargar preferencia guardada si se proporciona contexto
            context?.let {
                useSimulation = it.getSharedPreferences("app_settings", Context.MODE_PRIVATE)
                    .getBoolean("simulation_mode", false)
            }
        }

        fun createService(device: BluetoothDevice? = null): IOBD2Service {
            return if (useSimulation) {
                SimulatedOBD2Service()
            } else {
                RealOBD2Service(device)
            }
        }

        fun isSimulationMode(): Boolean = useSimulation
    }
}