package com.example.myapplicationelm327_v1

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions

object FirebaseInitializer {
    private const val TAG = "FirebaseInitializer"

    fun initialize(context: Context) {
        try {
            val apps = FirebaseApp.getApps(context)
            if (apps.isEmpty()) {
                Log.d(TAG, "Initializing Firebase manually...")

                val options = FirebaseOptions.Builder()
                    .setApplicationId("1:2536743036:android:715989de429870d45629f9")
                    .setApiKey("AIzaSyCBQM8SKuLROzmM3hG-MiD1acaRa9NuvGQ")
                    .setDatabaseUrl("https://dimanp-72555-default-rtdb.firebaseio.com")
                    .setProjectId("dimanp-72555")
                    .setStorageBucket("dimanp-72555.firebasestorage.app")
                    .build()

                FirebaseApp.initializeApp(context, options, "dimanp-72555")
                Log.d(TAG, "Firebase initialized successfully with manual configuration")
            } else {
                Log.d(TAG, "Firebase already initialized")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firebase: ${e.message}")
        }
    }
}