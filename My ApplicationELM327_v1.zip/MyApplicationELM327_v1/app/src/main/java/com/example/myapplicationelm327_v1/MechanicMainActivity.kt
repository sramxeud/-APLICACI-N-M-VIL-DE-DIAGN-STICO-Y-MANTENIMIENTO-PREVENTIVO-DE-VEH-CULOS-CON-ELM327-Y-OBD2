package com.example.myapplicationelm327_v1

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MotionEvent
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.widget.NestedScrollView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class MechanicMainActivity : AppCompatActivity() {

    private lateinit var btnMenu: ImageButton
    private lateinit var layoutMenu: LinearLayout
    private lateinit var opcion1: TextView
    private lateinit var opcion2: TextView
    private lateinit var opcion3: TextView

    private var assignmentsListener: ValueEventListener? = null
    private var ownersListener: ValueEventListener? = null
    private var vehiclesListener: ValueEventListener? = null
    private var vehicleDetailsListener: ValueEventListener? = null
    private var techDetailsListener: ValueEventListener? = null

    // Views para selección
    private lateinit var tvCurrentOwner: TextView
    private lateinit var tvCurrentVehicle: TextView
    private lateinit var btnSelectOwner: Button
    private lateinit var btnSelectVehicle: Button

    // Views para información
    private lateinit var scrollVehicleInfo: NestedScrollView
    private lateinit var scrollTechInfo: NestedScrollView
    private lateinit var tvVehicleDetails: TextView
    private lateinit var tvTechDetails: TextView

    // Firebase
    private val auth = FirebaseAuth.getInstance()
    private var currentMechanicId: String = ""

    // Datos
    private var assignments: List<Assignment> = emptyList()
    private var owners: List<Owner> = emptyList()
    private var vehicles: List<Vehicle> = emptyList()
    private var selectedOwner: Owner? = null
    private var selectedVehicle: Vehicle? = null
    private lateinit var btnDisconnect: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_mechanic_main)
        supportActionBar?.hide()

        initViews()
        setupMenuDesplegable()
        setupClickListeners()

        currentMechanicId = auth.currentUser?.uid ?: ""
        if (currentMechanicId.isNotEmpty()) {
            setupRealTimeListeners()
        } else {
            Toast.makeText(this, "Error: Usuario no autenticado", Toast.LENGTH_SHORT).show()
            finish()
        }
    }
    private fun setupRealTimeListeners() {
        setupAssignmentsListener()
    }
    private fun setupAssignmentsListener() {
        val assignmentsRef = Firebase.database.getReference("assignments")

        assignmentsListener = assignmentsRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    Log.d("MechanicMain", "TODAS las assignments en la base de datos:")
                    val allAssignments = snapshot.children.mapNotNull {
                        try {
                            val assignment = it.getValue(Assignment::class.java)
                            Log.d("MechanicMain", "Assignment: ${assignment?.id} - mechanic: ${assignment?.mechanicId}")
                            assignment
                        } catch (e: Exception) {
                            null
                        }
                    }

                    // Filtrar localmente por mechanicId
                    assignments = allAssignments.filter { it.mechanicId == currentMechanicId }

                    Log.d("MechanicMain", "Assignments filtrados para $currentMechanicId: ${assignments.size}")
                    assignments.forEach {
                        Log.d("MechanicMain", "Assignment: ${it.id} - owner: ${it.ownerId} - vehicle: ${it.vehicleId}")
                    }

                    loadOwnersFromAssignments()
                } catch (e: Exception) {
                    Log.e("MechanicMain", "Error processing assignments: ${e.message}")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("MechanicMain", "Database error: ${error.message}")
            }
        })
    }

    private fun initViews() {

        btnMenu = findViewById(R.id.btnMenu)
        layoutMenu = findViewById(R.id.layoutMenuDesplegable)
        opcion1 = findViewById(R.id.opcion1)
        opcion2 = findViewById(R.id.opcion2)
        opcion3 = findViewById(R.id.opcion3)

        tvCurrentOwner = findViewById(R.id.tvCurrentOwner)
        tvCurrentVehicle = findViewById(R.id.tvCurrentVehicle)
        btnSelectOwner = findViewById(R.id.btnSelectOwner)
        btnSelectVehicle = findViewById(R.id.btnSelectVehicle)

        scrollVehicleInfo = findViewById(R.id.scrollVehicleInfo)
        scrollTechInfo = findViewById(R.id.scrollTechInfo)
        tvVehicleDetails = findViewById(R.id.tvVehicleDetails)
        tvTechDetails = findViewById(R.id.tvTechDetails)
        btnDisconnect = findViewById(R.id.btnDisconnect)
    }

    private fun setupClickListeners() {
        btnSelectOwner.setOnClickListener {
            showOwnerSelectionDialog()
        }

        btnSelectVehicle.setOnClickListener {
            if (selectedOwner == null) {
                Toast.makeText(this, "Primero selecciona un dueño", Toast.LENGTH_SHORT).show()
            } else {
                showVehicleSelectionDialog()
            }
        }
        btnDisconnect.setOnClickListener {
            val intent = Intent(this, MechanicActivity::class.java)
            startActivity(intent)
        }
    }


    private fun loadAssignments() {
        val assignmentsRef = Firebase.database.getReference("assignments")
        assignmentsRef.orderByChild("mechanicId").equalTo(currentMechanicId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    try {
                        assignments = snapshot.children.mapNotNull {
                            try {
                                it.getValue(Assignment::class.java)
                            } catch (e: Exception) {
                                Log.e("MechanicMain", "Error parsing assignment: ${e.message}")
                                null
                            }
                        }

                        Log.d("MechanicMain", "Assignments encontrados: ${assignments.size}")
                        loadOwnersFromAssignments()
                    } catch (e: Exception) {
                        Log.e("MechanicMain", "Error processing assignments: ${e.message}")
                        Toast.makeText(this@MechanicMainActivity, "Error cargando asignaciones", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MechanicMain", "Database error: ${error.message}")
                    Toast.makeText(this@MechanicMainActivity, "Error cargando asignaciones", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun loadOwnersFromAssignments() {
        val ownerIds = assignments.map { it.ownerId }.distinct()

        // Remover listener anterior si existe
        ownersListener?.let {
            Firebase.database.getReference("users").removeEventListener(it)
        }

        if (ownerIds.isEmpty()) {
            owners = emptyList()
            vehicles = emptyList()
            selectedOwner = null
            selectedVehicle = null
            updateOwnerInfo()
            updateVehicleInfo()
            clearDetails()
            Toast.makeText(this, "No tienes asignaciones activas", Toast.LENGTH_SHORT).show()
            return
        }

        val ownersRef = Firebase.database.getReference("users")
        ownersListener = ownersRef.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                owners = snapshot.children.mapNotNull { ds ->
                    try {
                        val user = ds.getValue(User::class.java)
                        if (user != null && ownerIds.contains(ds.key) && user.userType == "owner") {
                            Owner(ds.key ?: "", user.name, user.email, user.phone)
                        } else {
                            null
                        }
                    } catch (e: Exception) {
                        null
                    }
                }

                Log.d("MechanicMain", "Owners actualizados: ${owners.size}")

                // Actualizar selección actual si el dueño seleccionado ya no está disponible
                selectedOwner = selectedOwner?.let { currentOwner ->
                    owners.find { it.id == currentOwner.id }
                }

                if (owners.isNotEmpty() && selectedOwner == null) {
                    selectedOwner = owners.first()
                }

                updateOwnerInfo()
                loadVehiclesForOwner()
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("MechanicMain", "Error loading owners: ${error.message}")
            }
        })
    }


    private fun loadVehiclesForOwner() {
        // Remover listener anterior si existe
        vehiclesListener?.let {
            Firebase.database.getReference("vehicles").removeEventListener(it)
        }

        selectedOwner?.let { owner ->
            val ownerVehicleIds = assignments
                .filter { it.ownerId == owner.id }
                .map { it.vehicleId }
                .distinct()

            if (ownerVehicleIds.isEmpty()) {
                vehicles = emptyList()
                selectedVehicle = null
                updateVehicleInfo()
                clearDetails()
                return
            }

            val vehiclesRef = Firebase.database.getReference("vehicles")
            vehiclesListener = vehiclesRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    vehicles = snapshot.children.mapNotNull { ds ->
                        try {
                            val vehicle = ds.getValue(Vehicle::class.java)
                            if (vehicle != null && ownerVehicleIds.contains(vehicle.id)) {
                                vehicle
                            } else {
                                null
                            }
                        } catch (e: Exception) {
                            null
                        }
                    }

                    Log.d("MechanicMain", "Vehículos actualizados: ${vehicles.size}")

                    // Actualizar selección actual si el vehículo seleccionado ya no está disponible
                    selectedVehicle = selectedVehicle?.let { currentVehicle ->
                        vehicles.find { it.id == currentVehicle.id }
                    }

                    if (vehicles.isNotEmpty() && selectedVehicle == null) {
                        selectedVehicle = vehicles.first()
                    }

                    updateVehicleInfo()

                    // Cargar detalles si hay un vehículo seleccionado
                    selectedVehicle?.let {
                        loadVehicleDetails()
                        loadTechDetails()
                    } ?: clearDetails()
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MechanicMain", "Error loading vehicles: ${error.message}")
                }
            })
        } ?: run {
            vehicles = emptyList()
            selectedVehicle = null
            updateVehicleInfo()
            clearDetails()
        }
    }

    private fun showOwnerSelectionDialog() {
        if (owners.isEmpty()) {
            Toast.makeText(this, "No hay dueños disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        val ownerNames = owners.map { it.name }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Seleccionar Dueño")
            .setItems(ownerNames) { _, which ->
                selectedOwner = owners[which]
                updateOwnerInfo()
                loadVehiclesForOwner()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showVehicleSelectionDialog() {
        if (vehicles.isEmpty()) {
            Toast.makeText(this, "No hay vehículos disponibles", Toast.LENGTH_SHORT).show()
            return
        }

        val vehicleNames = vehicles.map {
            if (it.vpicData.marca.isNotEmpty()) {
                "${it.vpicData.marca} ${it.vpicData.modelo} - ${it.vin}"
            } else {
                "${it.nombre} - ${it.vin}"
            }
        }.toTypedArray()

        AlertDialog.Builder(this)
            .setTitle("Seleccionar Vehículo")
            .setItems(vehicleNames) { _, which ->
                selectedVehicle = vehicles[which]
                updateVehicleInfo()
                loadVehicleDetails()
                loadTechDetails()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateOwnerInfo() {
        runOnUiThread {
            selectedOwner?.let { owner ->
                tvCurrentOwner.text = "Dueño: ${owner.name}"
                btnSelectVehicle.isEnabled = true
            } ?: run {
                tvCurrentOwner.text = "No hay dueño seleccionado"
                btnSelectVehicle.isEnabled = false
            }
        }
    }

    private fun updateVehicleInfo() {
        runOnUiThread {
            selectedVehicle?.let { vehicle ->
                val displayName = if (vehicle.vpicData.marca.isNotEmpty()) {
                    "${vehicle.vpicData.marca} ${vehicle.vpicData.modelo}"
                } else {
                    vehicle.nombre
                }
                tvCurrentVehicle.text = "Vehículo: $displayName"
            } ?: run {
                tvCurrentVehicle.text = "No hay vehículo seleccionado"
            }
        }
    }

    private fun loadVehicleDetails() {
        selectedVehicle?.let { vehicle ->
            val vehicleInfo = """
                🚗 INFORMACIÓN DEL VEHÍCULO
                
                📝 Nombre: ${vehicle.nombre}
                🔢 VIN: ${vehicle.vin}
                👤 Dueño: ${selectedOwner?.name ?: "N/A"}
                
                🎨 VPIC Data:
                • Marca: ${vehicle.vpicData.marca}
                • Modelo: ${vehicle.vpicData.modelo}
                • Año: ${vehicle.vpicData.año}
                • Color: ${vehicle.vpicData.color}
                • Motor: ${vehicle.vpicData.motor}
                • Transmisión: ${vehicle.vpicData.transmision}
                • Combustible: ${vehicle.vpicData.combustible}
                
                ⚙️ Datos de Sensores (Última lectura):
                • RPM: ${vehicle.sensorData.rpm}
                • Velocidad: ${vehicle.sensorData.velocidad}
                • Temperatura Refrigerante: ${vehicle.sensorData.tempRefrigerante}
                • Carga Motor: ${vehicle.sensorData.cargaMotor}
                • Nivel Combustible: ${vehicle.sensorData.nivelCombustible}
                
                ⚠️ Códigos de Error:
                • Activos: ${vehicle.errorData.codigosActivos.joinToString()}
                • Pendientes: ${vehicle.errorData.codigosPendientes.joinToString()}
            """.trimIndent()

            runOnUiThread {
                tvVehicleDetails.text = vehicleInfo
            }
        }
    }

    private fun loadTechDetails() {
        // Remover listener anterior si existe
        techDetailsListener?.let {
            Firebase.database.getReference("vpic").removeEventListener(it)
        }

        selectedVehicle?.vin?.let { vin ->
            val vpicRef = Firebase.database.getReference("vpic/vehiculos/$vin")
            techDetailsListener = vpicRef.addValueEventListener(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        try {
                            val vpicInfo = snapshot.getValue(VpicVehicle::class.java)
                            displayTechInfo(vpicInfo)
                        } catch (e: Exception) {
                            Log.e("MechanicMain", "Error parsing VPIC data: ${e.message}")
                            displayNoTechInfo()
                        }
                    } else {
                        displayNoTechInfo()
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("MechanicMain", "Error loading VPIC data: ${error.message}")
                    displayNoTechInfo()
                }
            })
        } ?: displayNoTechInfo()
    }

    private fun displayTechInfo(vpicInfo: VpicVehicle?) {
        vpicInfo?.let { info ->
            val techInfo = """
                🔧 INFORMACIÓN TÉCNICA
                
                🚀 Especificaciones Técnicas:
                • Motor: ${info.especificaciones_tecnicas.motor}
                • Cilindrada: ${info.especificaciones_tecnicas.cilindrada_cc} cc
                • Potencia: ${info.especificaciones_tecnicas.potencia_hp} HP
                • Torque: ${info.especificaciones_tecnicas.torque_nm} Nm
                • Compresión: ${info.especificaciones_tecnicas.compresion}
                • Tracción: ${info.especificaciones_tecnicas.traccion}
                • Transmisión: ${info.especificaciones_tecnicas.transmision}
                • Combustible: ${info.especificaciones_tecnicas.combustible}
                • Emisiones: ${info.especificaciones_tecnicas.emisiones}
                
                📏 Dimensiones y Peso:
                • Largo: ${info.dimensiones_peso.largo_mm} mm
                • Ancho: ${info.dimensiones_peso.ancho_mm} mm
                • Alto: ${info.dimensiones_peso.alto_mm} mm
                • Peso: ${info.dimensiones_peso.peso_kg} kg
                
                ⛽ Consumo y Eficiencia:
                • Ciudad: ${info.consumo_eficiencia.ciudad_lt_100km} L/100km
                • Carretera: ${info.consumo_eficiencia.carretera_lt_100km} L/100km
                • Mixto: ${info.consumo_eficiencia.mixto_lt_100km} L/100km
                • Capacidad Tanque: ${info.consumo_eficiencia.capacidad_tanque_lt} L
                
                📊 Rangos Operativos:
                • RPM Óptima: ${info.rangos_operativos.rpm.optima}
                • RPM Alerta: ${info.rangos_operativos.rpm.alerta}
                • Temp. Motor Óptima: ${info.rangos_operativos.temperatura_motor.optima}°C
                • Tensión Batería: ${info.rangos_operativos.tension_bateria.min}-${info.rangos_operativos.tension_bateria.max}V
                
                🌍 Procedencia:
                • País de Ensamblaje: ${info.procedencia.pais_ensamblaje}
                • WMI: ${info.procedencia.wmi}
            """.trimIndent()

            runOnUiThread {
                tvTechDetails.text = techInfo
            }
        } ?: displayNoTechInfo()
    }

    private fun displayNoTechInfo() {
        runOnUiThread {
            tvTechDetails.text = "🔧 INFORMACIÓN TÉCNICA\n\nNo hay información técnica disponible para este VIN"
        }
    }

    private fun clearDetails() {
        runOnUiThread {
            tvVehicleDetails.text = "Selecciona un vehículo para ver la información"
            tvTechDetails.text = "Selecciona un vehículo para ver la información técnica"
        }
    }

    private fun setupMenuDesplegable() {
        // Configurar menú para mecánicos
        setupMechanicMenu()

        btnMenu.setOnClickListener {
            if (layoutMenu.visibility == View.VISIBLE) {
                layoutMenu.visibility = View.GONE
            } else {
                layoutMenu.visibility = View.VISIBLE
            }
        }

        setupCerrarMenuAlTocarFuera()
    }

    private fun setupMechanicMenu() {
        opcion1.text = "Modificar Perfil"
        opcion2.text = "Lista de Dueños"
        opcion3.text = "Cerrar sesión"

        opcion1.setOnClickListener {
            val intent = Intent(this, ProfileActivity::class.java)
            intent.putExtra("EDIT_MODE", true)
            startActivity(intent)
            layoutMenu.visibility = View.GONE
        }

        opcion2.setOnClickListener {
            showOwnerSelectionDialog()
            layoutMenu.visibility = View.GONE
        }

        opcion3.setOnClickListener {
            auth.signOut()
            Toast.makeText(this, "Sesión cerrada", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
            layoutMenu.visibility = View.GONE
        }
    }

    private fun setupCerrarMenuAlTocarFuera() {
        val rootView = findViewById<View>(android.R.id.content)

        rootView.setOnTouchListener { _, event ->
            if (event.action == MotionEvent.ACTION_DOWN &&
                layoutMenu.visibility == View.VISIBLE) {

                val location = IntArray(2)
                layoutMenu.getLocationOnScreen(location)
                val menuRect = android.graphics.Rect(
                    location[0], location[1],
                    location[0] + layoutMenu.width,
                    location[1] + layoutMenu.height
                )

                val btnLocation = IntArray(2)
                btnMenu.getLocationOnScreen(btnLocation)
                val btnRect = android.graphics.Rect(
                    btnLocation[0], btnLocation[1],
                    btnLocation[0] + btnMenu.width,
                    btnLocation[1] + btnMenu.height
                )

                // Si se toca fuera del menú Y fuera del botón, cerrar menú
                if (!menuRect.contains(event.rawX.toInt(), event.rawY.toInt()) &&
                    !btnRect.contains(event.rawX.toInt(), event.rawY.toInt())) {
                    layoutMenu.visibility = View.GONE
                }
            }
            false
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        // Limpiar todos los listeners cuando la actividad se destruya
        assignmentsListener?.let {
            Firebase.database.getReference("assignments").removeEventListener(it)
        }
        ownersListener?.let {
            Firebase.database.getReference("users").removeEventListener(it)
        }
        vehiclesListener?.let {
            Firebase.database.getReference("vehicles").removeEventListener(it)
        }
        vehicleDetailsListener?.let {
            Firebase.database.getReference("vehicles").removeEventListener(it)
        }
        techDetailsListener?.let {
            Firebase.database.getReference("vpic").removeEventListener(it)
        }
    }


    // Data Classes
    data class Assignment(
        val id: String = "",
        val mechanicId: String = "",
        val ownerId: String = "",
        val vehicleId: String = "",
        val vin: String = "",
        val assignedAt: Long = 0L,
        val permissions: List<String> = emptyList(),
        val status: String = "",
        val createdAt: Long = 0L,
        val updatedAt: Long = 0L
    )

    data class Owner(
        val id: String = "",
        val name: String = "",
        val email: String = "",
        val phone: String = ""
    )

    data class User(
        val name: String = "",
        val email: String = "",
        val phone: String = "",
        val userType: String = ""
    )

    // Reutilizar las data classes de Vehicle de MainActivity
    // y agregar VpicVehicle para la información técnica
    data class VpicVehicle(
        val info_general: VpicGeneral = VpicGeneral(),
        val especificaciones_tecnicas: TechSpecs = TechSpecs(),
        val dimensiones_peso: Dimensions = Dimensions(),
        val consumo_eficiencia: Consumption = Consumption(),
        val rangos_operativos: OperatingRanges = OperatingRanges(),
        val procedencia: Origin = Origin()
    )

    data class VpicGeneral(
        val marca: String = "",
        val modelo: String = "",
        val ano: Int = 0,
        val color: String = "",
        val carroceria: String = "",
        val vin: String = ""
    )

    data class TechSpecs(
        val motor: String = "",
        val cilindrada_cc: Int = 0,
        val potencia_hp: Int = 0,
        val torque_nm: Int = 0,
        val compresion: String = "",
        val transmision: String = "",
        val traccion: String = "",
        val combustible: String = "",
        val emisiones: String = ""
    )

    data class Dimensions(
        val largo_mm: Int = 0,
        val ancho_mm: Int = 0,
        val alto_mm: Int = 0,
        val peso_kg: Int = 0
    )

    data class Consumption(
        val ciudad_lt_100km: Double = 0.0,
        val carretera_lt_100km: Double = 0.0,
        val mixto_lt_100km: Double = 0.0,
        val capacidad_tanque_lt: Double = 0.0
    )

    data class OperatingRanges(
        val rpm: RpmRange = RpmRange(),
        val temperatura_motor: TempRange = TempRange(),
        val tension_bateria: VoltageRange = VoltageRange()
    )

    data class RpmRange(
        val min: Int = 0,
        val max: Int = 0,
        val optima: Int = 0,
        val alerta: Int = 0
    )

    data class TempRange(
        val min: Int = 0,
        val max: Int = 0,
        val optima: Int = 0
    )

    data class VoltageRange(
        val min: Double = 0.0,
        val max: Double = 0.0
    )

    data class Origin(
        val pais_ensamblaje: String = "",
        val wmi: String = ""
    )
}