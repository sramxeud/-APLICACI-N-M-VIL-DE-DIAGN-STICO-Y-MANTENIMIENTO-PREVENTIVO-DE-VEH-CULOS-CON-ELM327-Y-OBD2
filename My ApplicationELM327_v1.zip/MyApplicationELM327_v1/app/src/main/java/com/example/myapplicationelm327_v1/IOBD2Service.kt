package com.example.myapplicationelm327_v1

interface IOBD2Service {
    fun connect(deviceAddress: String): Boolean
    fun disconnect()
    fun readPID(pid: String): String
    fun isConnected(): Boolean
    fun setConnectionListener(listener: ELM327Connection.ConnectionListener?)
}