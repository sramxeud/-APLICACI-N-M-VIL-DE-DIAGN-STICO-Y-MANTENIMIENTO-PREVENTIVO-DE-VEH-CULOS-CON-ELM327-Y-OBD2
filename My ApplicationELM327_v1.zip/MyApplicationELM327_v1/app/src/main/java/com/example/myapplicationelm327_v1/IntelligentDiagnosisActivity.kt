package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext

class IntelligentDiagnosisActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var layoutContent: LinearLayout
    private lateinit var tableContainer: LinearLayout
    private lateinit var tvProblems: TextView
    private lateinit var tvCauses: TextView
    private lateinit var tvSolutions: TextView
    private lateinit var btnAskQuestion: Button
    private lateinit var problemsSection: LinearLayout
    private lateinit var causesSection: LinearLayout
    private lateinit var solutionsSection: LinearLayout

    private val aiService = AIService.getInstance()
    private val database = Firebase.database

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_intelligent_diagnosis)
        supportActionBar?.hide()

        initViews()
        performIntelligentDiagnosis()
    }

    private fun initViews() {
        progressBar = findViewById(R.id.progressBar)
        layoutContent = findViewById(R.id.layoutContent)
        tableContainer = findViewById(R.id.tableContainer)
        tvProblems = findViewById(R.id.tvProblems)
        tvCauses = findViewById(R.id.tvCauses)
        tvSolutions = findViewById(R.id.tvSolutions)
        btnAskQuestion = findViewById(R.id.btnAskQuestion)
        problemsSection = findViewById(R.id.problemsSection)
        causesSection = findViewById(R.id.causesSection)
        solutionsSection = findViewById(R.id.solutionsSection)

        findViewById<Button>(R.id.btnBack).setOnClickListener {
            finish()
        }

        btnAskQuestion.setOnClickListener {
            showQuestionDialog()
        }
    }

    private fun performIntelligentDiagnosis() {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty()) {
            Toast.makeText(this, "No hay vehículo seleccionado", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        showProgress(true)

        lifecycleScope.launch {
            try {
                // 1. Obtener datos del vehículo desde Firebase
                val vehicle = getVehicleFromFirebase(currentVIN)
                if (vehicle == null) {
                    showProgress(false)
                    Toast.makeText(this@IntelligentDiagnosisActivity, "No se encontró el vehículo", Toast.LENGTH_SHORT).show()
                    finish()
                    return@launch
                }

                // 2. Obtener datos técnicos VPIC
                val vpicTechnicalData = getVpicTechnicalData(currentVIN)

                // 3. Obtener descripciones de códigos DTC
                val dtcDescriptions = getDtcDescriptions(vehicle.errorData.codigosActivos)

                // 4. Generar prompt combinado
                val diagnosticPrompt = generateDetailedDiagnosticPrompt(vehicle, vpicTechnicalData, dtcDescriptions)

                // 5. Llamar a IA
                val result = aiService.getAIAnalysis(diagnosticPrompt)

                // 6. Procesar y mostrar resultados
                when (result) {
                    is AIService.Result.Success -> {
                        processAndDisplayResults(vehicle, vpicTechnicalData, result.data, dtcDescriptions)
                    }
                    is AIService.Result.Error -> {
                        throw result.exception
                    }
                }

            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(this@IntelligentDiagnosisActivity, "Error en diagnóstico: ${e.message}", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    private fun generateDetailedDiagnosticPrompt(
        vehicle: Vehicle,
        vpicData: VpicTechnicalData?,
        dtcDescriptions: Map<String, String>
    ): String {
        return """
            Analiza COMPLETAMENTE el vehículo ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo} (VIN: ${vehicle.vin})
            
            DATOS EN TIEMPO REAL:
            • RPM: ${vehicle.sensorData.rpm}
            • Temperatura refrigerante: ${vehicle.sensorData.tempRefrigerante}
            • Carga motor: ${vehicle.sensorData.cargaMotor}
            • Velocidad: ${vehicle.sensorData.velocidad}
            • Nivel combustible: ${vehicle.sensorData.nivelCombustible}
            • Posición acelerador: ${vehicle.sensorData.posicionAcelerador}
            • Presión MAP: ${vehicle.sensorData.presionMAP}
            • Avance encendido: ${vehicle.sensorData.avanceEncendido}
            
            CÓDIGOS DE ERROR ACTIVOS:
            ${vehicle.errorData.codigosActivos.joinToString("\n") { "• $it: ${dtcDescriptions[it] ?: "Sin descripción"}" }}
            
            ESPECIFICACIONES TÉCNICAS:
            ${if (vpicData != null) """
                • Motor: ${vpicData.especificaciones_tecnicas.motor}
                • Potencia: ${vpicData.especificaciones_tecnicas.potencia_hp} HP
                • Torque: ${vpicData.especificaciones_tecnicas.torque_nm} Nm
                • Combustible: ${vpicData.especificaciones_tecnicas.combustible}
                • RPM óptimas: ${vpicData.rangos_operativos.rpm.optima}
                • Temp. motor óptima: ${vpicData.rangos_operativos.temperatura_motor.optima}°C
                • Temp. motor mín-máx: ${vpicData.rangos_operativos.temperatura_motor.min}°C - ${vpicData.rangos_operativos.temperatura_motor.max}°C
            """.trimIndent() else "No hay datos técnicos"}
            
            RESPONDE EXCLUSIVAMENTE en este formato:

            PROBLEMAS:
            [Lista los problemas principales encontrados, máximo 3-5 problemas específicos]

            CAUSAS:
            [Explica las posibles causas de cada problema identificado]

            SOLUCIONES:
            [Sugiere soluciones específicas y prácticas para cada problema]

            Responde en español, sé técnico pero claro y organizado.
        """.trimIndent()
    }

    private fun processAndDisplayResults(vehicle: Vehicle, vpicData: VpicTechnicalData?, aiAnalysis: String, dtcDescriptions: Map<String, String>) {
        showProgress(false)
        layoutContent.isVisible = true

        // Parsear la respuesta de IA para separar problemas, causas y soluciones
        val sections = parseAiResponse(aiAnalysis)

        // Mostrar las secciones
        showProblemsSection(sections["PROBLEMAS"] ?: "No se pudieron identificar problemas específicos")
        showCausesSection(sections["CAUSAS"] ?: "No se determinaron causas específicas")
        showSolutionsSection(sections["SOLUCIONES"] ?: "No se sugirieron soluciones específicas")

        // Construir tabla de sensores
        buildSensorTable(vehicle, vpicData, dtcDescriptions)
    }

    private fun showProblemsSection(problems: String) {
        problemsSection.isVisible = true
        tvProblems.text = formatSectionText(problems)
    }

    private fun showCausesSection(causes: String) {
        causesSection.isVisible = true
        tvCauses.text = formatSectionText(causes)
    }

    private fun showSolutionsSection(solutions: String) {
        solutionsSection.isVisible = true
        tvSolutions.text = formatSectionText(solutions)
    }

    private fun formatSectionText(text: String): String {
        // Formatear el texto para mejor presentación
        return text.trim()
            .replace("• ", "• ")
            .replace("- ", "• ")
            .replace("\n", "\n\n")
    }

    private fun parseAiResponse(aiAnalysis: String): Map<String, String> {
        val sections = mutableMapOf<String, String>()
        val lines = aiAnalysis.split("\n")
        var currentSection = ""
        var currentContent = StringBuilder()

        for (line in lines) {
            val trimmedLine = line.trim()
            when {
                trimmedLine.startsWith("PROBLEMAS:") -> {
                    if (currentSection.isNotEmpty()) {
                        sections[currentSection] = currentContent.toString().trim()
                    }
                    currentSection = "PROBLEMAS"
                    currentContent = StringBuilder(trimmedLine.removePrefix("PROBLEMAS:").trim())
                }
                trimmedLine.startsWith("CAUSAS:") -> {
                    if (currentSection.isNotEmpty()) {
                        sections[currentSection] = currentContent.toString().trim()
                    }
                    currentSection = "CAUSAS"
                    currentContent = StringBuilder(trimmedLine.removePrefix("CAUSAS:").trim())
                }
                trimmedLine.startsWith("SOLUCIONES:") -> {
                    if (currentSection.isNotEmpty()) {
                        sections[currentSection] = currentContent.toString().trim()
                    }
                    currentSection = "SOLUCIONES"
                    currentContent = StringBuilder(trimmedLine.removePrefix("SOLUCIONES:").trim())
                }
                else -> {
                    if (currentSection.isNotEmpty() && trimmedLine.isNotEmpty()) {
                        if (currentContent.isNotEmpty()) {
                            currentContent.append("\n")
                        }
                        currentContent.append(trimmedLine)
                    }
                }
            }
        }

        if (currentSection.isNotEmpty()) {
            sections[currentSection] = currentContent.toString().trim()
        }

        return sections
    }

    private fun buildSensorTable(vehicle: Vehicle, vpicData: VpicTechnicalData?, dtcDescriptions: Map<String, String>) {
        tableContainer.removeAllViews()

        // Crear HorizontalScrollView para la tabla
        val horizontalScrollView = HorizontalScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val tableLayout = TableLayout(this).apply {
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT
            )
            isStretchAllColumns = true
        }

        // Crear cabecera de la tabla
        val headerRow = TableRow(this).apply {
            setBackgroundColor(0xFF2196F3.toInt())
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val headers = arrayOf("Sensor", "Lectura", "Rango Esperado", "Estado", "Descripción Técnica")

        headers.forEach { header ->
            val textView = TextView(this).apply {
                text = header
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(16, 12, 16, 12)
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                gravity = Gravity.CENTER
            }
            headerRow.addView(textView)
        }

        tableLayout.addView(headerRow)

        // Agregar sensores principales
        addSensorRow(tableLayout, "RPM", vehicle.sensorData.rpm,
            vpicData?.rangos_operativos?.rpm?.let { "${it.min} - ${it.max}" } ?: "N/A",
            vpicData?.rangos_operativos?.rpm?.let {
                val rpmValue = vehicle.sensorData.rpm.replace(" rpm", "").toIntOrNull() ?: 0
                if (rpmValue in it.min..it.max) "✅ Normal" else "❌ Fuera de rango"
            } ?: "⚠️ Sin referencia",
            "Revoluciones por minuto del motor")

        addSensorRow(tableLayout, "Temp. Motor", vehicle.sensorData.tempRefrigerante,
            vpicData?.rangos_operativos?.temperatura_motor?.let { "${it.min} - ${it.max}°C" } ?: "N/A",
            vpicData?.rangos_operativos?.temperatura_motor?.let {
                val tempValue = vehicle.sensorData.tempRefrigerante.replace("°C", "").toIntOrNull() ?: 0
                if (tempValue in it.min..it.max) "✅ Normal" else "❌ Fuera de rango"
            } ?: "⚠️ Sin referencia",
            "Temperatura del refrigerante del motor")

        addSensorRow(tableLayout, "Carga Motor", vehicle.sensorData.cargaMotor,
            "0 - 100%",
            if ((vehicle.sensorData.cargaMotor.replace("%", "").toIntOrNull() ?: 0) in 0..100) "✅ Normal" else "❌ Fuera de rango",
            "Porcentaje de carga del motor")

        addSensorRow(tableLayout, "Velocidad", vehicle.sensorData.velocidad,
            "0 - 200 km/h",
            "✅ Normal",
            "Velocidad del vehículo")

        addSensorRow(tableLayout, "Combustible", vehicle.sensorData.nivelCombustible,
            "0 - 100%",
            if ((vehicle.sensorData.nivelCombustible.replace("%", "").toIntOrNull() ?: 0) in 0..100) "✅ Normal" else "❌ Fuera de rango",
            "Nivel de combustible en el tanque")

        // Agregar códigos DTC
        vehicle.errorData.codigosActivos.forEach { code ->
            addSensorRow(tableLayout, "DTC", code, "N/A", "❌ Error", dtcDescriptions[code] ?: "Código de error no identificado")
        }

        horizontalScrollView.addView(tableLayout)
        tableContainer.addView(horizontalScrollView)
    }

    private fun addSensorRow(tableLayout: TableLayout, sensor: String, lectura: String, rangoEsperado: String, estado: String, descripcion: String) {
        val row = TableRow(this).apply {
            layoutParams = TableLayout.LayoutParams(
                TableLayout.LayoutParams.WRAP_CONTENT,
                TableLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val texts = arrayOf(sensor, lectura, rangoEsperado, estado, descripcion)
        val background = if (tableLayout.childCount % 2 == 1) 0xFFFAFAFA.toInt() else 0xFFFFFFFF.toInt()

        texts.forEach { text ->
            val textView = TextView(this).apply {
                this.text = text
                setPadding(16, 12, 16, 12)
                textSize = 12f
                gravity = Gravity.CENTER
                setBackgroundColor(background)
            }
            row.addView(textView)
        }

        tableLayout.addView(row)
    }

    private fun showQuestionDialog() {
        val input = EditText(this)
        input.hint = "Ej: ¿Cómo soluciono el código P0101?"

        AlertDialog.Builder(this)
            .setTitle("🤔 Pregunta al Experto")
            .setView(input)
            .setPositiveButton("Enviar") { _, _ ->
                val question = input.text.toString().trim()
                if (question.isNotEmpty()) {
                    askQuestion(question)
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun askQuestion(question: String) {
        showProgress(true)
        lifecycleScope.launch {
            try {
                val currentVIN = ELM327Manager.currentVIN ?: "VIN desconocido"
                val vehicle = getVehicleFromFirebase(currentVIN)
                val vpicData = getVpicTechnicalData(currentVIN)

                val marca = vehicle?.vpicData?.marca ?: "Marca desconocida"
                val modelo = vehicle?.vpicData?.modelo ?: "Modelo desconocido"
                val rpm = vehicle?.sensorData?.rpm?.toString() ?: "N/A"
                val temp = vehicle?.sensorData?.tempRefrigerante?.toString() ?: "N/A"
                val codigos = vehicle?.errorData?.codigosActivos?.joinToString().orEmpty()

                val context = """
                Vehículo: $marca $modelo
                VIN: $currentVIN
                Sensores: RPM=$rpm, Temp=$temp
                Códigos error: $codigos
            """.trimIndent()

                val prompt = "Contexto: $context\n\nPregunta: $question\n\nResponde de forma específica y técnica."

                val result = aiService.getAIAnalysis(prompt)
                when (result) {
                    is AIService.Result.Success -> {
                        showProgress(false)
                        showAnswerDialog(question, result.data)
                    }
                    is AIService.Result.Error -> {
                        throw result.exception
                    }
                }
            } catch (e: Exception) {
                showProgress(false)
                Toast.makeText(
                    this@IntelligentDiagnosisActivity,
                    "Error: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }


    private fun showAnswerDialog(question: String, answer: String) {
        AlertDialog.Builder(this)
            .setTitle("🤖 Respuesta del Experto")
            .setMessage("**Pregunta:** $question\n\n**Respuesta:** $answer")
            .setPositiveButton("Aceptar", null)
            .show()
    }

    private fun showProgress(show: Boolean) {
        progressBar.isVisible = show
        layoutContent.isVisible = !show
    }

    // Funciones de Firebase
    private suspend fun getVehicleFromFirebase(vin: String): Vehicle? = withContext(Dispatchers.IO) {
        try {
            val vehiclesRef = database.getReference("vehicles")
            val dataSnapshot = vehiclesRef.get().await()

            for (child in dataSnapshot.children) {
                val vehicle = child.getValue(Vehicle::class.java)
                if (vehicle != null && vehicle.vin.equals(vin, ignoreCase = true)) {
                    return@withContext vehicle
                }
            }
            return@withContext null
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun getVpicTechnicalData(vin: String): VpicTechnicalData? = withContext(Dispatchers.IO) {
        try {
            val vpicRef = database.getReference("vpic/vehiculos/$vin")
            val dataSnapshot = vpicRef.get().await()

            if (dataSnapshot.exists()) {
                return@withContext dataSnapshot.getValue(VpicTechnicalData::class.java)
            } else {
                return@withContext null
            }
        } catch (e: Exception) {
            null
        }
    }

    private suspend fun getDtcDescriptions(codes: List<String>): Map<String, String> = withContext(Dispatchers.IO) {
        try {
            val dtcRef = database.getReference("dtc_codes")
            val dataSnapshot = dtcRef.get().await()

            val allCodes = mutableMapOf<String, String>()
            for (child in dataSnapshot.children) {
                val code = child.key ?: ""
                val description = child.child("description").getValue(String::class.java) ?: "Descripción no disponible"
                allCodes[code] = description
            }

            codes.associateWith { code -> allCodes[code] ?: "Descripción no disponible" }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    // Data Classes
    data class Vehicle(
        val id: String = "",
        val ownerId: String = "",
        val nombre: String = "",
        val vin: String = "",
        val assignedMechanics: List<String> = emptyList(),
        val vpicData: VpicData = VpicData(),
        val sensorData: SensorData = SensorData(),
        val errorData: ErrorData = ErrorData(),
        val createdAt: Long = 0L
    )

    data class VpicData(
        val marca: String = "",
        val modelo: String = "",
        val año: Int = 0,
        val color: String = "",
        val motor: String = "",
        val transmision: String = "",
        val combustible: String = "",
        val ultimaActualizacion: Long = 0L
    )

    data class SensorData(
        val rpm: String = "",
        val cargaMotor: String = "",
        val avanceEncendido: String = "",
        val tempRefrigerante: String = "",
        val tempAireAdmision: String = "",
        val tempAireAmbiental: String = "",
        val nivelCombustible: String = "",
        val presionCombustible: String = "",
        val tasaConsumo: String = "",
        val presionMAP: String = "",
        val presionBarometrica: String = "",
        val velocidad: String = "",
        val posicionAcelerador: String = "",
        val ultimaLectura: Long = 0L
    )

    data class ErrorData(
        val codigosActivos: List<String> = emptyList(),
        val codigosPendientes: List<String> = emptyList(),
        val ultimaLectura: Long = 0L
    )

    data class VpicTechnicalData(
        val info_general: InfoGeneral = InfoGeneral(),
        val especificaciones_tecnicas: EspecificacionesTecnicas = EspecificacionesTecnicas(),
        val rangos_operativos: RangosOperativos = RangosOperativos(),
        val consumo_eficiencia: ConsumoEficiencia = ConsumoEficiencia(),
        val dimensiones_peso: DimensionesPeso = DimensionesPeso(),
        val procedencia: Procedencia = Procedencia()
    ) {
        data class InfoGeneral(
            val marca: String = "",
            val modelo: String = "",
            val ano: Int = 0,
            val color: String = "",
            val carroceria: String = "",
            val vin: String = "",
            val fecha_registro: String = ""
        )

        data class EspecificacionesTecnicas(
            val motor: String = "",
            val cilindrada_cc: Int = 0,
            val combustible: String = "",
            val potencia_hp: Int = 0,
            val torque_nm: Int = 0,
            val transmision: String = "",
            val traccion: String = "",
            val compresion: String = "",
            val emisiones: String = ""
        )

        data class RangosOperativos(
            val rpm: Rpm = Rpm(),
            val temperatura_motor: TemperaturaMotor = TemperaturaMotor(),
            val temp_aceite: TempAceite = TempAceite(),
            val presion_aceite: PresionAceite = PresionAceite(),
            val tension_bateria: TensionBateria = TensionBateria()
        ) {
            data class Rpm(val min: Int = 0, val optima: Int = 0, val alerta: Int = 0, val max: Int = 0)
            data class TemperaturaMotor(val min: Int = 0, val optima: Int = 0, val max: Int = 0)
            data class TempAceite(val min: Int = 0, val max: Int = 0)
            data class PresionAceite(val min: Double = 0.0, val max: Double = 0.0)
            data class TensionBateria(val min: Double = 0.0, val max: Double = 0.0)
        }

        data class ConsumoEficiencia(
            val ciudad_lt_100km: Double = 0.0,
            val carretera_lt_100km: Double = 0.0,
            val mixto_lt_100km: Double = 0.0,
            val capacidad_tanque_lt: Double = 0.0
        )

        data class DimensionesPeso(
            val largo_mm: Int = 0,
            val ancho_mm: Int = 0,
            val alto_mm: Int = 0,
            val peso_kg: Int = 0
        )

        data class Procedencia(
            val pais_ensamblaje: String = "",
            val wmi: String = ""
        )
    }
}