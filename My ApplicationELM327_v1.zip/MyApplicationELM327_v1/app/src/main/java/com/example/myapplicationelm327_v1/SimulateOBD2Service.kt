package com.example.myapplicationelm327_v1

import java.util.Random

class SimulatedOBD2Service : IOBD2Service {
    private var isConnected = false
    private var connectionListener: ELM327Connection.ConnectionListener? = null
    private val random = Random()

    // Datos simulados más completos y realistas
    private val simulatedData = mapOf(
        // RPM del Motor
        "010C" to "41 0C 3B 26", // 6904 RPM (0x1A = 26, 0xF8 = 248 -> (26*256 + 248)/4 = 6904)

        // Velocidad del Vehículo
        "010D" to "41 0D 2B", // 43 km/h (0x2B = 43)

        // Temperatura del Refrigerante del Motor
        "0105" to "41 05 57", // 87°C (0x57 = 87 - 40 = 47°C? Corrección: 0x57 = 87)

        // Carga del Motor
        "0104" to "41 04 4D", // 77% (0x4D = 77)

        // Presión del Múltiple de Admisión (MAP)
        "010B" to "41 0B 6F", // 111 kPa (0x6F = 111)

        // Temperatura del Aire de Admisión
        "010F" to "41 0F 32", // 50°C (0x32 = 50 - 40 = 10°C? Corrección: 0x32 = 50)

        // Posición del Acelerador
        "0111" to "41 11 20", // 32% (0x20 = 32)

        // Presión del Combustible
        "010A" to "41 0A 33", // 51 kPa (0x33 = 51 * 3 = 153 kPa)

        // Avance del Encendido
        "010E" to "41 0E 18", // 24° antes del PMS (0x18 = 24/2 = 12°)

        // Nivel de Combustible
        "012F" to "41 2F 64", // 100% (0x64 = 100)

        // Presión Barométrica
        "0133" to "41 33 64", // 100 kPa (0x64 = 100)

        // Temperatura Ambiental del Aire
        "0146" to "41 46 19", // 25°C (0x19 = 25)

        // Tasa de Consumo de Combustible del Motor
        "015E" to "41 5E 07 D0", // 20.00 L/h (0x07D0 = 2000/100 = 20.00)

        // VIN (Número de Identificación del Vehículo)
        "0902" to "49 02 01 33 56 57 46 45 32 31 43 30 34 4D 31 32 33 34 35 36",

        // ID de Calibración
        "0904" to "49 04 01 45 4E 47 49 4E 45 5F 43 41 4C 49 42 5F 56 57 5F 32 2E 30 54 44 49",

        // No usados aún
        // CVN (Número de Verificación de Calibración)
        "0906" to "49 06 01 43 56 4E 5F 56 57 5F 30 30 30 31",

        // PIDs Soportados 01-20
        "0100" to "41 00 BE 1F A8 13",

        // PIDs Soportados 21-40
        "0120" to "41 20 90 15 B0 15",

        // PIDs Soportados 41-60
        "0140" to "41 40 00 03 00 01",

        // CÓDIGOS DE ERROR DTC (Diagnostic Trouble Codes)
        "03" to "43 08 01 01 01 02 04 20 03 00",  // 6 bytes = 3 DTCs: P0101, P0102, P0300
        "07" to "47 04 01 71 04 20",        // 4 bytes = 2 DTCs: P0171, P0420

        // Limpiar códigos DTC
        "04" to "44 00 00 00 00",

        // Distancia con MIL encendida (PID 0x21)
        "0121" to "41 21 00 64", // => 100 km

// Distancia desde borrado de DTC (PID 0x31)
        "0131" to "41 31 03 E8" // => 1000 km
    )

    override fun connect(deviceAddress: String): Boolean {
        Thread {
            // Simular tiempo de conexión
            Thread.sleep(2000)
            isConnected = true
            connectionListener?.onConnectionSuccess()
        }.start()
        return true
    }

    override fun disconnect() {
        isConnected = false
        connectionListener?.onDisconnected()
    }

    override fun readPID(pid: String): String {
        if (!isConnected) {
            return "NO_CONNECTION"
        }

        // Simular pequeño retardo de comunicación
        Thread.sleep(100)

        return simulatedData[pid] ?: generateDynamicResponse(pid)
    }

    private fun generateDynamicResponse(pid: String): String {
        return when (pid) {
            "010C" -> { // RPM - varía entre 800 y 3500
                val rpm = 800 + random.nextInt(2700)
                val value = rpm * 4
                val byteA = (value / 256).toByte().toInt() and 0xFF
                val byteB = (value % 256).toByte().toInt() and 0xFF
                String.format("41 0C %02X %02X", byteA, byteB)
            }
            "010D" -> { // Velocidad - varía entre 0 y 120 km/h
                val speed = random.nextInt(120)
                String.format("41 0D %02X", speed)
            }
            "0105" -> { // Temperatura refrigerante - varía entre 80 y 95
                val temp = 80 + random.nextInt(15)
                String.format("41 05 %02X", temp)
            }
            "0104" -> { // Carga del motor - varía entre 20% y 80%
                val load = 20 + random.nextInt(60)
                String.format("41 04 %02X", load)
            }
            "010B" -> { // Presión múltiple - varía entre 30 y 120 kPa
                val pressure = 30 + random.nextInt(90)
                String.format("41 0B %02X", pressure)
            }
            "010A" -> { // Fuel Pressure - varía entre 200 y 800 kPa
                val pressure = 200 + random.nextInt(600)
                val value = pressure / 3 // Convertir a valor byte
                String.format("41 0A %02X", value.coerceAtMost(255))
            }
            "010E" -> { // Timing Advance - varía entre 5° y 25°
                val advance = (5 + random.nextInt(20)) * 2 // Multiplicar por 2 para el valor real
                String.format("41 0E %02X", advance)
            }
            "0133" -> { // Barometric Pressure - varía entre 95 y 105 kPa
                val pressure = 95 + random.nextInt(10)
                String.format("41 33 %02X", pressure)
            }
            "0146" -> { // Ambient Air Temperature - varía entre 15 y 35°C
                val temp = 15 + random.nextInt(20)
                String.format("41 46 %02X", temp + 40) // Sumar 40 para el offset
            }
            "015E" -> { // Engine Fuel Rate - varía entre 5 y 25 L/h
                val fuelRate = (5 + random.nextInt(20)) * 100 // Multiplicar por 100 para precisión
                val byteA = (fuelRate / 256).toByte().toInt() and 0xFF
                val byteB = (fuelRate % 256).toByte().toInt() and 0xFF
                String.format("41 5E %02X %02X", byteA, byteB)
            }
            else -> "41 ${pid.substring(2)} 00" // Respuesta genérica
        }
    }

    override fun isConnected(): Boolean = isConnected

    override fun setConnectionListener(listener: ELM327Connection.ConnectionListener?) {
        connectionListener = listener
    }
}