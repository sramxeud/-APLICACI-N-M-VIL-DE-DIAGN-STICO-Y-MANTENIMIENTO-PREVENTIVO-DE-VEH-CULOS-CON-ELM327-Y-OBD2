package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class ErrorCodesActivity : AppCompatActivity() {

    private lateinit var btnReadErrors: Button
    private lateinit var btnClearErrors: Button
    private lateinit var btnBack: Button
    private lateinit var tvErrorStatus: TextView
    private lateinit var tvErrorCount: TextView
    private lateinit var tvCurrentVehicle: TextView
    private lateinit var scrollContainer: ScrollView
    private lateinit var mainContainer: LinearLayout

    private var obd2Service: IOBD2Service? = null
    private val firebaseDatabase = FirebaseDatabase.getInstance()
    private val dtcCodesRef = firebaseDatabase.getReference("dtc_codes")
    private val database = Firebase.database
    private var currentVehicle: Vehicle? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_error_codes)
        supportActionBar?.hide()

        initViews()
        initializeService()
        loadCurrentVehicle()
    }

    private fun initViews() {
        btnReadErrors = findViewById(R.id.btnReadErrors)
        btnClearErrors = findViewById(R.id.btnClearErrors)
        btnBack = findViewById(R.id.btnBackErrorCodes)
        tvErrorStatus = findViewById(R.id.tvErrorStatus)
        tvErrorCount = findViewById(R.id.tvErrorCount)
        tvCurrentVehicle = findViewById(R.id.tvCurrentVehicle)
        scrollContainer = findViewById(R.id.scrollContainer)
        mainContainer = findViewById(R.id.mainContainer)

        btnReadErrors.setOnClickListener {
            readErrorCodes()
        }

        btnClearErrors.setOnClickListener {
            clearErrorCodes()
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun initializeService() {
        obd2Service = ELM327Manager.obd2Service
        if (obd2Service == null) {
            tvErrorStatus.text = "❌ Servicio OBD2 no disponible"
            btnReadErrors.isEnabled = false
            btnClearErrors.isEnabled = false
        }
    }

    private fun loadCurrentVehicle() {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty()) {
            showMessage("⚠️ No hay vehículo seleccionado")
            btnReadErrors.isEnabled = false
            btnClearErrors.isEnabled = false
            return
        }

        Log.d("ErrorCodesActivity", "Buscando vehículo con VIN: $currentVIN")

        // Buscar vehículo por VIN en Firebase
        val vehiclesRef = database.getReference("vehicles")
        vehiclesRef.orderByChild("vin").equalTo(currentVIN)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val vehicleSnapshot = snapshot.children.first()
                        currentVehicle = vehicleSnapshot.getValue(Vehicle::class.java)
                        currentVehicle?.let { vehicle ->
                            tvCurrentVehicle.text = "🚗 ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo} - ${vehicle.vin}"

                            // Cargar códigos de error existentes si los hay
                            loadExistingErrorData(vehicle)

                            Log.d("ErrorCodesActivity", "Vehículo cargado: ${vehicle.vin}")
                        }
                    } else {
                        showMessage("❌ Vehículo no encontrado en base de datos")
                        btnReadErrors.isEnabled = false
                        btnClearErrors.isEnabled = false
                        Log.d("ErrorCodesActivity", "No se encontró vehículo con VIN: $currentVIN")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    showMessage("❌ Error cargando vehículo: ${error.message}")
                    btnReadErrors.isEnabled = false
                    btnClearErrors.isEnabled = false
                }
            })
    }

    private fun loadExistingErrorData(vehicle: Vehicle) {
        val errorData = vehicle.errorData
        if (errorData.ultimaLectura > 0) {
            val totalCodes = errorData.codigosActivos.size + errorData.codigosPendientes.size
            if (totalCodes > 0) {
                displayErrorCodes(errorData.codigosActivos, errorData.codigosPendientes)
                updateStatusAndCount(totalCodes)
            }
        }
    }

    private fun readErrorCodes() {
        if (currentVehicle == null) {
            showMessage("❌ No hay vehículo seleccionado")
            return
        }

        Thread {
            try {
                // Leer códigos activos y pendientes
                val activeCodes = readRealErrorCodes("03")  // PID 03 para códigos activos
                val pendingCodes = readRealErrorCodes("07") // PID 07 para códigos pendientes

                runOnUiThread {
                    displayErrorCodes(activeCodes, pendingCodes)
                    val totalCodes = activeCodes.size + pendingCodes.size
                    updateStatusAndCount(totalCodes)
                }

                // Guardar en Firebase
                saveErrorCodesToFirebase(activeCodes, pendingCodes)

            } catch (e: Exception) {
                runOnUiThread {
                    tvErrorStatus.text = "❌ Error leyendo códigos: ${e.message}"
                }
            }
        }.start()
    }

    private fun readRealErrorCodes(pid: String): List<String> {
        val errorCodes = mutableListOf<String>()
        try {
            val response = obd2Service?.readPID(pid)
            if (response != null && response != "NO_DATA" && response != "NO_CONNECTION") {
                val codes = parseDTCResponse(response)
                errorCodes.addAll(codes)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return errorCodes
    }

    private fun parseDTCResponse(response: String): List<String> {
        val dtcList = mutableListOf<String>()

        try {
            val cleanResponse = response.replace(" ", "")
            if (cleanResponse.length < 4) return dtcList

            val responseType = cleanResponse.substring(0, 2)
            if (responseType != "43" && responseType != "47") return dtcList

            // Número de BYTES de datos DTC (no número de DTCs)
            val dataBytesCount = cleanResponse.substring(2, 4).toInt(16)
            // Cada DTC ocupa 2 bytes, así que el número de DTCs es bytes/2
            val expectedDtcCount = dataBytesCount / 2

            var position = 4
            for (i in 0 until expectedDtcCount) {
                if (position + 3 < cleanResponse.length) {
                    val dtcBytes = cleanResponse.substring(position, position + 4)
                    if (dtcBytes != "0000") {
                        val dtcCode = bytesToDTC(dtcBytes)
                        if (dtcCode != "UNKNOWN") {
                            dtcList.add(dtcCode)
                        }
                    }
                    position += 4
                }
            }

        } catch (e: Exception) {
            Log.e("ErrorCodesActivity", "Error parsing DTC response: ${e.message}")
        }

        return dtcList
    }

    private fun bytesToDTC(bytes: String): String {
        if (bytes.length != 4) return "UNKNOWN"

        try {
            val firstByte = bytes.substring(0, 2).toInt(16)
            val secondByte = bytes.substring(2, 4).toInt(16)

            // Determinar el primer carácter del código DTC basado en los primeros 2 bits
            val firstChar = when ((firstByte and 0xC0) shr 6) {
                0 -> "P"  // Powertrain
                1 -> "C"  // Chassis
                2 -> "B"  // Body
                3 -> "U"  // Network
                else -> "P"
            }

            // El primer dígito después de la letra (próximos 2 bits)
            val firstDigit = ((firstByte and 0x30) shr 4).toString()

            // Los últimos 4 bits del primer byte forman el segundo dígito
            val secondDigit = String.format("%X", (firstByte and 0x0F))

            // El segundo byte forma los últimos 2 dígitos
            val lastTwoDigits = String.format("%02X", secondByte)

            return "$firstChar$firstDigit$secondDigit$lastTwoDigits"

        } catch (e: Exception) {
            return "UNKNOWN"
        }
    }

    private fun displayErrorCodes(activeCodes: List<String>, pendingCodes: List<String>) {
        mainContainer.removeAllViews()

        if (activeCodes.isEmpty() && pendingCodes.isEmpty()) {
            val tvMessage = TextView(this).apply {
                text = "✅ No se encontraron códigos de error"
                setTextColor(ContextCompat.getColor(this@ErrorCodesActivity, android.R.color.darker_gray))
                gravity = android.view.Gravity.CENTER
                setPadding(16, 32, 16, 32)
                textSize = 16f
            }
            mainContainer.addView(tvMessage)
            return
        }

        // Agregar códigos activos
        if (activeCodes.isNotEmpty()) {
            addErrorCodeSection("🔴 CÓDIGOS ACTIVOS")
            activeCodes.forEach { code ->
                addErrorCard(code, "Activo")
            }
        }

        // Agregar códigos pendientes
        if (pendingCodes.isNotEmpty()) {
            addErrorCodeSection("🟡 CÓDIGOS PENDIENTES")
            pendingCodes.forEach { code ->
                addErrorCard(code, "Pendiente")
            }
        }
    }

    private fun addErrorCodeSection(title: String) {
        val sectionTitleView = TextView(this).apply {
            text = title
            textSize = 18f
            setTextColor(0xFF424242.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(32, 24, 32, 16)
        }
        mainContainer.addView(sectionTitleView)
    }

    private fun addErrorCard(dtcCode: String, status: String) {
        val card = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 0, 16, 12)
            }
            radius = 12f
            cardElevation = 4f
            setContentPadding(24, 16, 24, 16)
        }

        val cardContent = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Fila superior: Código y Estado
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Código DTC
        val tvCode = TextView(this).apply {
            text = dtcCode
            textSize = 16f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 8, 16, 8)
            gravity = android.view.Gravity.CENTER
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Estado
        val tvStatus = TextView(this).apply {
            text = "Estado: $status"
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(16, 8, 16, 8)
            gravity = android.view.Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
                marginStart = 16
            }
        }

        // Aplicar colores según el estado
        when (status) {
            "Activo" -> {
                tvCode.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
                tvCode.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_red_dark))
            }
            "Pendiente" -> {
                tvCode.setBackgroundColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
                tvCode.setTextColor(ContextCompat.getColor(this, android.R.color.white))
                tvStatus.setTextColor(ContextCompat.getColor(this, android.R.color.holo_orange_dark))
            }
        }

        topRow.addView(tvCode)
        topRow.addView(tvStatus)

        // Descripción (se cargará desde Firebase)
        val tvDescription = TextView(this).apply {
            text = "Cargando información..."
            setPadding(16, 8, 16, 4)
            textSize = 14f
            setTextColor(ContextCompat.getColor(this@ErrorCodesActivity, android.R.color.black))
        }

        // Sistema (se cargará desde Firebase)
        val tvSystem = TextView(this).apply {
            text = "Sistema: Cargando..."
            setPadding(16, 0, 16, 4)
            textSize = 12f
            setTextColor(ContextCompat.getColor(this@ErrorCodesActivity, android.R.color.darker_gray))
        }

        // Severidad (se cargará desde Firebase)
        val tvSeverity = TextView(this).apply {
            text = "Severidad: Cargando..."
            setPadding(16, 0, 16, 8)
            textSize = 12f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }

        cardContent.addView(topRow)
        cardContent.addView(tvDescription)
        cardContent.addView(tvSystem)
        cardContent.addView(tvSeverity)
        card.addView(cardContent)

        mainContainer.addView(card)

        // Buscar información del código DTC en Firebase
        fetchDTCInfoFromFirebase(dtcCode) { dtcInfo ->
            runOnUiThread {
                tvDescription.text = dtcInfo?.description ?: "Información no disponible"
                tvSystem.text = "Sistema: ${dtcInfo?.system ?: "Desconocido"}"
                tvSeverity.text = "Severidad: ${getSeverityText(dtcInfo?.severity ?: 0)}"
                tvSeverity.setTextColor(getSeverityColor(dtcInfo?.severity ?: 0))
            }
        }
    }

    private fun updateStatusAndCount(totalCodes: Int) {
        val status = when {
            totalCodes == 0 -> "✅ No hay códigos de error"
            else -> "⚠️ $totalCodes código(s) de error encontrado(s)"
        }
        tvErrorStatus.text = status
        tvErrorCount.text = "$totalCodes códigos encontrados"
        tvErrorCount.visibility = View.VISIBLE
    }

    private fun saveErrorCodesToFirebase(activeCodes: List<String>, pendingCodes: List<String>) {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty() || currentVehicle == null) {
            Log.d("ErrorCodesActivity", "No hay VIN actual, no se guardarán códigos de error")
            return
        }

        // Buscar vehículo por VIN
        val vehiclesRef = database.getReference("vehicles")
        vehiclesRef.orderByChild("vin").equalTo(currentVIN)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        // Asumimos que solo hay un vehículo con ese VIN
                        val vehicleSnapshot = snapshot.children.first()
                        val vehicleId = vehicleSnapshot.key

                        // Actualizar los datos de error del vehículo
                        val updates = hashMapOf<String, Any>(
                            "errorData/codigosActivos" to activeCodes,
                            "errorData/codigosPendientes" to pendingCodes,
                            "errorData/ultimaLectura" to System.currentTimeMillis()
                        )

                        vehicleId?.let { id ->
                            database.getReference("vehicles").child(id).updateChildren(updates)
                                .addOnSuccessListener {
                                    Log.d("ErrorCodesActivity", "✅ Códigos de error guardados para vehículo $id")
                                    showMessage("✅ Datos guardados correctamente")
                                }
                                .addOnFailureListener { e ->
                                    Log.e("ErrorCodesActivity", "❌ Error guardando códigos: ${e.message}")
                                    showMessage("❌ Error guardando datos")
                                }
                        }
                    } else {
                        Log.d("ErrorCodesActivity", "No se encontró vehículo con VIN: $currentVIN")
                        showMessage("❌ Vehículo no encontrado en base de datos")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("ErrorCodesActivity", "Error buscando vehículo por VIN: ${error.message}")
                    showMessage("❌ Error de conexión con base de datos")
                }
            })
    }

    private fun clearErrorCodes() {
        if (currentVehicle == null) {
            showMessage("❌ No hay vehículo seleccionado")
            return
        }

        Thread {
            try {
                // Enviar comando para limpiar códigos DTC (PID 04)
                obd2Service?.readPID("04")
                Thread.sleep(1000)

                runOnUiThread {
                    mainContainer.removeAllViews()
                    updateStatusAndCount(0)

                    // Mostrar mensaje de no códigos
                    val tvMessage = TextView(this).apply {
                        text = "✅ No hay códigos de error"
                        setTextColor(ContextCompat.getColor(this@ErrorCodesActivity, android.R.color.darker_gray))
                        gravity = android.view.Gravity.CENTER
                        setPadding(16, 32, 16, 32)
                        textSize = 16f
                    }
                    mainContainer.addView(tvMessage)
                }

                // Limpiar los códigos en Firebase
                saveErrorCodesToFirebase(emptyList(), emptyList())

            } catch (e: Exception) {
                runOnUiThread {
                    tvErrorStatus.text = "❌ Error limpiando códigos: ${e.message}"
                }
            }
        }.start()
    }

    private fun fetchDTCInfoFromFirebase(dtcCode: String, onComplete: (DTCInfo?) -> Unit) {
        dtcCodesRef.child(dtcCode).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    val description = snapshot.child("description").getValue(String::class.java) ?: "Descripción no disponible"
                    val system = snapshot.child("system").getValue(String::class.java) ?: "Sistema desconocido"
                    val severity = snapshot.child("severity").getValue(Int::class.java) ?: 0
                    onComplete(DTCInfo(description, system, severity))
                } else {
                    onComplete(null)
                }
            }

            override fun onCancelled(error: DatabaseError) {
                onComplete(null)
            }
        })
    }

    private fun getSeverityColor(severity: Int): Int {
        return when (severity) {
            1 -> ContextCompat.getColor(this, android.R.color.holo_green_dark)
            2 -> ContextCompat.getColor(this, android.R.color.holo_orange_dark)
            3 -> ContextCompat.getColor(this, android.R.color.holo_red_dark)
            else -> ContextCompat.getColor(this, android.R.color.darker_gray)
        }
    }

    private fun getSeverityText(severity: Int): String {
        return when (severity) {
            1 -> "Baja"
            2 -> "Media"
            3 -> "Alta"
            else -> "Desconocida"
        }
    }

    private fun showMessage(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }
}

// Data classes
data class DTCInfo(
    val description: String,
    val system: String,
    val severity: Int
)
