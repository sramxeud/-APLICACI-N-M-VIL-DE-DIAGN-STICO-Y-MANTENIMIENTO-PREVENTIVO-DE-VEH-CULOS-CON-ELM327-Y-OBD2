package com.example.myapplicationelm327_v1

import android.app.Dialog
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Geocoder
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import com.google.android.gms.location.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import java.util.*

class ProfileActivity : AppCompatActivity() {

    private lateinit var tvTitle: TextView
    private lateinit var etName: EditText
    private lateinit var etPhone: EditText
    private lateinit var etAddress: EditText
    private lateinit var etEducation: EditText
    private lateinit var etLatitude: EditText
    private lateinit var etLongitude: EditText
    private lateinit var radioUserType: RadioGroup
    private lateinit var radioOwner: RadioButton
    private lateinit var radioMechanic: RadioButton
    private lateinit var btnSelectLocation: Button
    private lateinit var btnSaveProfile: Button

    private val auth = FirebaseAuth.getInstance()
    private val database = Firebase.database

    // Variables para ubicación
    private var selectedLatitude: Double = 0.0
    private var selectedLongitude: Double = 0.0
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback

    // Variables para modo edición
    private var isEditMode = false
    private var existingUserData: HashMap<String, Any>? = null

    // Código de solicitud de permisos
    private companion object {
        const val LOCATION_PERMISSION_REQUEST_CODE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        supportActionBar?.hide()
        initViews()
        setupClickListeners()
        setupLocationServices()

        // Verificar si estamos en modo edición
        checkEditMode()
    }

    private fun initViews() {
        tvTitle = findViewById(R.id.tvTitle)
        etName = findViewById(R.id.etName)
        etPhone = findViewById(R.id.etPhone)
        etAddress = findViewById(R.id.etAddress)
        etEducation = findViewById(R.id.etEducation)
        etLatitude = findViewById(R.id.etLatitude)
        etLongitude = findViewById(R.id.etLongitude)
        radioUserType = findViewById(R.id.radioUserType)
        radioOwner = findViewById(R.id.radioOwner)
        radioMechanic = findViewById(R.id.radioMechanic)
        btnSelectLocation = findViewById(R.id.btnSelectLocation)
        btnSaveProfile = findViewById(R.id.btnSaveProfile)
    }

    private fun checkEditMode() {
        isEditMode = intent.getBooleanExtra("EDIT_MODE", false)

        if (isEditMode) {
            // Cambiar título y texto del botón
            tvTitle.text = "✏️ Editar tu perfil"
            btnSaveProfile.text = "Actualizar Perfil"

            // Cargar datos existentes del usuario
            loadUserData()
        }
    }

    private fun loadUserData() {
        val firebaseUser = auth.currentUser
        if (firebaseUser != null) {
            val userRef = database.getReference("users").child(firebaseUser.uid)

            userRef.get().addOnSuccessListener { snapshot ->
                if (snapshot.exists()) {
                    existingUserData = snapshot.value as? HashMap<String, Any>
                    populateUserData()
                }
            }.addOnFailureListener {
                Toast.makeText(this, "Error al cargar datos del usuario", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun populateUserData() {
        existingUserData?.let { userData ->
            // Llenar campos básicos
            etName.setText(userData["name"] as? String ?: "")
            etPhone.setText(userData["phone"] as? String ?: "")
            etAddress.setText(userData["address"] as? String ?: "")

            // Llenar educación (convertir List a String)
            val educationList = userData["education"] as? List<*>
            if (educationList != null && educationList.isNotEmpty()) {
                val educationText = educationList.joinToString("\n")
                etEducation.setText(educationText)
            }

            // Llenar tipo de usuario
            when (userData["userType"] as? String) {
                "owner" -> radioOwner.isChecked = true
                "mechanic" -> radioMechanic.isChecked = true
            }

            // Llenar ubicación si existe - BASADO EN TU ESTRUCTURA ACTUAL
            val latitude = userData["latitude"] as? Double
            val longitude = userData["longitude"] as? Double

            if (latitude != null && longitude != null) {
                selectedLatitude = latitude
                selectedLongitude = longitude
                etLatitude.setText(latitude.toString())
                etLongitude.setText(longitude.toString())
                btnSelectLocation.text = "📍 Ubicación seleccionada"
            }

            // Mostrar mensaje informativo
            Toast.makeText(this, "Puedes editar los campos que necesites", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupClickListeners() {
        btnSaveProfile.setOnClickListener {
            saveProfile()
        }

        btnSelectLocation.setOnClickListener {
            showLocationOptionsDialog()
        }
    }

    private fun setupLocationServices() {
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)

        locationRequest = LocationRequest.create().apply {
            interval = 10000
            fastestInterval = 5000
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
        }

        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                locationResult.lastLocation?.let { location ->
                    updateLocationFields(location.latitude, location.longitude)
                    fusedLocationClient.removeLocationUpdates(this)
                }
            }
        }
    }

    private fun showLocationOptionsDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_location_options)
        dialog.setCancelable(true)
        dialog.window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val btnCurrentLocation = dialog.findViewById<Button>(R.id.btnCurrentLocation)
        val btnManualLocation = dialog.findViewById<Button>(R.id.btnManualLocation)
        val btnCancel = dialog.findViewById<Button>(R.id.btnCancel)

        btnCurrentLocation.setOnClickListener {
            dialog.dismiss()
            getCurrentLocation()
        }

        btnManualLocation.setOnClickListener {
            dialog.dismiss()
            showManualLocationDialog()
        }

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun getCurrentLocation() {
        if (checkLocationPermissions()) {
            btnSelectLocation.text = "Obteniendo ubicación..."
            btnSelectLocation.isEnabled = false

            fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper())

            // Timeout por si no obtiene ubicación en 10 segundos
            Handler(Looper.getMainLooper()).postDelayed({
                fusedLocationClient.removeLocationUpdates(locationCallback)
                btnSelectLocation.text = "📍 Seleccionar ubicación"
                btnSelectLocation.isEnabled = true
                Toast.makeText(this, "", Toast.LENGTH_SHORT).show()
            }, 3000)

        } else {
            requestLocationPermissions()
        }
    }

    private fun showManualLocationDialog() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_manual_location)
        dialog.setCancelable(true)
        dialog.window?.setLayout(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )

        val etManualLat = dialog.findViewById<EditText>(R.id.etManualLat)
        val etManualLng = dialog.findViewById<EditText>(R.id.etManualLng)
        val btnConfirmManual = dialog.findViewById<Button>(R.id.btnConfirmManual)
        val btnCancelManual = dialog.findViewById<Button>(R.id.btnCancelManual)

        // Prellenar con valores actuales si existen
        if (selectedLatitude != 0.0) {
            etManualLat.setText(selectedLatitude.toString())
        }
        if (selectedLongitude != 0.0) {
            etManualLng.setText(selectedLongitude.toString())
        }

        btnConfirmManual.setOnClickListener {
            val lat = etManualLat.text.toString().trim()
            val lng = etManualLng.text.toString().trim()

            if (lat.isNotEmpty() && lng.isNotEmpty()) {
                try {
                    val latitude = lat.toDouble()
                    val longitude = lng.toDouble()

                    if (latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180) {
                        updateLocationFields(latitude, longitude)
                        dialog.dismiss()
                        Toast.makeText(this, "📍 Ubicación establecida manualmente", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Coordenadas inválidas", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: NumberFormatException) {
                    Toast.makeText(this, "Formato de coordenadas inválido", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Ingresa ambas coordenadas", Toast.LENGTH_SHORT).show()
            }
        }

        btnCancelManual.setOnClickListener {
            dialog.dismiss()
        }

        dialog.show()
    }

    private fun updateLocationFields(latitude: Double, longitude: Double) {
        selectedLatitude = latitude
        selectedLongitude = longitude

        etLatitude.setText(latitude.toString())
        etLongitude.setText(longitude.toString())

        btnSelectLocation.text = "📍 Ubicación seleccionada"
        btnSelectLocation.isEnabled = true

        // Opcional: Obtener dirección aproximada
        getAddressFromLocation(latitude, longitude)
    }

    private fun getAddressFromLocation(lat: Double, lng: Double) {
        try {
            val geocoder = Geocoder(this, Locale.getDefault())
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            addresses?.let {
                if (it.isNotEmpty()) {
                    val address = it[0].getAddressLine(0)
                    // Puedes mostrar la dirección en un Toast o asignarla al campo de dirección
                    Toast.makeText(this, "Dirección: $address", Toast.LENGTH_LONG).show()

                    // Opcional: Si el campo de dirección está vacío, llenarlo automáticamente
                    if (etAddress.text.toString().isEmpty()) {
                        etAddress.setText(address)
                    }
                }
            }
        } catch (e: Exception) {
            // Geocoder puede fallar, no es crítico
            e.printStackTrace()
        }
    }

    private fun checkLocationPermissions(): Boolean {
        return (ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ActivityCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }

    private fun requestLocationPermissions() {
        ActivityCompat.requestPermissions(
            this,
            arrayOf(
                android.Manifest.permission.ACCESS_FINE_LOCATION,
                android.Manifest.permission.ACCESS_COARSE_LOCATION
            ),
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                getCurrentLocation()
            } else {
                Toast.makeText(this, "Se necesitan permisos de ubicación para esta función", Toast.LENGTH_SHORT).show()
                showManualLocationDialog()
            }
        }
    }

    private fun saveProfile() {
        val name = etName.text.toString().trim()
        val phone = etPhone.text.toString().trim()
        val address = etAddress.text.toString().trim()
        val educationText = etEducation.text.toString().trim()
        val latitudeText = etLatitude.text.toString().trim()
        val longitudeText = etLongitude.text.toString().trim()
        val userType = when {
            radioOwner.isChecked -> "owner"
            radioMechanic.isChecked -> "mechanic"
            else -> ""
        }

        if (validateInputs(name, phone, userType, educationText, address)) {
            val firebaseUser = auth.currentUser
            if (firebaseUser != null) {
                val userRef = database.getReference("users").child(firebaseUser.uid)

                // Procesar educación como array
                val educationArray = if (educationText.isNotEmpty()) {
                    educationText.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                } else {
                    emptyList<String>()
                }

                // Construir datos del usuario - BASADO EN TU ESTRUCTURA ACTUAL
                val userData = if (isEditMode && existingUserData != null) {
                    // En modo edición, mantener datos existentes y actualizar solo los modificados
                    existingUserData!!.apply {
                        put("name", name)
                        put("phone", phone)
                        put("userType", userType)
                        put("address", address)
                        put("education", educationArray)
                        put("updatedAt", System.currentTimeMillis())

                        // Agregar/actualizar ubicación como campos separados (según tu estructura)
                        if (latitudeText.isNotEmpty() && longitudeText.isNotEmpty()) {
                            put("latitude", latitudeText.toDouble())
                            put("longitude", longitudeText.toDouble())
                        } else {
                            // Si no hay ubicación, remover campos existentes
                            remove("latitude")
                            remove("longitude")
                        }
                    }
                } else {
                    // En modo creación, crear nuevo objeto según tu estructura
                    hashMapOf(
                        "name" to name,
                        "phone" to phone,
                        "userType" to userType,
                        "email" to firebaseUser.email,
                        "address" to address,
                        "education" to educationArray,
                        "createdAt" to System.currentTimeMillis(),
                        "rating" to 0.0
                    ).apply {
                        // Agregar ubicación como campos separados
                        if (latitudeText.isNotEmpty() && longitudeText.isNotEmpty()) {
                            put("latitude", latitudeText.toDouble())
                            put("longitude", longitudeText.toDouble())
                        }
                    }
                }

                btnSaveProfile.isEnabled = false
                btnSaveProfile.text = if (isEditMode) "Actualizando..." else "Guardando..."

                userRef.setValue(userData).addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        val successMessage = if (isEditMode) "✅ Perfil actualizado exitosamente" else "✅ Perfil guardado exitosamente"
                        Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show()

                        if (!isEditMode) {
                            // Solo redirigir si es modo creación
                            val intent = if (userType == "mechanic") {
                                Intent(this, MechanicActivity::class.java)
                            } else {
                                Intent(this, OwnerActivity::class.java)
                            }
                            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                            startActivity(intent)
                            finish()
                        } else {
                            // En modo edición, simplemente finalizar la actividad
                            finish()
                        }
                    } else {
                        btnSaveProfile.isEnabled = true
                        btnSaveProfile.text = if (isEditMode) "Actualizar Perfil" else "Guardar Perfil"
                        Toast.makeText(this, "❌ Error: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                Toast.makeText(this, "❌ No hay usuario autenticado", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun validateInputs(name: String, phone: String, userType: String, educationText: String, address: String): Boolean {
        var isValid = true

        if (name.isEmpty()) {
            etName.error = "Ingresa tu nombre"
            isValid = false
        }

        if (phone.isEmpty()) {
            etPhone.error = "Ingresa tu teléfono"
            isValid = false
        }

        if (address.isEmpty()) {
            etAddress.error = "Ingresa tu dirección"
            isValid = false
        }

        if (userType.isEmpty()) {
            Toast.makeText(this, "Selecciona tu tipo de usuario", Toast.LENGTH_SHORT).show()
            isValid = false
        }

        // Validación específica para mecánicos
        if (userType == "mechanic" && educationText.isEmpty()) {
            etEducation.error = "La formación es obligatoria para mecánicos"
            isValid = false
        }

        return isValid
    }

    override fun onBackPressed() {
        if (isEditMode) {
            // En modo edición, simplemente cerrar la actividad
            finish()
        } else {
            // En modo creación, comportamiento normal
            super.onBackPressed()
        }
    }
}