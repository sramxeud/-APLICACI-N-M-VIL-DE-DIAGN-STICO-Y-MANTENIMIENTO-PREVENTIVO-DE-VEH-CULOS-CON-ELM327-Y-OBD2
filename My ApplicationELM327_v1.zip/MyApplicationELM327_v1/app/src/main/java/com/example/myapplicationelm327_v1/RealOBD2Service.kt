package com.example.myapplicationelm327_v1

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothAdapter

class RealOBD2Service(private val device: BluetoothDevice?) : IOBD2Service {
    private var elmConnection: ELM327Connection? = null
    private var connectionListener: ELM327Connection.ConnectionListener? = null

    override fun connect(deviceAddress: String): Boolean {
        return try {
            val btDevice = device ?: BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(deviceAddress)
            if (btDevice != null) {
                elmConnection = ELM327Connection(btDevice)
                elmConnection?.connectionListener = connectionListener
                elmConnection?.connect()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            false
        }
    }

    override fun disconnect() {
        elmConnection?.disconnect()
        elmConnection = null
    }

    override fun readPID(pid: String): String {
        return try {
            elmConnection?.sendCommand(pid, 2000) ?: "NO_CONNECTION"
        } catch (e: Exception) {
            "ERROR: ${e.message}"
        }
    }

    override fun isConnected(): Boolean {
        return elmConnection?.isConnected() ?: false
    }

    override fun setConnectionListener(listener: ELM327Connection.ConnectionListener?) {
        connectionListener = listener
        elmConnection?.connectionListener = listener
    }
}