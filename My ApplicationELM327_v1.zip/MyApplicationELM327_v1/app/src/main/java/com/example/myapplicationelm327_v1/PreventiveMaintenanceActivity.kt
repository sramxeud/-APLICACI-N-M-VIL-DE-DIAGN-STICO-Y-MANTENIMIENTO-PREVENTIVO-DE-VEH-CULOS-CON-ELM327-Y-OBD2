package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.isVisible
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.text.SimpleDateFormat
import java.util.*

class PreventiveMaintenanceActivity : AppCompatActivity() {

    private lateinit var tvVehicleName: TextView
    private lateinit var tvCurrentDistance: TextView
    private lateinit var tvMaintenanceStatus: TextView
    private lateinit var spinnerMaintenanceType: Spinner
    private lateinit var btnSchedule: Button
    private lateinit var btnReadOBD: Button
    private lateinit var btnViewHistory: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var btnBack: Button
    private lateinit var maintenanceListView: ListView
    private lateinit var tvNextMaintenance: TextView

    private val database = FirebaseDatabase.getInstance()
    private val maintenanceRef = database.getReference("preventive_maintenance")
    private val historyRef = database.getReference("maintenance_history")
    private val vehiclesRef = database.getReference("vehicles")
    private val auth = FirebaseAuth.getInstance()

    private var currentDistance = 0
    private var lastMaintenanceDistance = 0
    private var vehicleId: String = ""
    private var ownerId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_preventive_maintenance)

        initViews()
        setupSpinner()
        setupClickListeners()

        vehicleId = intent.getStringExtra("VEHICLE_ID") ?: ""
        val vehicleName = intent.getStringExtra("VEHICLE_NAME") ?: "Vehículo"
        ownerId = auth.currentUser?.uid ?: ""

        tvVehicleName.text = "Vehículo: $vehicleName"

        loadVehicleData()
        loadMaintenanceData()
    }

    private fun initViews() {
        tvVehicleName = findViewById(R.id.tvVehicleName)
        tvCurrentDistance = findViewById(R.id.tvCurrentDistance)
        tvMaintenanceStatus = findViewById(R.id.tvMaintenanceStatus)
        tvNextMaintenance = findViewById(R.id.tvNextMaintenance)
        spinnerMaintenanceType = findViewById(R.id.spinnerMaintenanceType)
        btnSchedule = findViewById(R.id.btnSchedule)
        btnReadOBD = findViewById(R.id.btnReadOBD)
        btnViewHistory = findViewById(R.id.btnViewHistory)
        progressBar = findViewById(R.id.progressBar)
        btnBack = findViewById(R.id.btnBack)
        maintenanceListView = findViewById(R.id.maintenanceListView)
    }

    private fun setupSpinner() {
        val maintenanceTypes = arrayOf(
            "Cambio de Aceite",
            "Rotación de Llantas",
            "Inspección de Frenos",
            "Cambio de Filtros",
            "Servicio Mayor",
            "Cambio de Bujías",
            "Cambio de Líquido de Frenos",
            "Cambio de Refrigerante",
            "Alineación y Balanceo"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, maintenanceTypes)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMaintenanceType.adapter = adapter
    }

    private fun setupClickListeners() {
        btnSchedule.setOnClickListener {
            scheduleMaintenance()
        }

        btnReadOBD.setOnClickListener {
            readOBDData()
        }

        btnViewHistory.setOnClickListener {
            viewMaintenanceHistory()
        }

        btnBack.setOnClickListener {
            finish()
        }
    }

    private fun loadVehicleData() {
        if (vehicleId.isEmpty()) return

        vehiclesRef.child(vehicleId).addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                try {
                    // Obtener datos del vehículo usando Map en lugar de clases
                    val vehicleData = snapshot.value as? Map<String, Any>
                    vehicleData?.let {
                        // Obtener kilometraje actual
                        val maintenanceData = it["maintenanceData"] as? Map<String, Any>
                        currentDistance = (maintenanceData?.get("ultimoKilometraje") as? Long)?.toInt() ?: 0
                        lastMaintenanceDistance = (maintenanceData?.get("lastMaintenanceKm") as? Long)?.toInt() ?: 0

                        tvCurrentDistance.text = "Kilometraje actual: $currentDistance km"
                        updateMaintenanceSchedule()
                    }
                } catch (e: Exception) {
                    Toast.makeText(this@PreventiveMaintenanceActivity, "Error al cargar datos del vehículo", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@PreventiveMaintenanceActivity, "Error al cargar datos del vehículo", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun loadMaintenanceData() {
        if (vehicleId.isEmpty()) return

        // Cargar mantenimientos programados para este vehículo
        maintenanceRef.orderByChild("vehicleId").equalTo(vehicleId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val maintenanceList = mutableListOf<Map<String, Any>>()

                    for (child in snapshot.children) {
                        try {
                            val maintenance = child.value as? Map<String, Any>
                            maintenance?.let {
                                val status = it["status"] as? String ?: ""
                                if (status == "scheduled" || status == "overdue") {
                                    maintenanceList.add(it)
                                }
                            }
                        } catch (e: Exception) {
                            // Ignorar elementos con error
                        }
                    }

                    displayMaintenanceList(maintenanceList)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@PreventiveMaintenanceActivity, "Error al cargar mantenimientos", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun readOBDData() {
        progressBar.isVisible = true
        btnReadOBD.isEnabled = false

        // Simular lectura OBD2
        Thread {
            Thread.sleep(2000) // Simular tiempo de lectura

            runOnUiThread {
                try {
                    // Usar el servicio simulado para obtener datos de distancia
                    val obdService = SimulatedOBD2Service()
                    val distanceResponse = obdService.readPID("0131")

                    // Parsear manualmente la respuesta
                    currentDistance = parseDistanceFromOBD(distanceResponse)

                    // Actualizar en Firebase
                    updateVehicleKilometers(currentDistance)

                    tvCurrentDistance.text = "Kilometraje actual: $currentDistance km"
                    Toast.makeText(this, "✅ Datos OBD2 leídos correctamente", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Error al leer datos OBD2", Toast.LENGTH_SHORT).show()
                } finally {
                    progressBar.isVisible = false
                    btnReadOBD.isEnabled = true
                    updateMaintenanceSchedule()
                }
            }
        }.start()
    }

    private fun parseDistanceFromOBD(response: String): Int {
        return try {
            val cleaned = response.replace(" ", "")
            if (cleaned.length >= 8 && cleaned.startsWith("4131")) {
                val byteA = cleaned.substring(4, 6).toInt(16)
                val byteB = cleaned.substring(6, 8).toInt(16)
                (byteA * 256 + byteB)
            } else {
                // Valor por defecto si no se puede parsear
                currentDistance + 100
            }
        } catch (e: Exception) {
            currentDistance + 100
        }
    }

    private fun updateVehicleKilometers(km: Int) {
        if (vehicleId.isEmpty()) return

        val maintenanceData = mapOf(
            "ultimoKilometraje" to km,
            "updatedAt" to System.currentTimeMillis()
        )

        vehiclesRef.child(vehicleId).child("maintenanceData").updateChildren(maintenanceData)
    }

    private fun updateMaintenanceSchedule() {
        // Calcular próximos mantenimientos basados en el kilometraje actual
        val nextMaintenance = calculateNextMaintenance()

        if (nextMaintenance != null) {
            val kmRemaining = nextMaintenance["scheduledKm"] as Int - currentDistance
            tvNextMaintenance.text = "Próximo: ${nextMaintenance["type"]} en ${nextMaintenance["scheduledKm"]} km"

            if (kmRemaining <= 500) {
                tvMaintenanceStatus.text = "🔔 ${nextMaintenance["type"]} en $kmRemaining km"
                tvMaintenanceStatus.setTextColor(resources.getColor(android.R.color.holo_orange_dark, theme))
            } else if (kmRemaining <= 0) {
                tvMaintenanceStatus.text = "⚠️ ${nextMaintenance["type"]} VENCIDO por ${-kmRemaining} km"
                tvMaintenanceStatus.setTextColor(resources.getColor(android.R.color.holo_red_dark, theme))
            } else {
                tvMaintenanceStatus.text = "✅ Mantenimientos al día"
                tvMaintenanceStatus.setTextColor(resources.getColor(android.R.color.holo_green_dark, theme))
            }
        } else {
            tvNextMaintenance.text = "No hay mantenimientos programados"
            tvMaintenanceStatus.text = "Estado: Sin mantenimientos"
        }

        loadMaintenanceData()
    }

    private fun calculateNextMaintenance(): Map<String, Any>? {
        val maintenanceTypes = listOf(
            mapOf("name" to "Cambio de Aceite", "interval" to 5000),
            mapOf("name" to "Rotación de Llantas", "interval" to 10000),
            mapOf("name" to "Inspección de Frenos", "interval" to 15000),
            mapOf("name" to "Cambio de Filtros", "interval" to 20000)
        )

        var nextMaintenance: Map<String, Any>? = null

        for (type in maintenanceTypes) {
            val typeName = type["name"] as String
            val interval = type["interval"] as Int
            val nextKm = lastMaintenanceDistance + interval

            if (nextKm > currentDistance) {
                if (nextMaintenance == null || nextKm < (nextMaintenance["scheduledKm"] as Int)) {
                    nextMaintenance = mapOf(
                        "type" to typeName,
                        "scheduledKm" to nextKm,
                        "status" to "scheduled"
                    )
                }
            }
        }

        return nextMaintenance
    }

    private fun displayMaintenanceList(maintenanceList: List<Map<String, Any>>) {
        if (maintenanceList.isEmpty()) {
            maintenanceListView.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, arrayOf("No hay mantenimientos programados"))
            return
        }

        val displayList = maintenanceList.map { maintenance ->
            val type = maintenance["type"] as? String ?: "Mantenimiento"
            val scheduledKm = maintenance["scheduledKm"] as? Int ?: 0
            val status = maintenance["status"] as? String ?: "scheduled"

            "$type\nProgramado: $scheduledKm km | Estado: ${if (status == "overdue") "⚠️ VENCIDO" else "⏳ PROGRAMADO"}"
        }

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, displayList)
        maintenanceListView.adapter = adapter

        // Agregar click listener para completar mantenimientos
        maintenanceListView.setOnItemClickListener { _, _, position, _ ->
            val selectedMaintenance = maintenanceList[position]
            showCompleteMaintenanceDialog(selectedMaintenance)
        }
    }

    private fun showCompleteMaintenanceDialog(maintenance: Map<String, Any>) {
        val type = maintenance["type"] as? String ?: "Mantenimiento"

        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Completar Mantenimiento")
            .setMessage("¿Has completado el $type?")
            .setPositiveButton("Sí, Completar") { _, _ ->
                completeMaintenance(maintenance)
            }
            .setNegativeButton("Cancelar", null)
            .create()

        dialog.show()
    }

    private fun completeMaintenance(maintenance: Map<String, Any>) {
        val maintenanceId = maintenance["id"] as? String ?: return
        val type = maintenance["type"] as? String ?: "Mantenimiento"

        // Mover a historial
        val historyId = historyRef.push().key ?: return

        val historyItem = mapOf(
            "id" to historyId,
            "vehicleId" to vehicleId,
            "ownerId" to ownerId,
            "type" to type,
            "completedKm" to currentDistance,
            "completedDate" to System.currentTimeMillis(),
            "cost" to 0.0,
            "mechanic" to "Usuario",
            "notes" to "Mantenimiento completado desde la app"
        )

        historyRef.child(historyId).setValue(historyItem)
            .addOnSuccessListener {
                // Actualizar último kilometraje de mantenimiento
                lastMaintenanceDistance = currentDistance
                updateLastMaintenanceKm()

                // Eliminar de mantenimientos programados
                maintenanceRef.child(maintenanceId).removeValue()
                    .addOnSuccessListener {
                        updateMaintenanceSchedule()
                        Toast.makeText(this@PreventiveMaintenanceActivity, "✅ Mantenimiento completado", Toast.LENGTH_SHORT).show()
                    }
                    .addOnFailureListener {
                        Toast.makeText(this@PreventiveMaintenanceActivity, "Error al eliminar mantenimiento", Toast.LENGTH_SHORT).show()
                    }
            }
            .addOnFailureListener {
                Toast.makeText(this, "Error al guardar en historial", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateLastMaintenanceKm() {
        if (vehicleId.isEmpty()) return

        val updates = mapOf(
            "lastMaintenanceKm" to currentDistance,
            "lastMaintenanceDate" to System.currentTimeMillis()
        )

        vehiclesRef.child(vehicleId).child("maintenanceData").updateChildren(updates)
    }

    private fun scheduleMaintenance() {
        if (vehicleId.isEmpty()) return

        val maintenanceType = spinnerMaintenanceType.selectedItem.toString()

        if (maintenanceType.isEmpty()) {
            Toast.makeText(this, "Selecciona un tipo de mantenimiento", Toast.LENGTH_SHORT).show()
            return
        }

        if (currentDistance == 0) {
            Toast.makeText(this, "Primero lee los datos OBD2 del vehículo", Toast.LENGTH_SHORT).show()
            return
        }

        progressBar.isVisible = true
        btnSchedule.isEnabled = false

        val maintenanceId = maintenanceRef.push().key ?: return

        // Calcular kilometraje programado basado en el tipo
        val scheduledKm = calculateScheduledKm(maintenanceType)

        val maintenance = mapOf(
            "id" to maintenanceId,
            "vehicleId" to vehicleId,
            "ownerId" to ownerId,
            "type" to maintenanceType,
            "status" to "scheduled",
            "scheduledKm" to scheduledKm,
            "actualKm" to 0,
            "scheduledDate" to System.currentTimeMillis(),
            "completedDate" to 0,
            "createdAt" to System.currentTimeMillis(),
            "updatedAt" to System.currentTimeMillis(),
            "cost" to 0.0,
            "mechanic" to "",
            "notes" to "Mantenimiento programado desde la app"
        )

        maintenanceRef.child(maintenanceId).setValue(maintenance)
            .addOnSuccessListener {
                progressBar.isVisible = false
                btnSchedule.isEnabled = true
                Toast.makeText(this, "✅ Mantenimiento programado para $scheduledKm km", Toast.LENGTH_SHORT).show()
                loadMaintenanceData()
                updateMaintenanceSchedule()
            }
            .addOnFailureListener {
                progressBar.isVisible = false
                btnSchedule.isEnabled = true
                Toast.makeText(this, "❌ Error al programar mantenimiento", Toast.LENGTH_SHORT).show()
            }
    }

    private fun calculateScheduledKm(maintenanceType: String): Int {
        val interval = when (maintenanceType) {
            "Cambio de Aceite" -> 5000
            "Rotación de Llantas" -> 10000
            "Inspección de Frenos" -> 15000
            "Cambio de Filtros" -> 20000
            "Servicio Mayor" -> 30000
            "Cambio de Bujías" -> 60000
            "Cambio de Líquido de Frenos" -> 60000
            "Cambio de Refrigerante" -> 40000
            "Alineación y Balanceo" -> 15000
            else -> 5000
        }

        return currentDistance + interval
    }

    private fun viewMaintenanceHistory() {
        historyRef.orderByChild("vehicleId").equalTo(vehicleId)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val historyList = mutableListOf<String>()

                    for (child in snapshot.children) {
                        try {
                            val history = child.value as? Map<String, Any>
                            history?.let {
                                val type = it["type"] as? String ?: "Mantenimiento"
                                val completedKm = it["completedKm"] as? Int ?: 0
                                val completedDate = it["completedDate"] as? Long ?: 0

                                val date = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(completedDate))
                                historyList.add("$type - $completedKm km - $date")
                            }
                        } catch (e: Exception) {
                            // Ignorar elementos con error
                        }
                    }

                    if (historyList.isEmpty()) {
                        historyList.add("No hay historial de mantenimientos")
                    }

                    showHistoryDialog(historyList)
                }

                override fun onCancelled(error: DatabaseError) {
                    Toast.makeText(this@PreventiveMaintenanceActivity, "Error al cargar historial", Toast.LENGTH_SHORT).show()
                }
            })
    }

    private fun showHistoryDialog(historyList: List<String>) {
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle("Historial de Mantenimientos")
            .setItems(historyList.toTypedArray(), null)
            .setPositiveButton("Cerrar", null)
            .create()

        dialog.show()
    }
}