package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase
import android.widget.Toast


class SensorsActivity : AppCompatActivity() {

    private lateinit var btnReadSensors: Button
    private lateinit var btnBackToMain: Button
    private lateinit var scrollContainer: ScrollView
    private lateinit var mainContainer: LinearLayout
    private lateinit var tvCurrentVehicle: TextView

    private var obd2Service: IOBD2Service? = null
    private val database = Firebase.database
    private var currentVehicle: Vehicle? = null

    // Todos los sensores organizados por categorías
    private val sensorCategories = listOf(
        SensorCategory("🚗 MOTOR", listOf(
            Sensor("RPM", "010C", ::parseRPM),
            Sensor("Carga del Motor", "0104", ::parseEngineLoad),
            Sensor("Avance del Encendido", "010E", ::parseTimingAdvance)
        )),

        SensorCategory("🌡️ TEMPERATURAS", listOf(
            Sensor("Temp. Refrigerante", "0105", ::parseCoolantTemp),
            Sensor("Temp. Aire Admisión", "010F", ::parseIntakeTemp),
            Sensor("Temp. Aire Ambiental", "0146", ::parseAmbientAirTemp)
        )),

        SensorCategory("⛽ COMBUSTIBLE", listOf(
            Sensor("Nivel Combustible", "012F", ::parseFuelLevel),
            Sensor("Presión Combustible", "010A", ::parseFuelPressure),
            Sensor("Tasa Consumo", "015E", ::parseEngineFuelRate)
        )),

        SensorCategory("📊 PRESIONES", listOf(
            Sensor("Presión MAP", "010B", ::parseMAPPressure),
            Sensor("Presión Barométrica", "0133", ::parseBarometricPressure)
        )),

        SensorCategory("🚀 VEHÍCULO", listOf(
            Sensor("Velocidad", "010D", ::parseVehicleSpeed),
            Sensor("Posición Acelerador", "0111", ::parseThrottlePosition)
        ))
    )

    // Mapa para almacenar las referencias a los TextView de valores
    private val valueViews = mutableMapOf<String, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sensors)
        supportActionBar?.hide()

        initViews()
        initializeService()
        loadCurrentVehicle()
    }

    private fun initViews() {
        btnReadSensors = findViewById(R.id.btnReadSensors)
        btnBackToMain = findViewById(R.id.btnBackToMain)
        scrollContainer = findViewById(R.id.scrollContainer)
        mainContainer = findViewById(R.id.mainContainer)
        tvCurrentVehicle = findViewById(R.id.tvCurrentVehicle)

        btnReadSensors.setOnClickListener {
            readAllSensorsOnce()
        }

        btnBackToMain.setOnClickListener {
            finish()
        }
    }

    private fun initializeService() {
        obd2Service = ELM327Manager.obd2Service
        if (obd2Service == null) {
            showMessage("❌ Servicio OBD2 no disponible")
            btnReadSensors.isEnabled = false
        }
    }

    private fun loadCurrentVehicle() {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty()) {
            showMessage("⚠️ No hay vehículo seleccionado")
            btnReadSensors.isEnabled = false
            return
        }

        Log.d("SensorsActivity", "Buscando vehículo con VIN: $currentVIN")

        // Buscar vehículo por VIN en Firebase
        val vehiclesRef = database.getReference("vehicles")
        vehiclesRef.orderByChild("vin").equalTo(currentVIN)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val vehicleSnapshot = snapshot.children.first()
                        currentVehicle = vehicleSnapshot.getValue(Vehicle::class.java)
                        currentVehicle?.let { vehicle ->
                            tvCurrentVehicle.text = "🚗 ${vehicle.vpicData.marca} ${vehicle.vpicData.modelo} - ${vehicle.vin}"
                            setupSensorsLayout()

                            // Cargar datos existentes si los hay
                            loadExistingSensorData(vehicle)

                            Log.d("SensorsActivity", "Vehículo cargado: ${vehicle.vin}")
                        }
                    } else {
                        showMessage("❌ Vehículo no encontrado en base de datos")
                        btnReadSensors.isEnabled = false
                        Log.d("SensorsActivity", "No se encontró vehículo con VIN: $currentVIN")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    showMessage("❌ Error cargando vehículo: ${error.message}")
                    btnReadSensors.isEnabled = false
                }
            })
    }

    private fun loadExistingSensorData(vehicle: Vehicle) {
        val sensorData = vehicle.sensorData
        if (sensorData.ultimaLectura > 0) {
            // Actualizar la interfaz con datos existentes
            updateSensorValue("RPM", sensorData.rpm.ifEmpty { "--" })
            updateSensorValue("Carga del Motor", sensorData.cargaMotor.ifEmpty { "--" })
            updateSensorValue("Avance del Encendido", sensorData.avanceEncendido.ifEmpty { "--" })
            updateSensorValue("Temp. Refrigerante", sensorData.tempRefrigerante.ifEmpty { "--" })
            updateSensorValue("Temp. Aire Admisión", sensorData.tempAireAdmision.ifEmpty { "--" })
            updateSensorValue("Temp. Aire Ambiental", sensorData.tempAireAmbiental.ifEmpty { "--" })
            updateSensorValue("Nivel Combustible", sensorData.nivelCombustible.ifEmpty { "--" })
            updateSensorValue("Presión Combustible", sensorData.presionCombustible.ifEmpty { "--" })
            updateSensorValue("Tasa Consumo", sensorData.tasaConsumo.ifEmpty { "--" })
            updateSensorValue("Presión MAP", sensorData.presionMAP.ifEmpty { "--" })
            updateSensorValue("Presión Barométrica", sensorData.presionBarometrica.ifEmpty { "--" })
            updateSensorValue("Velocidad", sensorData.velocidad.ifEmpty { "--" })
            updateSensorValue("Posición Acelerador", sensorData.posicionAcelerador.ifEmpty { "--" })
        }
    }

    private fun setupSensorsLayout() {
        mainContainer.removeAllViews()
        valueViews.clear()

        // Título principal
        addSectionTitle("📊 LECTURA DE SENSORES EN TIEMPO REAL")

        sensorCategories.forEach { category ->
            // Agregar sección
            addCardSection(category.name)

            // Agregar sensores de esta categoría
            category.sensors.forEach { sensor ->
                addSensorCard(sensor.nombre, sensor.pid)
            }

            // Espacio entre categorías
            addEmptySpace(16)
        }
    }

    private fun addSectionTitle(title: String) {
        val titleView = TextView(this).apply {
            text = title
            textSize = 20f
            setTextColor(0xFF1976D2.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(32, 24, 32, 16)
        }
        mainContainer.addView(titleView)
    }

    private fun addCardSection(sectionTitle: String) {
        val sectionTitleView = TextView(this).apply {
            text = sectionTitle
            textSize = 18f
            setTextColor(0xFF424242.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(32, 24, 32, 16)
        }
        mainContainer.addView(sectionTitleView)
    }

    private fun addSensorCard(sensorName: String, pid: String) {
        val card = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 0, 16, 8)
            }
            radius = 12f
            cardElevation = 4f
            setContentPadding(24, 16, 24, 16)
        }

        val cardContent = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        val labelView = TextView(this).apply {
            text = sensorName
            textSize = 14f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setTextColor(0xFF212121.toInt())
            layoutParams = LinearLayout.LayoutParams(
                0,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                weight = 1f
            }
        }

        val valueView = TextView(this).apply {
            text = "--"
            textSize = 14f
            setTextColor(0xFF757575.toInt())
            gravity = android.view.Gravity.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )
        }

        // Guardar referencia para actualizaciones posteriores
        valueViews[sensorName] = valueView

        cardContent.addView(labelView)
        cardContent.addView(valueView)
        card.addView(cardContent)
        mainContainer.addView(card)
    }

    private fun addEmptySpace(heightDp: Int) {
        val space = LinearLayout(this)
        val params = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            (heightDp * resources.displayMetrics.density).toInt()
        )
        space.layoutParams = params
        mainContainer.addView(space)
    }

    private fun readAllSensorsOnce() {
        if (currentVehicle == null) {
            showMessage("❌ No hay vehículo seleccionado")
            return
        }

        btnReadSensors.isEnabled = false
        btnReadSensors.text = "Leyendo..."

        Thread {
            val sensorValues = mutableMapOf<String, String>()

            sensorCategories.forEach { category ->
                category.sensors.forEach { sensor ->
                    try {
                        val response = obd2Service?.readPID(sensor.pid)
                        val valor = sensor.parseFunction(response)
                        sensorValues[sensor.nombre] = valor

                        runOnUiThread {
                            updateSensorValue(sensor.nombre, valor)
                        }

                        Thread.sleep(100) // Pequeña pausa entre lecturas
                    } catch (e: Exception) {
                        Log.e("SensorsActivity", "Error leyendo sensor ${sensor.nombre}: ${e.message}")
                        runOnUiThread {
                            updateSensorValue(sensor.nombre, "Error")
                        }
                    }
                }
            }

            runOnUiThread {
                btnReadSensors.isEnabled = true
                btnReadSensors.text = "Leer Sensores"
            }

            // Guardar en Firebase después de leer todos los sensores
            saveSensorDataToFirebase(sensorValues)

        }.start()
    }

    private fun updateSensorValue(sensorName: String, value: String) {
        valueViews[sensorName]?.text = value
    }

    private fun saveSensorDataToFirebase(sensorValues: Map<String, String>) {
        val currentVIN = ELM327Manager.currentVIN
        if (currentVIN.isNullOrEmpty() || currentVehicle == null) {
            Log.d("SensorsActivity", "No hay VIN o vehículo actual, no se guardarán datos")
            return
        }

        // Buscar vehículo por VIN para obtener el ID correcto
        val vehiclesRef = database.getReference("vehicles")
        vehiclesRef.orderByChild("vin").equalTo(currentVIN)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    if (snapshot.exists()) {
                        val vehicleSnapshot = snapshot.children.first()
                        val vehicleId = vehicleSnapshot.key

                        // Crear objeto SensorData con los nuevos valores
                        val sensorData = SensorData(
                            rpm = sensorValues["RPM"] ?: "",
                            cargaMotor = sensorValues["Carga del Motor"] ?: "",
                            avanceEncendido = sensorValues["Avance del Encendido"] ?: "",
                            tempRefrigerante = sensorValues["Temp. Refrigerante"] ?: "",
                            tempAireAdmision = sensorValues["Temp. Aire Admisión"] ?: "",
                            tempAireAmbiental = sensorValues["Temp. Aire Ambiental"] ?: "",
                            nivelCombustible = sensorValues["Nivel Combustible"] ?: "",
                            presionCombustible = sensorValues["Presión Combustible"] ?: "",
                            tasaConsumo = sensorValues["Tasa Consumo"] ?: "",
                            presionMAP = sensorValues["Presión MAP"] ?: "",
                            presionBarometrica = sensorValues["Presión Barométrica"] ?: "",
                            velocidad = sensorValues["Velocidad"] ?: "",
                            posicionAcelerador = sensorValues["Posición Acelerador"] ?: "",
                            ultimaLectura = System.currentTimeMillis()
                        )

                        // Actualizar los datos de sensores del vehículo
                        vehicleId?.let { id ->
                            database.getReference("vehicles").child(id).child("sensorData")
                                .setValue(sensorData)
                                .addOnSuccessListener {
                                    Log.d("SensorsActivity", "✅ Datos de sensores guardados para vehículo $id")
                                    showMessage("✅ Datos guardados correctamente")
                                }
                                .addOnFailureListener { e ->
                                    Log.e("SensorsActivity", "❌ Error guardando sensores: ${e.message}")
                                    showMessage("❌ Error guardando datos")
                                }
                        }
                    } else {
                        Log.d("SensorsActivity", "No se encontró vehículo con VIN: $currentVIN")
                        showMessage("❌ Vehículo no encontrado en base de datos")
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("SensorsActivity", "Error buscando vehículo por VIN: ${error.message}")
                    showMessage("❌ Error de conexión con base de datos")
                }
            })
    }

    private fun showMessage(message: String) {
        runOnUiThread {
            Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
        }
    }

    // ==================== FUNCIONES DE PARSEO (MANTENIDAS) ====================
    private fun parseRPM(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 4 && parts[0] == "41" && parts[1] == "0C") {
                val a = parts[2].toInt(16)
                val b = parts[3].toInt(16)
                "${((a * 256) + b) / 4}"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseEngineLoad(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "04") {
                "${parts[2].toInt(16)}%"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseCoolantTemp(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "05") {
                "${parts[2].toInt(16) - 40}°C"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseIntakeTemp(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0F") {
                "${parts[2].toInt(16) - 40}°C"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseMAPPressure(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0B") {
                "${parts[2].toInt(16)} kPa"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseThrottlePosition(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "11") {
                "${parts[2].toInt(16)}%"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseFuelPressure(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0A") {
                "${parts[2].toInt(16) * 3} kPa"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseTimingAdvance(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0E") {
                "${parts[2].toInt(16) / 2}°"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseFuelLevel(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "2F") {
                "${parts[2].toInt(16)}%"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseBarometricPressure(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "33") {
                "${parts[2].toInt(16)} kPa"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseAmbientAirTemp(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "46") {
                "${parts[2].toInt(16)}°C"
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseEngineFuelRate(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 4 && parts[0] == "41" && parts[1] == "5E") {
                val a = parts[2].toInt(16)
                val b = parts[3].toInt(16)
                val fuelRate = ((a * 256) + b) / 100.0
                "%.2f L/h".format(fuelRate)
            } else "--"
        } catch (e: Exception) { "--" }
    }

    private fun parseVehicleSpeed(response: String?): String {
        if (response == null || response.contains("ERROR")) return "--"
        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }
            if (parts.size >= 3 && parts[0] == "41" && parts[1] == "0D") {
                "${parts[2].toInt(16)} km/h"
            } else "--"
        } catch (e: Exception) { "--" }
    }
}

// Clases de datos (actualizadas según tu estructura)
data class Sensor(
    val nombre: String,
    val pid: String,
    val parseFunction: (String?) -> String
)

data class SensorCategory(
    val name: String,
    val sensors: List<Sensor>
)

data class Vehicle(
    val id: String = "",
    val ownerId: String = "",
    val nombre: String = "",
    val vin: String = "",
    val assignedMechanics: List<String> = emptyList(),
    val vpicData: VpicData = VpicData(),
    val sensorData: SensorData = SensorData(),
    val errorData: ErrorData = ErrorData(),
    val createdAt: Long = 0L
)

data class VpicData(
    val marca: String = "",
    val modelo: String = "",
    val año: Int = 0,
    val color: String = "",
    val motor: String = "",
    val transmision: String = "",
    val combustible: String = "",
    val ultimaActualizacion: Long = 0L
)

data class SensorData(
    val rpm: String = "",
    val cargaMotor: String = "",
    val avanceEncendido: String = "",
    val tempRefrigerante: String = "",
    val tempAireAdmision: String = "",
    val tempAireAmbiental: String = "",
    val nivelCombustible: String = "",
    val presionCombustible: String = "",
    val tasaConsumo: String = "",
    val presionMAP: String = "",
    val presionBarometrica: String = "",
    val velocidad: String = "",
    val posicionAcelerador: String = "",
    val ultimaLectura: Long = 0L
)

data class ErrorData(
    val codigosActivos: List<String> = emptyList(),
    val codigosPendientes: List<String> = emptyList(),
    val ultimaLectura: Long = 0L
)