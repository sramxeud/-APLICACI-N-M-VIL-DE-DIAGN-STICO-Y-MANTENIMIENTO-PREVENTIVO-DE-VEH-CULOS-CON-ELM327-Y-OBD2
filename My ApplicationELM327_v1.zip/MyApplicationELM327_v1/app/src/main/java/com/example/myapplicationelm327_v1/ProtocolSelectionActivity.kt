package com.example.myapplicationelm327_v1

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.IOException

private lateinit var obd2Service: IOBD2Service
class ProtocolSelectionActivity : AppCompatActivity() {

    private lateinit var spinnerProtocol: Spinner
    private lateinit var btnConnect: Button
    private lateinit var progressBar: ProgressBar

    private var device: BluetoothDevice? = null
    private var deviceName: String? = null
    private var deviceAddress: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_protocol_selection)

        // Obtener datos del dispositivo desde BluetoothActivity
        deviceAddress = intent.getStringExtra("DEVICE_ADDRESS")
        deviceName = intent.getStringExtra("DEVICE_NAME")
        device = BluetoothAdapter.getDefaultAdapter()?.getRemoteDevice(deviceAddress)
        supportActionBar?.hide()

        initViews()
        setupSpinner()
        setupButton()
    }

    private fun initViews() {
        spinnerProtocol = findViewById(R.id.spinnerProtocol)
        btnConnect = findViewById(R.id.btnConnect)
        progressBar = findViewById(R.id.progressBar)
    }

    private fun setupSpinner() {
        val protocols = ELM327Connection.Protocol.values().map { it.name }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, protocols)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerProtocol.adapter = adapter
        spinnerProtocol.setSelection(0) // Auto por defecto
    }

    private fun setupButton() {
        btnConnect.setOnClickListener {
            if (device == null) {
                Toast.makeText(this, "Dispositivo no válido", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val selectedPosition = spinnerProtocol.selectedItemPosition
            val selectedProtocol = ELM327Connection.Protocol.values()[selectedPosition]
            connectToDevice(selectedProtocol)
        }
    }

    private fun connectToDevice(protocol: ELM327Connection.Protocol) {
        showLoading(true)

        Thread {
            try {
                // Inicializar el servicio
                ELM327Manager.initializeService(device)
                val obd2Service = ELM327Manager.obd2Service ?: throw Exception("Servicio no disponible")

                // Configurar listener
                val connectionListener = object : ELM327Connection.ConnectionListener {
                    override fun onConnectionSuccess() {
                        runOnUiThread {
                            showLoading(false)
                            //AQUI CAMBIAR DEST
                            val intent = Intent(this@ProtocolSelectionActivity, MainActivity::class.java).apply {
                                putExtra("DEVICE_ADDRESS", deviceAddress)
                                putExtra("DEVICE_NAME", deviceName)
                                putExtra("PROTOCOL", protocol.displayName)
                                putExtra("IS_CONNECTED", true)
                                putExtra("IS_SIMULATION", OBD2ServiceFactory.isSimulationMode())
                            }
                            startActivity(intent)
                            finish()
                        }
                    }

                    override fun onConnectionError(error: String) {
                        runOnUiThread {
                            showLoading(false)
                            Toast.makeText(this@ProtocolSelectionActivity, "Error: $error", Toast.LENGTH_LONG).show()
                        }
                    }

                    override fun onDataReceived(data: String) {}
                    override fun onDisconnected() {}
                }

                obd2Service.setConnectionListener(connectionListener)

                // Guardar en el manager
                ELM327Manager.currentDevice = device
                ELM327Manager.currentProtocol = protocol
                ELM327Manager.isConnected = true

                // Conectar
                val success = obd2Service.connect(deviceAddress!!)

                if (!success) {
                    throw Exception("No se pudo iniciar la conexión")
                }

            } catch (e: Exception) {
                ELM327Manager.disconnect()
                runOnUiThread {
                    showLoading(false)
                    Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun showLoading(show: Boolean) {
        runOnUiThread {
            progressBar.visibility = if (show) View.VISIBLE else View.GONE
            btnConnect.isEnabled = !show
            spinnerProtocol.isEnabled = !show
        }
    }
}