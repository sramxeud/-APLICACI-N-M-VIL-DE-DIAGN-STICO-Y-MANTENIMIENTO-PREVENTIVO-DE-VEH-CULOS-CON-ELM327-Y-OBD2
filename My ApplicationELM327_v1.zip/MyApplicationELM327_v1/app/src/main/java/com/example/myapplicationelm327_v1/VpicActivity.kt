package com.example.myapplicationelm327_v1

import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.google.firebase.database.ktx.database
import com.google.firebase.ktx.Firebase

class VpicActivity : AppCompatActivity() {

    private lateinit var tvVin: TextView
    private lateinit var btnBack: Button
    private lateinit var btnReadVin: Button
    private lateinit var progressBar: ProgressBar
    private lateinit var scrollContainer: ScrollView
    private lateinit var mainContainer: LinearLayout

    private val database = Firebase.database
    private var obd2Service: IOBD2Service? = null

    // Mapa para almacenar las referencias a los TextView de valores
    private val valueViews = mutableMapOf<String, TextView>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_vpic)
        supportActionBar?.hide()

        initViews()
        initializeService()
        // MOSTRAR ESTRUCTURA COMPLETA CON VALORES VACÍOS
        showEmptyVehicleLayout()

        // Cargar datos del vehículo actual si existe
        loadCurrentVehicleData()
    }

    private fun initViews() {
        tvVin = findViewById(R.id.tvVin)
        btnBack = findViewById(R.id.btnBackVpic)
        btnReadVin = findViewById(R.id.btnReadVin)
        progressBar = findViewById(R.id.progressBar)
        scrollContainer = findViewById(R.id.scrollContainer)
        mainContainer = findViewById(R.id.mainContainer)

        btnBack.setOnClickListener {
            finish()
        }

        btnReadVin.setOnClickListener {
            readVinFromOBD2()
        }
    }

    private fun initializeService() {
        obd2Service = ELM327Manager.obd2Service
        if (obd2Service == null) {
            updateCardValue("estado_servicio", "❌ No disponible")
            updateCardValue("instrucciones", "Conecta al ELM327 desde el menú principal")
        } else {
            updateCardValue("estado_servicio", "✅ Disponible")
            updateCardValue("instrucciones", "Presiona 'Leer VIN del Vehículo'")
        }
    }

    // NUEVO MÉTODO: Cargar datos del vehículo actual
    private fun loadCurrentVehicleData() {
        val currentVIN = ELM327Manager.currentVIN
        if (!currentVIN.isNullOrEmpty()) {
            updateCardValue("vin_detectado", "✅ $currentVIN")
            updateCardValue("vin", currentVIN)
            tvVin.text = "✅ VIN: $currentVIN"

            Log.d("VpicActivity", "VIN actual: $currentVIN")

            // Buscar y cargar datos existentes del vehículo desde VPIC
            searchVehicleInVPICDatabase(currentVIN)
        } else {
            updateCardValue("vin_detectado", "No leído")
            updateCardValue("instrucciones", "Selecciona un vehículo en MainActivity o lee el VIN")
            Log.d("VpicActivity", "No hay VIN seleccionado")
        }
    }

    // NUEVA FUNCIÓN: Mostrar estructura completa con tarjetas centradas
    private fun showEmptyVehicleLayout() {
        mainContainer.removeAllViews()
        valueViews.clear()

        // Título principal
        addSectionTitle("🔍 IDENTIFICADOR DE VEHÍCULOS - VPIC")

        // Sección de estado
        addCardSection("📊 ESTADO DEL SISTEMA", listOf(
            "Servicio OBD2" to "estado_servicio",
            "Instrucciones" to "instrucciones",
            "VIN Detectado" to "vin_detectado"
        ))

        // INFORMACIÓN GENERAL
        addCardSection("🚗 INFORMACIÓN GENERAL", listOf(
            "Marca" to "marca",
            "Modelo" to "modelo",
            "Año" to "ano",
            "Carrocería" to "carroceria",
            "Color" to "color"
        ))

        // PROCEDENCIA
        addCardSection("🌎 PROCEDENCIA", listOf(
            "País Ensamblaje" to "pais_ensamblaje",
            "WMI" to "wmi"
        ))

        // ESPECIFICACIONES TÉCNICAS
        addCardSection("⚙️ ESPECIFICACIONES TÉCNICAS", listOf(
            "Motor" to "motor",
            "Combustible" to "combustible",
            "Cilindrada" to "cilindrada",
            "Potencia" to "potencia",
            "Torque" to "torque",
            "Transmisión" to "transmision",
            "Tracción" to "traccion",
            "Compresión" to "compresion",
            "Emisiones" to "emisiones"
        ))

        // RANGOS OPERATIVOS
        addCardSection("📊 RANGOS OPERATIVOS", listOf(
            "RPM Mín" to "rpm_min",
            "RPM Máx" to "rpm_max",
            "RPM Óptima" to "rpm_optima",
            "Temp Motor Mín" to "temp_motor_min",
            "Temp Motor Máx" to "temp_motor_max",
            "Temp Motor Óptima" to "temp_motor_optima"
        ))

        // VIN (oculto para uso interno)
        addHiddenValue("vin", "---")
    }

    // NUEVA FUNCIÓN: Agregar título de sección
    private fun addSectionTitle(title: String) {
        val titleView = TextView(this).apply {
            text = title
            textSize = 20f
            setTextColor(0xFF1976D2.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            gravity = android.view.Gravity.CENTER
            setPadding(32, 24, 32, 16)
        }
        mainContainer.addView(titleView)
    }

    // NUEVA FUNCIÓN: Agregar sección con tarjetas
    private fun addCardSection(sectionTitle: String, items: List<Pair<String, String>>) {
        // Título de la sección
        val sectionTitleView = TextView(this).apply {
            text = sectionTitle
            textSize = 18f
            setTextColor(0xFF424242.toInt())
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(32, 24, 32, 16)
        }
        mainContainer.addView(sectionTitleView)

        // Contenedor para las tarjetas
        val cardsContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(16, 0, 16, 16)
            }
        }

        items.forEach { (label, valueKey) ->
            val card = CardView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, 0, 0, 8)
                }
                radius = 12f
                cardElevation = 4f
                setContentPadding(24, 16, 24, 16)
            }

            val cardContent = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val labelView = TextView(this).apply {
                text = label
                textSize = 14f
                setTypeface(typeface, android.graphics.Typeface.BOLD)
                setTextColor(0xFF212121.toInt())
                layoutParams = LinearLayout.LayoutParams(
                    0,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                ).apply {
                    weight = 1f
                }
            }

            val valueView = TextView(this).apply {
                text = "---"
                textSize = 14f
                setTextColor(0xFF757575.toInt())
                gravity = android.view.Gravity.END
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            // Guardar referencia para actualizaciones posteriores
            valueViews[valueKey] = valueView

            cardContent.addView(labelView)
            cardContent.addView(valueView)
            card.addView(cardContent)
            cardsContainer.addView(card)
        }

        mainContainer.addView(cardsContainer)
    }

    // FUNCIÓN: Para valores ocultos (uso interno)
    private fun addHiddenValue(key: String, value: String) {
        val valueView = TextView(this).apply {
            visibility = View.GONE
        }
        valueViews[key] = valueView
        valueView.text = value
    }

    // NUEVA FUNCIÓN: Actualizar valor específico
    private fun updateCardValue(key: String, value: String) {
        runOnUiThread {
            valueViews[key]?.text = value
        }
    }

    private fun readVinFromOBD2() {
        progressBar.visibility = View.VISIBLE
        btnReadVin.isEnabled = false
        updateCardValue("estado_servicio", "🔍 Leyendo VIN...")
        updateCardValue("instrucciones", "Espera mientras se lee el VIN del vehículo")

        Thread {
            try {
                val vinResponse = obd2Service?.readPID("0902")
                Log.d("VpicActivity", "Respuesta VIN: $vinResponse")
                val vin = parseVIN(vinResponse)

                runOnUiThread {
                    progressBar.visibility = View.GONE
                    btnReadVin.isEnabled = true

                    if (vin.isNotEmpty()) {
                        tvVin.text = "✅ VIN: $vin"
                        updateCardValue("vin_detectado", "✅ $vin")
                        updateCardValue("vin", vin)

                        // Guardar el VIN actual en ELM327Manager
                        ELM327Manager.currentVIN = vin

                        // ASIGNAR VIN AL VEHÍCULO (NUEVO)
                        handleVehicleVINAssignment(vin)

                        // Buscar vehículo en Firebase VPIC
                        searchVehicleInVPICDatabase(vin)
                    } else {
                        updateCardValue("estado_servicio", "❌ Error lectura VIN")
                        updateCardValue("instrucciones", "Verifica conexión ELM327 y reinicia")
                    }
                }
            } catch (e: Exception) {
                Log.e("VpicActivity", "Error leyendo VIN", e)
                runOnUiThread {
                    progressBar.visibility = View.GONE
                    btnReadVin.isEnabled = true
                    updateCardValue("estado_servicio", "❌ Error: ${e.message}")
                }
            }
        }.start()
    }
    // En VpicActivity.kt, dentro de la clase, agrega este método:

    private fun handleVehicleVINAssignment(vin: String) {
        val vehicleId = intent.getStringExtra("VEHICLE_ID")

        if (!vehicleId.isNullOrEmpty()) {
            // Actualizar el vehículo con el VIN leído
            val vehicleRef = database.getReference("vehicles").child(vehicleId)

            vehicleRef.child("vin").setValue(vin).addOnSuccessListener {
                Log.d("VpicActivity", "✅ VIN $vin asignado al vehículo $vehicleId")

                // También actualizar ELM327Manager
                ELM327Manager.currentVIN = vin

                // Mostrar mensaje al usuario
                runOnUiThread {
                    Toast.makeText(this, "✅ VIN asignado al vehículo", Toast.LENGTH_SHORT).show()
                }
            }.addOnFailureListener { error ->
                Log.e("VpicActivity", "❌ Error asignando VIN: ${error.message}")
            }
        }
    }

    private fun parseVIN(response: String?): String {
        if (response == null || response.contains("ERROR") || response.contains("NO_DATA")) {
            return ""
        }

        return try {
            val parts = response.split(" ").filter { it.isNotBlank() }

            if (parts.size >= 6 && parts[0] == "49" && parts[1] == "02") {
                val vinBytes = parts.drop(3)
                val vin = vinBytes.map { byteStr ->
                    try {
                        val charCode = byteStr.toInt(16)
                        charCode.toChar()
                    } catch (e: Exception) {
                        '?'
                    }
                }.joinToString("")

                vin.filter { it.isLetterOrDigit() }
            } else {
                ""
            }
        } catch (e: Exception) {
            Log.e("VIN_Parse", "Error parsing VIN: $response", e)
            ""
        }
    }

    // MÉTODO CORREGIDO: Buscar en la estructura VPIC real
    private fun searchVehicleInVPICDatabase(vin: String) {
        updateCardValue("estado_servicio", "🔍 Buscando en base de datos VPIC...")
        updateCardValue("instrucciones", "Buscando vehículo con VIN: $vin")

        // BUSCAR EN LA ESTRUCTURA CORRECTA DE VPIC
        val vpicRef = database.getReference("vpic/vehiculos/$vin")

        vpicRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                if (snapshot.exists()) {
                    // VEHÍCULO ENCONTRADO EN LA BASE DE DATOS VPIC
                    updateCardValue("estado_servicio", "✅ Vehículo encontrado en VPIC")
                    loadVpicDataFromDatabase(snapshot, vin)
                } else {
                    // Vehículo no existe en VPIC
                    updateCardValue("estado_servicio", "⚠️ Vehículo no encontrado en VPIC")
                    updateCardValue("instrucciones", "Este VIN no está registrado en la base de datos VPIC")
                    clearVehicleData()
                }
            }

            override fun onCancelled(error: DatabaseError) {
                updateCardValue("estado_servicio", "❌ Error base de datos VPIC")
                updateCardValue("instrucciones", error.message ?: "Error desconocido")
            }
        })
    }

    // MÉTODO: Cargar datos desde la estructura VPIC real
    private fun loadVpicDataFromDatabase(snapshot: DataSnapshot, vin: String) {
        try {
            // INFORMACIÓN GENERAL
            val infoGeneral = snapshot.child("info_general")
            val marca = infoGeneral.child("marca").getValue(String::class.java) ?: ""
            val modelo = infoGeneral.child("modelo").getValue(String::class.java) ?: ""
            val ano = infoGeneral.child("ano").getValue(Int::class.java) ?: 0
            val carroceria = infoGeneral.child("carroceria").getValue(String::class.java) ?: ""
            val color = infoGeneral.child("color").getValue(String::class.java) ?: ""

            // PROCEDENCIA
            val procedencia = snapshot.child("procedencia")
            val paisEnsamblaje = procedencia.child("pais_ensamblaje").getValue(String::class.java) ?: ""
            val wmi = procedencia.child("wmi").getValue(String::class.java) ?: ""

            // ESPECIFICACIONES TÉCNICAS
            val especificaciones = snapshot.child("especificaciones_tecnicas")
            val motor = especificaciones.child("motor").getValue(String::class.java) ?: ""
            val combustible = especificaciones.child("combustible").getValue(String::class.java) ?: ""
            val cilindrada = especificaciones.child("cilindrada_cc").getValue(Int::class.java) ?: 0
            val potencia = especificaciones.child("potencia_hp").getValue(Int::class.java) ?: 0
            val torque = especificaciones.child("torque_nm").getValue(Int::class.java) ?: 0
            val transmision = especificaciones.child("transmision").getValue(String::class.java) ?: ""
            val traccion = especificaciones.child("traccion").getValue(String::class.java) ?: ""
            val compresion = especificaciones.child("compresion").getValue(String::class.java) ?: ""
            val emisiones = especificaciones.child("emisiones").getValue(String::class.java) ?: ""

            // RANGOS OPERATIVOS
            val rangos = snapshot.child("rangos_operativos")
            val rpm = rangos.child("rpm")
            val rpmMin = rpm.child("min").getValue(Int::class.java) ?: 0
            val rpmMax = rpm.child("max").getValue(Int::class.java) ?: 0
            val rpmOptima = rpm.child("optima").getValue(Int::class.java) ?: 0

            val tempMotor = rangos.child("temperatura_motor")
            val tempMin = tempMotor.child("min").getValue(Int::class.java) ?: 0
            val tempMax = tempMotor.child("max").getValue(Int::class.java) ?: 0
            val tempOptima = tempMotor.child("optima").getValue(Int::class.java) ?: 0

            // Actualizar la interfaz con los datos reales de VPIC
            // INFORMACIÓN GENERAL
            updateCardValue("marca", marca.ifEmpty { "---" })
            updateCardValue("modelo", modelo.ifEmpty { "---" })
            updateCardValue("ano", if (ano > 0) ano.toString() else "---")
            updateCardValue("carroceria", carroceria.ifEmpty { "---" })
            updateCardValue("color", color.ifEmpty { "---" })

            // PROCEDENCIA
            updateCardValue("pais_ensamblaje", paisEnsamblaje.ifEmpty { "---" })
            updateCardValue("wmi", wmi.ifEmpty { "---" })

            // ESPECIFICACIONES TÉCNICAS
            updateCardValue("motor", motor.ifEmpty { "---" })
            updateCardValue("combustible", combustible.ifEmpty { "---" })
            updateCardValue("cilindrada", if (cilindrada > 0) "${cilindrada} cc" else "---")
            updateCardValue("potencia", if (potencia > 0) "${potencia} HP" else "---")
            updateCardValue("torque", if (torque > 0) "${torque} Nm" else "---")
            updateCardValue("transmision", transmision.ifEmpty { "---" })
            updateCardValue("traccion", traccion.ifEmpty { "---" })
            updateCardValue("compresion", compresion.ifEmpty { "---" })
            updateCardValue("emisiones", emisiones.ifEmpty { "---" })

            // RANGOS OPERATIVOS
            updateCardValue("rpm_min", if (rpmMin > 0) rpmMin.toString() else "---")
            updateCardValue("rpm_max", if (rpmMax > 0) rpmMax.toString() else "---")
            updateCardValue("rpm_optima", if (rpmOptima > 0) rpmOptima.toString() else "---")
            updateCardValue("temp_motor_min", if (tempMin > 0) "${tempMin}°C" else "---")
            updateCardValue("temp_motor_max", if (tempMax > 0) "${tempMax}°C" else "---")
            updateCardValue("temp_motor_optima", if (tempOptima > 0) "${tempOptima}°C" else "---")

            updateCardValue("vin", vin)

            updateCardValue("estado_servicio", "✅ Datos VPIC cargados")
            updateCardValue("instrucciones", "Datos técnicos cargados correctamente desde VPIC")

            // Guardar también en la estructura de vehicles para consistencia
            saveVpicDataToVehicleStructure(vin, marca, modelo, ano, color, motor, transmision, combustible)

        } catch (e: Exception) {
            Log.e("VpicActivity", "Error procesando datos VPIC", e)
            updateCardValue("estado_servicio", "❌ Error cargando datos VPIC")
            updateCardValue("instrucciones", "Estructura de datos incorrecta: ${e.message}")
        }
    }

    // MÉTODO: Limpiar datos cuando no se encuentra el VIN
    private fun clearVehicleData() {
        // Información General
        updateCardValue("marca", "---")
        updateCardValue("modelo", "---")
        updateCardValue("ano", "---")
        updateCardValue("carroceria", "---")
        updateCardValue("color", "---")

        // Procedencia
        updateCardValue("pais_ensamblaje", "---")
        updateCardValue("wmi", "---")

        // Especificaciones Técnicas
        updateCardValue("motor", "---")
        updateCardValue("combustible", "---")
        updateCardValue("cilindrada", "---")
        updateCardValue("potencia", "---")
        updateCardValue("torque", "---")
        updateCardValue("transmision", "---")
        updateCardValue("traccion", "---")
        updateCardValue("compresion", "---")
        updateCardValue("emisiones", "---")

        // Rangos Operativos
        updateCardValue("rpm_min", "---")
        updateCardValue("rpm_max", "---")
        updateCardValue("rpm_optima", "---")
        updateCardValue("temp_motor_min", "---")
        updateCardValue("temp_motor_max", "---")
        updateCardValue("temp_motor_optima", "---")
    }

    // MÉTODO: Guardar datos en la estructura de vehicles también
    private fun saveVpicDataToVehicleStructure(vin: String, marca: String, modelo: String, ano: Int,
                                               color: String, motor: String, transmision: String, combustible: String) {
        val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
        if (currentUser == null) return

        val vehiclesRef = database.getReference("vehicles")

        // Buscar si el vehículo ya existe en la estructura de vehicles
        vehiclesRef.orderByChild("vin").equalTo(vin)
            .addListenerForSingleValueEvent(object : ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    val vpicData = VpicData(
                        marca = marca,
                        modelo = modelo,
                        año = ano,
                        color = color,
                        motor = motor,
                        transmision = transmision,
                        combustible = combustible,
                        ultimaActualizacion = System.currentTimeMillis()
                    )

                    if (snapshot.exists()) {
                        // Actualizar vehículo existente
                        val vehicleSnapshot = snapshot.children.first()
                        val vehicleId = vehicleSnapshot.key
                        vehicleId?.let { id ->
                            val updates = hashMapOf<String, Any>(
                                "vpicData" to vpicData
                            )
                            database.getReference("vehicles").child(id).updateChildren(updates)
                                .addOnSuccessListener {
                                    Log.d("VpicActivity", "✅ Datos VPIC sincronizados en vehicles")
                                }
                        }
                    } else {
                        // Crear nuevo vehículo
                        val vehicleRef = vehiclesRef.push()
                        val vehicleId = vehicleRef.key ?: ""

                        val vehicle = Vehicle(
                            id = vehicleId,
                            ownerId = currentUser.uid,
                            nombre = "$marca $modelo",
                            vin = vin,
                            assignedMechanics = emptyList(),
                            vpicData = vpicData,
                            sensorData = SensorData(),
                            errorData = ErrorData(),
                            createdAt = System.currentTimeMillis()
                        )

                        vehicleRef.setValue(vehicle)
                            .addOnSuccessListener {
                                Log.d("VpicActivity", "✅ Nuevo vehículo creado en estructura vehicles")
                            }
                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    Log.e("VpicActivity", "Error sincronizando con vehicles", error.toException())
                }
            })
    }

    // Data classes (se mantienen igual)
    data class Vehicle(
        val id: String = "",
        val ownerId: String = "",
        val nombre: String = "",
        val vin: String = "",
        val assignedMechanics: List<String> = emptyList(),
        val vpicData: VpicData = VpicData(),
        val sensorData: SensorData = SensorData(),
        val errorData: ErrorData = ErrorData(),
        val createdAt: Long = 0L
    )

    data class VpicData(
        val marca: String = "",
        val modelo: String = "",
        val año: Int = 0,
        val color: String = "",
        val motor: String = "",
        val transmision: String = "",
        val combustible: String = "",
        val ultimaActualizacion: Long = 0L
    )

    data class SensorData(
        val rpm: String = "",
        val cargaMotor: String = "",
        val avanceEncendido: String = "",
        val tempRefrigerante: String = "",
        val tempAireAdmision: String = "",
        val tempAireAmbiental: String = "",
        val nivelCombustible: String = "",
        val presionCombustible: String = "",
        val tasaConsumo: String = "",
        val presionMAP: String = "",
        val presionBarometrica: String = "",
        val velocidad: String = "",
        val posicionAcelerador: String = "",
        val ultimaLectura: Long = 0L
    )

    data class ErrorData(
        val codigosActivos: List<String> = emptyList(),
        val codigosPendientes: List<String> = emptyList(),
        val ultimaLectura: Long = 0L
    )
}