package com.example.myapplicationelm327_v1
import com.example.myapplicationelm327_v1.ELM327Connection

import android.bluetooth.BluetoothDevice
import com.example.myapplicationelm327_v1.IOBD2Service
import com.example.myapplicationelm327_v1.OBD2ServiceFactory

object ELM327Manager {
    var connection: ELM327Connection? = null
    var obd2Service: IOBD2Service? = null
    var isConnected: Boolean = false
    var currentDevice: BluetoothDevice? = null
    var currentProtocol: ELM327Connection.Protocol = ELM327Connection.Protocol.AUTO

    var currentVIN: String? = null

    fun initializeService(device: BluetoothDevice?) {
        obd2Service = OBD2ServiceFactory.createService(device)
    }

    fun disconnect() {
        obd2Service?.disconnect()
        connection?.disconnect()
        connection = null
        obd2Service = null
        isConnected = false
        currentDevice = null
    }

    fun isSimulationMode(): Boolean = OBD2ServiceFactory.isSimulationMode()
}